import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import {
  createOrders,
  getOrderById,
  listOrders,
  updateOrderStatus,
} from '../services/order.service.js';
import { created, success } from '../utils/response.js';
import { parseEnum, parseId, parsePagination } from '../utils/validate.js';
import { validateOrderCreate, validateOrderStatus } from '../validators/order.validator.js';

const ORDER_STATUSES = ['pending_seller', 'in_progress', 'completed', 'cancelled'];

export const orderRouter = Router();
orderRouter.use(requireAuth);

orderRouter.post('/', (req, res) => {
  const orders = createOrders(req.user, validateOrderCreate(req.body));
  return created(res, { orders }, '订单创建成功，等待卖家确认');
});

orderRouter.get('/', (req, res) => {
  const { page, pageSize } = parsePagination(req.query, { defaultPageSize: 10 });
  const role = parseEnum(req.query.role ?? 'buyer', ['buyer', 'seller'], '订单角色');
  const status = req.query.status ? parseEnum(req.query.status, ORDER_STATUSES, '订单状态') : null;
  return success(res, listOrders(req.user.id, { role, status, page, pageSize }), '获取订单列表成功');
});

orderRouter.get('/:id', (req, res) => {
  const id = parseId(req.params.id, '订单 ID');
  return success(res, getOrderById(id, req.user), '获取订单详情成功');
});

orderRouter.patch('/:id/status', (req, res) => {
  const id = parseId(req.params.id, '订单 ID');
  const payload = validateOrderStatus(req.body);
  return success(res, updateOrderStatus(id, req.user, payload), '订单状态已更新');
});
