import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import {
  ArrowLeft,
  BookOpen,
  CheckCircle2,
  MapPin,
  Pencil,
  ShieldCheck,
  ShoppingBag,
  Store,
  Trash2,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import { useToast } from '../contexts/ToastContext';
import * as booksApi from '../services/books';
import * as cartApi from '../services/cart';
import { ErrorMessage, LoadingSpinner, StatusBadge } from '../components/common';
import BookCard from '../components/BookCard';
import Modal from '../components/Modal';
import { useDocumentTitle } from '../hooks/useDocumentTitle';
import {
  conditionLabel,
  discountPercent,
  formatDate,
  formatPrice,
  getCoverUrl,
  handleCoverError,
  initials,
} from '../utils/format';

export default function BookDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { isAuthenticated, user } = useAuth();
  const { refresh: refreshCart } = useCart();
  const toast = useToast();
  const [book, setBook] = useState(null);
  const [similar, setSimilar] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [busy, setBusy] = useState('');
  const [confirmOffline, setConfirmOffline] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);

  useDocumentTitle(book?.title ?? '图书详情');

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError(null);
    booksApi
      .detail(id)
      .then((data) => {
        if (!active) return;
        setBook(data);
        return booksApi
          .similar(id, { limit: 4 })
          .then((result) => {
            if (active) setSimilar(result.items);
          })
          .catch(() => {
            if (active) setSimilar([]);
          });
      })
      .catch((loadError) => {
        if (active) setError(loadError.message);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [id, reloadKey]);

  if (loading) {
    return (
      <div className="container page-section">
        <LoadingSpinner label="正在翻开这本书…" />
      </div>
    );
  }

  if (error || !book) {
    return (
      <div className="container page-section">
        <ErrorMessage message={error ?? '图书不存在'} onRetry={() => setReloadKey((key) => key + 1)} />
        <Link to="/books" className="button button--secondary" style={{ marginTop: 16 }}>
          <ArrowLeft size={16} /> 返回图书列表
        </Link>
      </div>
    );
  }

  const isOwner = user?.id === book.seller?.id;
  const available = book.reviewStatus === 'approved' && book.saleStatus === 'available';
  const discount = discountPercent(book.originalPrice, book.price);
  const savings =
    book.originalPrice && Number(book.originalPrice) > Number(book.price)
      ? Number(book.originalPrice) - Number(book.price)
      : null;

  const requireLogin = () => {
    if (isAuthenticated) return true;
    toast.info('请先登录后再继续操作');
    navigate(`/login?redirect=${encodeURIComponent(`/books/${book.id}`)}`);
    return false;
  };

  const addToCart = async (buyNow = false) => {
    if (!requireLogin()) return;
    setBusy(buyNow ? 'buy' : 'cart');
    try {
      await cartApi.addBook(book.id);
      await refreshCart();
      if (buyNow) {
        toast.success('已加入购物车，请确认订单信息');
        navigate('/cart');
      } else {
        toast.success('已加入购物车');
      }
    } catch (actionError) {
      if (actionError.code === 'ALREADY_IN_CART') {
        toast.info('这本书已经在购物车中');
        if (buyNow) navigate('/cart');
      } else {
        toast.error(actionError.message);
      }
    } finally {
      setBusy('');
    }
  };

  const handleOffline = async () => {
    setBusy('offline');
    try {
      await booksApi.offline(book.id);
      toast.success('图书已下架');
      setConfirmOffline(false);
      navigate('/profile?tab=books');
    } catch (actionError) {
      toast.error(actionError.message);
    } finally {
      setBusy('');
    }
  };

  return (
    <div className="container page-section">
      <nav className="breadcrumb" aria-label="面包屑">
        <Link to="/">首页</Link>
        <span>/</span>
        <Link to={`/books?category=${book.category?.slug ?? ''}`}>{book.category?.name ?? '图书'}</Link>
        <span>/</span>
        <span aria-current="page">{book.title}</span>
      </nav>

      {isOwner && book.reviewStatus !== 'approved' && (
        <div className={`notice notice--${book.reviewStatus === 'rejected' ? 'danger' : 'warning'}`}>
          <StatusBadge type="review" status={book.reviewStatus} />
          <span>
            {book.reviewStatus === 'pending'
              ? '这本书正在等待管理员审核，审核通过后会出现在公开列表中。'
              : `审核未通过：${book.reviewNote || '请修改图书信息后重新提交。'}`}
          </span>
          <Link to={`/books/${book.id}/edit`} className="button button--secondary button--sm">
            编辑并重新提交
          </Link>
        </div>
      )}

      <div className="detail-layout">
        <div className="detail-cover">
          <div className="detail-cover__frame">
            <img
              src={getCoverUrl(book.coverPath)}
              alt={`《${book.title}》封面`}
              onError={handleCoverError}
            />
          </div>
          <div className="detail-cover__meta">
            <span className="pill pill--outline">
              <BookOpen size={13} /> {conditionLabel(book.condition)}
            </span>
            {book.saleStatus !== 'available' && <StatusBadge type="sale" status={book.saleStatus} />}
          </div>
        </div>

        <div className="detail-info">
          <div className="detail-info__top">
            <Link to={`/books?category=${book.category?.slug ?? ''}`} className="pill pill--soft">
              {book.category?.name}
            </Link>
            {book.reviewStatus !== 'approved' && (
              <StatusBadge type="review" status={book.reviewStatus} />
            )}
          </div>
          <h1>{book.title}</h1>
          <p className="detail-author">{book.author}</p>

          <div className="detail-meta-grid">
            <div>
              <span>ISBN</span>
              <b>{book.isbn}</b>
            </div>
            <div>
              <span>出版社</span>
              <b>{book.publisher || '未填写'}</b>
            </div>
            <div>
              <span>出版年份</span>
              <b>{book.publishYear || '未填写'}</b>
            </div>
            <div>
              <span>发布时间</span>
              <b>{formatDate(book.createdAt)}</b>
            </div>
          </div>

          <div className="price-panel">
            <div className="price-panel__main">
              <span className="price price--hero">{formatPrice(book.price)}</span>
              {book.originalPrice && <s className="price-original">原价 {formatPrice(book.originalPrice)}</s>}
              {discount && <span className="discount">省 {discount}%</span>}
            </div>
            {savings !== null && (
              <p className="price-panel__savings">比购买新书少花 {formatPrice(savings)}</p>
            )}
            <p className="price-panel__note">
              <ShieldCheck size={15} /> 二手书每本仅有一册 · 校内当面自提
            </p>
          </div>

          {!isOwner && (
            <div className="detail-actions">
              <button
                type="button"
                className="button button--primary button--lg"
                onClick={() => addToCart(true)}
                disabled={!available || Boolean(busy)}
              >
                <ShoppingBag size={17} /> 立即购买
              </button>
              <button
                type="button"
                className="button button--secondary button--lg"
                onClick={() => addToCart(false)}
                disabled={!available || Boolean(busy)}
              >
                加入购物车
              </button>
              {!available && (
                <p className="detail-unavailable">
                  {book.saleStatus === 'sold'
                    ? '这本书已经售出，可以继续查看信息或收藏。'
                    : book.saleStatus === 'reserved'
                      ? '这本书正在进行交易，暂时无法购买。'
                      : '这本书暂不可交易。'}
                </p>
              )}
            </div>
          )}

          {isOwner && (
            <div className="detail-actions">
              <Link to={`/books/${book.id}/edit`} className="button button--secondary">
                <Pencil size={16} /> 编辑图书
              </Link>
              {book.saleStatus !== 'offline' && book.saleStatus !== 'sold' && (
                <button
                  type="button"
                  className="button button--danger"
                  onClick={() => setConfirmOffline(true)}
                  disabled={book.saleStatus === 'reserved'}
                >
                  <Trash2 size={16} /> 下架图书
                </button>
              )}
              <span className="muted">这是你发布的图书，不能购买自己的商品。</span>
            </div>
          )}

          <div className="detail-seller">
            <span className="avatar">{initials(book.seller?.username)}</span>
            <div className="detail-seller__info">
              <strong>{book.seller?.username}</strong>
              <span>
                <MapPin size={13} /> {book.seller?.campus || '校内自提'}
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="detail-sections">
        <section className="panel" aria-labelledby="detail-description">
          <h2 id="detail-description">图书描述</h2>
          <p className="pre-line">{book.description || '卖家暂未填写详细描述，可在交易前当面确认书况。'}</p>
        </section>

        <section className="panel" aria-labelledby="detail-pickup">
          <h2 id="detail-pickup">交易与自提</h2>
          <ul className="info-list">
            <li>
              <MapPin size={16} />
              <div>
                <b>自提地点</b>
                <span>{book.pickupLocation || '可与卖家协商校内地点'}</span>
              </div>
            </li>
            <li>
              <Store size={16} />
              <div>
                <b>交易方式</b>
                <span>下单后由卖家确认，校内当面验书并完成交易</span>
              </div>
            </li>
            <li>
              <CheckCircle2 size={16} />
              <div>
                <b>书况说明</b>
                <span>{conditionLabel(book.condition)} · 下单前可与卖家确认细节</span>
              </div>
            </li>
          </ul>
          <p className="panel__hint">
            安全提示：请在校内公共区域当面交易，确认书况后再确认订单完成。平台不接入真实支付，
            具体付款方式由双方线下协商。
          </p>
        </section>
      </div>

      {similar.length > 0 && (
        <section className="page-section page-section--tight" aria-labelledby="similar-heading">
          <div className="section-heading">
            <div>
              <span className="eyebrow eyebrow--plain">同类教材</span>
              <h2 id="similar-heading">相似图书推荐</h2>
            </div>
          </div>
          <div className="book-grid book-grid--four">
            {similar.map((item) => (
              <BookCard key={item.id} book={item} />
            ))}
          </div>
        </section>
      )}

      <Modal
        open={confirmOffline}
        title="确认下架这本书？"
        onClose={() => setConfirmOffline(false)}
        footer={
          <>
            <button type="button" className="button button--ghost" onClick={() => setConfirmOffline(false)}>
              取消
            </button>
            <button
              type="button"
              className="button button--danger"
              onClick={handleOffline}
              disabled={busy === 'offline'}
            >
              {busy === 'offline' ? '正在下架…' : '确认下架'}
            </button>
          </>
        }
      >
        <p>下架后图书将不再出现在公开列表中，已有订单不受影响。你可以在个人中心看到它。</p>
      </Modal>
    </div>
  );
}
