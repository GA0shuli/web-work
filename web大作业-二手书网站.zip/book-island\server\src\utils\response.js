export const asyncHandler = (handler) => (req, res, next) => {
  Promise.resolve(handler(req, res, next)).catch(next);
};

export function success(res, data = null, message = '操作成功', status = 200) {
  return res.status(status).json({ success: true, message, data });
}

export function created(res, data, message = '创建成功') {
  return success(res, data, message, 201);
}
