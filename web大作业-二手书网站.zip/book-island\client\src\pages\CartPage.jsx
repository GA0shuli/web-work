import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowRight, CheckCircle2, Loader2, ShoppingBag, Trash2 } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import { useToast } from '../contexts/ToastContext';
import * as cartApi from '../services/cart';
import * as ordersApi from '../services/orders';
import { EmptyState, ErrorMessage, LoadingSpinner } from '../components/common';
import Modal from '../components/Modal';
import { useDocumentTitle } from '../hooks/useDocumentTitle';
import {
  conditionLabel,
  formatPrice,
  getCoverUrl,
  handleCoverError,
} from '../utils/format';

export default function CartPage() {
  useDocumentTitle('购物车');
  const { user } = useAuth();
  const { refresh: refreshCart } = useCart();
  const toast = useToast();
  const navigate = useNavigate();

  const [cart, setCart] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selected, setSelected] = useState([]);
  const [reloadKey, setReloadKey] = useState(0);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [removing, setRemoving] = useState(null);
  const [busy, setBusy] = useState(false);
  const [formError, setFormError] = useState('');
  const [form, setForm] = useState({
    contactName: user?.username ?? '',
    contactPhone: '',
    pickupLocation: '',
    note: '',
  });

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError(null);
    cartApi
      .getCart()
      .then((data) => {
        if (!active) return;
        setCart(data);
        setSelected(data.items.filter((item) => item.purchasable).map((item) => item.id));
      })
      .catch((loadError) => {
        if (active) setError(loadError.message);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [reloadKey]);

  const purchasableItems = useMemo(
    () => (cart?.items ?? []).filter((item) => item.purchasable),
    [cart],
  );
  const selectedItems = useMemo(
    () => purchasableItems.filter((item) => selected.includes(item.id)),
    [purchasableItems, selected],
  );
  const subtotal = selectedItems.reduce((sum, item) => sum + item.book.price, 0);
  const allSelected = purchasableItems.length > 0 && selected.length === purchasableItems.length;

  const toggleAll = () => {
    setSelected(allSelected ? [] : purchasableItems.map((item) => item.id));
  };

  const toggleItem = (id) => {
    setSelected((current) =>
      current.includes(id) ? current.filter((item) => item !== id) : [...current, id],
    );
  };

  const openCheckout = () => {
    if (!selectedItems.length) return;
    const pickup = selectedItems[0]?.book.pickupLocation ?? '';
    setForm((current) => ({ ...current, pickupLocation: current.pickupLocation || pickup }));
    setFormError('');
    setCheckoutOpen(true);
  };

  const removeItem = async () => {
    if (!removing) return;
    setBusy(true);
    try {
      const data = await cartApi.removeItem(removing.id);
      setCart(data);
      setSelected((current) => current.filter((id) => id !== removing.id));
      await refreshCart();
      toast.success('已从购物车移除');
      setRemoving(null);
    } catch (removeError) {
      toast.error(removeError.message);
    } finally {
      setBusy(false);
    }
  };

  const submitOrder = async (event) => {
    event.preventDefault();
    const name = form.contactName.trim();
    const phone = form.contactPhone.trim();
    if (name.length < 2) {
      setFormError('请填写至少 2 个字符的联系人姓名');
      return;
    }
    if (!/^[0-9+\-\s]{6,20}$/.test(phone)) {
      setFormError('请填写正确的联系电话');
      return;
    }
    setBusy(true);
    setFormError('');
    try {
      const result = await ordersApi.create({
        bookIds: selectedItems.map((item) => item.book.id),
        contactName: name,
        contactPhone: phone,
        pickupLocation: form.pickupLocation.trim(),
        note: form.note.trim(),
      });
      await refreshCart();
      setCheckoutOpen(false);
      toast.success(
        result.orders.length > 1
          ? `已按卖家生成 ${result.orders.length} 笔订单，等待卖家确认`
          : '订单创建成功，等待卖家确认',
      );
      navigate('/orders?tab=buyer');
    } catch (orderError) {
      setFormError(orderError.message);
    } finally {
      setBusy(false);
    }
  };

  if (loading) {
    return (
      <div className="container page-section">
        <LoadingSpinner label="正在整理购物车…" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="container page-section">
        <ErrorMessage message={error} onRetry={() => setReloadKey((key) => key + 1)} />
      </div>
    );
  }

  return (
    <div className="container page-section">
      <header className="page-header">
        <div>
          <span className="eyebrow eyebrow--plain">确认你的选购</span>
          <h1>购物车</h1>
          <p>二手书每本仅有一册，订单金额由后端根据当前售价重新计算。</p>
        </div>
        <Link to="/books" className="button button--secondary">
          继续逛书
        </Link>
      </header>

      {!cart?.items.length ? (
        <EmptyState
          icon={ShoppingBag}
          title="购物车还是空的"
          description="去发现一本适合下一门课的教材吧。"
          action={
            <Link to="/books" className="button button--primary">
              浏览图书 <ArrowRight size={16} />
            </Link>
          }
        />
      ) : (
        <div className="cart-layout">
          <section className="cart-list" aria-label="购物车商品">
            <div className="cart-list__header">
              <label className="check-row check-row--inline">
                <input type="checkbox" checked={allSelected} onChange={toggleAll} />
                <span>全选可购买图书</span>
              </label>
              <span className="muted">{purchasableItems.length} 本可购买</span>
            </div>

            {cart.items.map((item) => (
              <article
                key={item.id}
                className={`cart-item${item.purchasable ? '' : ' is-unavailable'}`}
              >
                <label className="cart-item__check">
                  <input
                    type="checkbox"
                    checked={selected.includes(item.id)}
                    onChange={() => toggleItem(item.id)}
                    disabled={!item.purchasable}
                    aria-label={`选择《${item.book.title}》`}
                  />
                </label>
                <Link to={`/books/${item.book.id}`} className="cart-item__cover">
                  <img
                    src={getCoverUrl(item.book.coverPath)}
                    alt={`《${item.book.title}》封面`}
                    onError={handleCoverError}
                  />
                </Link>
                <div className="cart-item__info">
                  <Link to={`/books/${item.book.id}`} className="cart-item__title">
                    {item.book.title}
                  </Link>
                  <p>{item.book.author}</p>
                  <div className="cart-item__meta">
                    <span className="pill pill--outline">{conditionLabel(item.book.condition)}</span>
                    <span className="muted">卖家：{item.book.seller?.username}</span>
                    <span className="muted">{item.book.pickupLocation || '校内自提'}</span>
                  </div>
                  {!item.purchasable && (
                    <p className="cart-item__warning">{item.unavailableReason}</p>
                  )}
                </div>
                <div className="cart-item__price">
                  <strong className="price">{formatPrice(item.book.price)}</strong>
                  <span className="muted">数量 1</span>
                </div>
                <button
                  type="button"
                  className="icon-button cart-item__remove"
                  onClick={() => setRemoving(item)}
                  aria-label={`移除《${item.book.title}》`}
                >
                  <Trash2 size={17} />
                </button>
              </article>
            ))}
          </section>

          <aside className="cart-summary" aria-label="订单结算">
            <h2>订单摘要</h2>
            <dl>
              <div>
                <dt>已选图书</dt>
                <dd>{selectedItems.length} 本</dd>
              </div>
              <div>
                <dt>商品小计</dt>
                <dd>{formatPrice(Number(subtotal.toFixed(2)), { exact: true })}</dd>
              </div>
              <div>
                <dt>交易方式</dt>
                <dd>校内自提</dd>
              </div>
            </dl>
            <div className="cart-summary__total">
              <span>应付金额</span>
              <strong>{formatPrice(Number(subtotal.toFixed(2)), { exact: true })}</strong>
            </div>
            <button
              type="button"
              className="button button--primary button--block button--lg"
              onClick={openCheckout}
              disabled={!selectedItems.length}
            >
              去结算 <ArrowRight size={16} />
            </button>
            <p className="cart-summary__note">
              <CheckCircle2 size={14} /> 提交前会再次校验图书状态、价格和卖家身份。
            </p>
            <p className="cart-summary__note">本平台不接入真实支付，请与卖家线下完成交易。</p>
          </aside>
        </div>
      )}

      <Modal
        open={Boolean(removing)}
        title="移出购物车？"
        onClose={() => setRemoving(null)}
        footer={
          <>
            <button type="button" className="button button--ghost" onClick={() => setRemoving(null)}>
              取消
            </button>
            <button type="button" className="button button--danger" onClick={removeItem} disabled={busy}>
              {busy ? '正在移除…' : '确认移除'}
            </button>
          </>
        }
      >
        <p>确定要将《{removing?.book.title}》移出购物车吗？</p>
      </Modal>

      <Modal
        open={checkoutOpen}
        title="确认交易信息"
        onClose={() => !busy && setCheckoutOpen(false)}
        footer={
          <>
            <button
              type="button"
              className="button button--ghost"
              onClick={() => setCheckoutOpen(false)}
              disabled={busy}
            >
              返回
            </button>
            <button type="submit" form="checkout-form" className="button button--primary" disabled={busy}>
              {busy ? <Loader2 size={16} className="loading__icon" /> : null}
              {busy ? '正在创建订单…' : `提交订单 · ${formatPrice(Number(subtotal.toFixed(2)), { exact: true })}`}
            </button>
          </>
        }
      >
        <form id="checkout-form" className="form-stack" onSubmit={submitOrder} noValidate>
          {formError && (
            <div className="alert alert--danger" role="alert">
              {formError}
            </div>
          )}
          <div className="modal-summary">
            {selectedItems.map((item) => (
              <div key={item.id}>
                <span>{item.book.title}</span>
                <b>{formatPrice(item.book.price)}</b>
              </div>
            ))}
          </div>
          <div className="form-grid">
            <div className="field">
              <label htmlFor="contact-name">
                联系人 <span className="required">*</span>
              </label>
              <input
                id="contact-name"
                value={form.contactName}
                onChange={(event) => setForm((current) => ({ ...current, contactName: event.target.value }))}
                maxLength={30}
                placeholder="卖家如何称呼你"
              />
            </div>
            <div className="field">
              <label htmlFor="contact-phone">
                联系电话 <span className="required">*</span>
              </label>
              <input
                id="contact-phone"
                value={form.contactPhone}
                onChange={(event) => setForm((current) => ({ ...current, contactPhone: event.target.value }))}
                maxLength={20}
                placeholder="用于约定自提时间"
                inputMode="tel"
              />
            </div>
            <div className="field field--full">
              <label htmlFor="checkout-pickup">期望自提地点</label>
              <input
                id="checkout-pickup"
                value={form.pickupLocation}
                onChange={(event) =>
                  setForm((current) => ({ ...current, pickupLocation: event.target.value }))
                }
                maxLength={120}
                placeholder="例如 图书馆东门"
              />
            </div>
            <div className="field field--full">
              <label htmlFor="checkout-note">给卖家的备注</label>
              <textarea
                id="checkout-note"
                rows={3}
                value={form.note}
                onChange={(event) => setForm((current) => ({ ...current, note: event.target.value }))}
                maxLength={300}
                placeholder="例如 周三下午三点后均方便自提"
              />
            </div>
          </div>
          <p className="form-note">
            提交后图书将进入交易中状态。若卖家取消订单，图书会自动恢复为可交易。
          </p>
        </form>
      </Modal>
    </div>
  );
}
