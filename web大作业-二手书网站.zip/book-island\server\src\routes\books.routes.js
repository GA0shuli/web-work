import { Router } from 'express';
import { attachUser, requireAuth } from '../middleware/auth.js';
import { coverUpload } from '../middleware/upload.js';
import {
  createBook,
  getBookDetail,
  listBooks,
  offlineBook,
  updateBook,
} from '../services/book.service.js';
import { recommendBooks, similarBooks } from '../services/recommendation.service.js';
import { badRequest } from '../utils/AppError.js';
import { asyncHandler, created, success } from '../utils/response.js';
import { parseId, parseNumber, parsePagination } from '../utils/validate.js';
import { validateBookCreate, validateBookUpdate } from '../validators/book.validator.js';
import { validateRecommendationQuery } from '../validators/recommendation.validator.js';
import { BOOK_CONDITIONS, BOOK_SORTS } from '../config/constants.js';

function parseConditionFilter(value) {
  if (!value) return null;
  const conditions = String(value)
    .split(',')
    .map((item) => item.trim())
    .filter((item) => Object.hasOwn(BOOK_CONDITIONS, item));
  return conditions.length ? conditions : null;
}

export const bookRouter = Router();

bookRouter.get('/', (req, res) => {
  const { page, pageSize } = parsePagination(req.query);
  const minPrice = parseNumber(req.query.minPrice, '最低价格', { min: 0, max: 9999 });
  const maxPrice = parseNumber(req.query.maxPrice, '最高价格', { min: 0, max: 9999 });
  if (minPrice !== null && maxPrice !== null && minPrice > maxPrice) {
    throw badRequest('最低价格不能高于最高价格');
  }

  const data = listBooks({
    viewerId: req.user?.id ?? null,
    q: req.query.q ? String(req.query.q).trim().slice(0, 100) : null,
    category: req.query.category ?? req.query.categoryId ?? null,
    conditions: parseConditionFilter(req.query.condition ?? req.query.conditions),
    minPrice,
    maxPrice,
    sort: BOOK_SORTS.includes(req.query.sort) ? req.query.sort : 'newest',
    page,
    pageSize,
  });
  return success(res, data, '获取图书列表成功');
});

bookRouter.get('/recommendations', (req, res) => {
  const query = validateRecommendationQuery(req.query);
  return success(res, recommendBooks(query, req.user?.id ?? null), '推荐结果生成成功');
});

bookRouter.get('/:id/similar', attachUser, (req, res) => {
  const id = parseId(req.params.id, '图书 ID');
  const limit = parseNumber(req.query.limit, '返回数量', { min: 1, max: 12 }) ?? 6;
  return success(res, similarBooks(id, req.user?.id ?? null, limit), '获取相似图书成功');
});

bookRouter.get('/:id', attachUser, (req, res) => {
  const id = parseId(req.params.id, '图书 ID');
  return success(res, getBookDetail(id, req.user), '获取图书详情成功');
});

bookRouter.post(
  '/',
  requireAuth,
  coverUpload,
  asyncHandler(async (req, res) => {
    const payload = validateBookCreate(req.body);
    const data = await createBook({ userId: req.user.id, payload, file: req.file });
    return created(res, data, '图书已提交，等待管理员审核');
  }),
);

bookRouter.patch(
  '/:id',
  requireAuth,
  coverUpload,
  asyncHandler(async (req, res) => {
    const id = parseId(req.params.id, '图书 ID');
    const payload = validateBookUpdate(req.body, { hasCover: Boolean(req.file) });
    const data = await updateBook({ userId: req.user.id, bookId: id, payload, file: req.file });
    return success(res, data, '图书已更新，等待管理员重新审核');
  }),
);

bookRouter.delete('/:id', requireAuth, (req, res) => {
  const id = parseId(req.params.id, '图书 ID');
  return success(res, offlineBook({ userId: req.user.id, bookId: id }), '图书已下架');
});
