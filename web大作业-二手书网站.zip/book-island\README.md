# 书屿 · 校园二手书交易平台

一个面向校园的二手教材交易平台，支持图书发布、搜索筛选、购物车、订单交易和后台审核。

技术栈：React 19 + Vite（前端）/ Node.js + Express + SQLite（后端）。

---

## 一、运行环境

- Node.js 18 或更高版本（开发时使用 v24）
- Windows / macOS / Linux 均可

> 不需要另外安装数据库，SQLite 是单文件数据库，首次启动会自动建表并写入示例数据。

## 二、安装步骤

在项目根目录（`package.json` 所在目录）依次执行：

```bash
npm install
npm --prefix server install
npm --prefix client install
```

## 三、启动

```bash
npm run dev
```

看到下面两行说明启动成功：

```text
[server] 书屿 API 已启动: http://localhost:4000/api/health
[client]   ➜  Local:   http://localhost:5173/
```

浏览器打开 **http://localhost:5173** 即可。

> 终端窗口需要保持开启，关闭即停止服务。

### 也可以用 VS Code 一键启动

用 VS Code 打开项目后按 `Ctrl + Shift + B`（依赖 `.vscode/tasks.json`）。

### 生产模式（可选）

```bash
npm run build
npm start
```

然后访问 http://localhost:4000（前端静态文件由 Express 托管）。

## 四、演示账号

| 角色 | 账号 | 密码 |
| --- | --- | --- |
| 管理员 | admin@bookisland.local | Admin@12345 |
| 普通用户 | linxi@campus.edu | Demo@12345 |
| 普通用户 | chenyu@campus.edu | Demo@12345 |
| 普通用户 | zhaomiao@campus.edu | Demo@12345 |
| 普通用户 | xiaoman@campus.edu | Demo@12345 |

示例数据包含 8 个分类、21 本图书、3 笔订单。

## 五、功能说明

**访客**：浏览首页、图书列表、图书详情；按书名 / 作者 / ISBN 搜索；按分类、价格、成色筛选和排序；注册登录。

**普通用户**：发布、编辑、下架自己的图书（提交后进入待审核）；加入购物车、提交订单；查看「我买到的 / 我卖出的」；确认接单、确认完成、取消订单；维护个人资料。

**管理员**：独立后台（路由守卫 + 后端角色校验）；平台数据概览；图书审核（通过 / 驳回 / 下架）；查看全部订单。

**教材推荐**：输入课程名或 ISBN，设置预算与最低成色，按

```text
总分 = 0.40 × 关键词匹配 + 0.25 × 价格 + 0.20 × 成色 + 0.15 × 新鲜度
```

排序，并给出推荐理由。

## 六、目录结构

```text
book-island/
├── client/                 前端
│   ├── src/
│   │   ├── pages/          12 个页面
│   │   ├── components/     公共组件
│   │   ├── contexts/       全局状态（登录、购物车、提示）
│   │   ├── services/       接口封装
│   │   └── styles.css      样式
│   ├── public/covers/      默认封面
│   └── vite.config.js
├── server/                 后端
│   ├── src/
│   │   ├── routes/         路由与请求处理
│   │   ├── services/       业务逻辑与 SQL
│   │   ├── validators/     参数校验
│   │   ├── middleware/     认证、上传、限流、错误处理
│   │   └── database/       连接、建表、种子数据
│   └── tests/              接口测试
└── package.json
```

## 七、数据库表

共 6 张表：`users`（用户）、`categories`（分类）、`books`（图书）、`cart_items`（购物车）、`orders`（订单）、`order_items`（订单明细）。

## 八、测试

```bash
npm test              # 依次运行前后端测试
npm run test:server   # 后端 13 个接口测试
npm run test:client   # 前端 7 个组件测试
```

测试使用独立数据库，不会影响开发数据。

## 九、常见问题

**1. 端口被占用**

说明上一次启动的窗口没有关闭。关掉旧窗口后重新启动；仍不行可以重启电脑。

**2. 页面空白**

不要用 Live Server 打开 `client/index.html`。本项目是 Vite + React 应用，`index.html` 只是入口模板，必须通过 `npm run dev` 启动开发服务器后访问 5173 端口。

**3. PowerShell 提示禁止运行 npm.ps1**

改用 `npm.cmd`，例如 `npm.cmd run dev`；或执行
`Set-ExecutionPolicy -Scope CurrentUser RemoteSigned` 后重开终端。

**4. 想重置演示数据**

```bash
npm run db:reset
```

会删掉现有数据库文件并重新建表、写入示例数据。
