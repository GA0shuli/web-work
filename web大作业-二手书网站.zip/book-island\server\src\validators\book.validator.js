import { BOOK_CONDITIONS } from '../config/constants.js';
import { badRequest } from '../utils/AppError.js';
import {
  normalizeIsbn,
  optionalString,
  parseEnum,
  parseId,
  parseInteger,
  parseNumber,
  requiredString,
} from '../utils/validate.js';

const MAX_YEAR = new Date().getFullYear() + 1;

function normalizeCondition(value) {
  if (Object.hasOwn(BOOK_CONDITIONS, value)) return value;
  if (value === 'new') return 'like_new';
  throw badRequest('成色取值不合法');
}

function validateIsbn(value) {
  const isbn = normalizeIsbn(requiredString(value, 'ISBN', { max: 30 }));
  if (!/^\d{9}[\dX]$/.test(isbn) && !/^\d{13}$/.test(isbn)) {
    throw badRequest('ISBN 需为 10 位或 13 位有效格式');
  }
  return isbn;
}

export function validateBookCreate(body = {}) {
  return {
    title: requiredString(body.title, '书名', { max: 120 }),
    author: requiredString(body.author, '作者', { max: 80 }),
    isbn: validateIsbn(body.isbn),
    publisher: optionalString(body.publisher, '出版社', { max: 80 }),
    publishYear: parseInteger(body.publishYear, '出版年份', { min: 1900, max: MAX_YEAR }),
    categoryId: parseId(body.categoryId, '图书分类'),
    originalPrice: parseNumber(body.originalPrice, '新书参考价', { min: 0, max: 9999 }),
    price: parseNumber(body.price, '二手售价', { min: 0.01, max: 9999, required: true }),
    condition: normalizeCondition(body.condition),
    description: optionalString(body.description, '图书描述', { max: 2000 }),
    pickupLocation: optionalString(body.pickupLocation, '自提地点', { max: 120 }),
  };
}

export function validateBookUpdate(body = {}, { hasCover = false } = {}) {
  const update = {};

  if (body.title !== undefined) update.title = requiredString(body.title, '书名', { max: 120 });
  if (body.author !== undefined) update.author = requiredString(body.author, '作者', { max: 80 });
  if (body.isbn !== undefined) update.isbn = validateIsbn(body.isbn);
  if (body.publisher !== undefined) {
    update.publisher = optionalString(body.publisher, '出版社', { max: 80 });
  }
  if (body.publishYear !== undefined) {
    update.publishYear =
      body.publishYear === '' || body.publishYear === null
        ? null
        : parseInteger(body.publishYear, '出版年份', { min: 1900, max: MAX_YEAR });
  }
  if (body.categoryId !== undefined) update.categoryId = parseId(body.categoryId, '图书分类');
  if (body.originalPrice !== undefined) {
    update.originalPrice =
      body.originalPrice === '' || body.originalPrice === null
        ? null
        : parseNumber(body.originalPrice, '新书参考价', { min: 0, max: 9999 });
  }
  if (body.price !== undefined) {
    update.price = parseNumber(body.price, '二手售价', { min: 0.01, max: 9999, required: true });
  }
  if (body.condition !== undefined) update.condition = normalizeCondition(body.condition);
  if (body.description !== undefined) {
    update.description = optionalString(body.description, '图书描述', { max: 2000 });
  }
  if (body.pickupLocation !== undefined) {
    update.pickupLocation = optionalString(body.pickupLocation, '自提地点', { max: 120 });
  }

  if (Object.keys(update).length === 0 && !hasCover) {
    throw badRequest('没有需要更新的字段');
  }
  return update;
}

export function validateAdminReview(body = {}) {
  const action = parseEnum(body.action, ['approve', 'reject', 'remove'], '审核操作');
  const reason = optionalString(body.reason, '审核说明', { max: 200 });
  if (action !== 'approve' && !reason) {
    throw badRequest('驳回或下架时必须填写原因');
  }
  return { action, reason };
}
