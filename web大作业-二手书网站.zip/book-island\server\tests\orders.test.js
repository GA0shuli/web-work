import { beforeEach, describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../src/app.js';
import { CSRF, findBook, login, registerUser, resetDb } from './helpers.js';

const app = createApp();

beforeEach(() => {
  resetDb();
});

async function newBuyer() {
  const agent = request.agent(app);
  const { payload } = await registerUser(app);
  const response = await agent
    .post('/api/auth/login')
    .set(CSRF)
    .send({ identifier: payload.email, password: payload.password });
  expect(response.status).toBe(200);
  return agent;
}

const contact = {
  contactName: '满小满',
  contactPhone: '13800000001',
  pickupLocation: '图书馆东门',
  note: '周三下午自提',
};

describe('订单与交易流程', () => {
  it('下单后金额由后端计算，卖家接单、买家完成后图书变为已售出', async () => {
    const buyer = await login(app, 'xiaoman@campus.edu');
    const seller = await login(app, 'linxi@campus.edu');
    const book = await findBook(app, '数据结构（C语言版）');

    await buyer.post('/api/cart').set(CSRF).send({ bookId: book.id });
    const created = await buyer
      .post('/api/orders')
      .set(CSRF)
      .send({ bookIds: [book.id], ...contact, totalAmount: 0.01 });

    expect(created.status).toBe(201);
    const order = created.body.data.orders[0];
    expect(order.status).toBe('pending_seller');
    expect(order.totalAmount).toBe(book.price);

    expect((await buyer.get('/api/cart')).body.data.items).toHaveLength(0);
    expect((await request(app).get(`/api/books/${book.id}`)).body.data.saleStatus).toBe('reserved');

    const buyerCannotConfirm = await buyer
      .patch(`/api/orders/${order.id}/status`)
      .set(CSRF)
      .send({ status: 'in_progress' });
    expect(buyerCannotConfirm.status).toBe(400);

    const confirmed = await seller
      .patch(`/api/orders/${order.id}/status`)
      .set(CSRF)
      .send({ status: 'in_progress' });
    expect(confirmed.body.data.status).toBe('in_progress');

    const completed = await buyer
      .patch(`/api/orders/${order.id}/status`)
      .set(CSRF)
      .send({ status: 'completed' });
    expect(completed.body.data.status).toBe('completed');
    expect((await request(app).get(`/api/books/${book.id}`)).body.data.saleStatus).toBe('sold');
  });

  it('不能购买自己发布的图书，同一本书也不能被重复下单', async () => {
    const seller = await login(app, 'linxi@campus.edu');
    const ownBook = await findBook(app, '百年孤独');
    const selfOrder = await seller
      .post('/api/orders')
      .set(CSRF)
      .send({ bookIds: [ownBook.id], ...contact });
    expect(selfOrder.status).toBe(400);

    const book = await findBook(app, '算法导论（原书第3版）');
    const firstBuyer = await login(app, 'xiaoman@campus.edu');
    expect(
      (await firstBuyer.post('/api/orders').set(CSRF).send({ bookIds: [book.id], ...contact }))
        .status,
    ).toBe(201);

    const secondBuyer = await newBuyer();
    const secondOrder = await secondBuyer
      .post('/api/orders')
      .set(CSRF)
      .send({ bookIds: [book.id], ...contact });
    expect(secondOrder.status).toBe(409);
    expect(secondOrder.body.code).toBe('BOOK_NOT_AVAILABLE');
  });

  it('取消订单后图书恢复为可交易', async () => {
    const buyer = await login(app, 'xiaoman@campus.edu');
    const book = await findBook(app, '算法导论（原书第3版）');

    const created = await buyer
      .post('/api/orders')
      .set(CSRF)
      .send({ bookIds: [book.id], ...contact });
    const order = created.body.data.orders[0];

    const cancelled = await buyer
      .patch(`/api/orders/${order.id}/status`)
      .set(CSRF)
      .send({ status: 'cancelled', reason: '时间冲突，暂时无法自提' });
    expect(cancelled.status).toBe(200);
    expect(cancelled.body.data.status).toBe('cancelled');

    const detail = await request(app).get(`/api/books/${book.id}`);
    expect(detail.body.data.saleStatus).toBe('available');
  });
});
