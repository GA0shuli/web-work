import { bootstrapDatabase } from './bootstrap.js';
import { env } from '../config/env.js';

const reset = process.argv.includes('--reset');
const summary = bootstrapDatabase({ reset });

console.log(`数据库已${reset ? '重置并' : ''}初始化：${env.dbPath}`);
console.log(
  `种子数据写入结果：分类 ${summary.categories} 个，用户 ${summary.users} 个，图书 ${summary.books} 本，订单 ${summary.orders} 笔。`,
);
