import { getDb } from '../database/db.js';
import { badRequest, conflict, notFound } from '../utils/AppError.js';
import { serializeBook } from '../utils/serializers.js';

function unavailableReason(row, userId) {
  if (row.seller_id === userId) return '不能购买自己发布的图书';
  if (row.review_status !== 'approved') return '图书尚未通过审核';
  if (row.sale_status === 'sold') return '图书已售出';
  if (row.sale_status === 'reserved') return '图书正在交易中';
  if (row.sale_status !== 'available') return '图书已下架';
  return null;
}

const CART_SELECT = `
  SELECT ci.id AS cart_item_id, ci.quantity, ci.created_at AS added_at,
         b.*, c.name AS category_name, c.slug AS category_slug,
         u.username AS seller_username, u.campus AS seller_campus
  FROM cart_items ci
  JOIN books b ON b.id = ci.book_id
  JOIN categories c ON c.id = b.category_id
  JOIN users u ON u.id = b.seller_id
  WHERE ci.user_id = @userId
  ORDER BY ci.created_at DESC
`;

export function getCart(userId) {
  const rows = getDb().prepare(CART_SELECT).all({ userId });
  const items = rows.map((row) => {
    const reason = unavailableReason(row, userId);
    return {
      id: row.cart_item_id,
      quantity: row.quantity,
      addedAt: row.added_at,
      purchasable: !reason,
      unavailableReason: reason,
      book: serializeBook(row),
    };
  });
  const purchasable = items.filter((item) => item.purchasable);
  return {
    items,
    summary: {
      totalItems: items.length,
      purchasableItems: purchasable.length,
      subtotal: Number(
        purchasable.reduce((sum, item) => sum + item.book.price * item.quantity, 0).toFixed(2),
      ),
    },
  };
}

export function addToCart(userId, bookId) {
  const db = getDb();
  const book = db.prepare('SELECT * FROM books WHERE id = ?').get(bookId);
  if (!book) throw notFound('图书不存在');
  const reason = unavailableReason(book, userId);
  if (reason) throw conflict(reason, 'BOOK_NOT_AVAILABLE');

  const result = db
    .prepare('INSERT OR IGNORE INTO cart_items (user_id, book_id, quantity) VALUES (?, ?, 1)')
    .run(userId, bookId);
  if (!result.changes) {
    throw conflict('该图书已在购物车中', 'ALREADY_IN_CART');
  }
  return getCart(userId);
}

export function removeCartItem(userId, cartItemId) {
  const result = getDb()
    .prepare('DELETE FROM cart_items WHERE id = ? AND user_id = ?')
    .run(cartItemId, userId);
  if (!result.changes) throw notFound('购物车条目不存在');
  return getCart(userId);
}

export function updateCartItem(userId, cartItemId, quantity) {
  if (Number(quantity) !== 1) {
    throw badRequest('二手书每本仅有一册，数量只能为 1');
  }
  const result = getDb()
    .prepare('UPDATE cart_items SET quantity = 1 WHERE id = ? AND user_id = ?')
    .run(cartItemId, userId);
  if (!result.changes) throw notFound('购物车条目不存在');
  return getCart(userId);
}
