import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { addToCart, getCart, removeCartItem, updateCartItem } from '../services/cart.service.js';
import { success } from '../utils/response.js';
import { parseId } from '../utils/validate.js';
import { validateCartAdd } from '../validators/order.validator.js';

export const cartRouter = Router();
cartRouter.use(requireAuth);

cartRouter.get('/', (req, res) => success(res, getCart(req.user.id), '获取购物车成功'));

cartRouter.post('/', (req, res) => {
  const { bookId } = validateCartAdd(req.body);
  return success(res, addToCart(req.user.id, bookId), '已加入购物车', 201);
});

cartRouter.patch('/:id', (req, res) => {
  const id = parseId(req.params.id, '购物车条目 ID');
  return success(res, updateCartItem(req.user.id, id, req.body.quantity), '购物车已更新');
});

cartRouter.delete('/:id', (req, res) => {
  const id = parseId(req.params.id, '购物车条目 ID');
  return success(res, removeCartItem(req.user.id, id), '已移出购物车');
});
