import request from 'supertest';
import { env } from '../src/config/env.js';
import { getDb } from '../src/database/db.js';
import { resetTestDatabase } from './reset.js';

export const CSRF = { 'X-Requested-With': 'book-island' };

export function resetDb() {
  resetTestDatabase();
}

export async function login(app, identifier, password = env.demoPassword) {
  const agent = request.agent(app);
  const response = await agent.post('/api/auth/login').set(CSRF).send({ identifier, password });
  if (response.status !== 200) {
    throw new Error(`登录失败: ${response.status} ${JSON.stringify(response.body)}`);
  }
  return agent;
}

export async function loginAdmin(app) {
  return login(app, env.admin.email, env.admin.password);
}

export async function findBook(app, title) {
  const response = await request(app).get('/api/books').query({ q: title, pageSize: 50 });
  const items = response.body?.data?.items ?? [];
  return items.find((item) => item.title === title) ?? items[0] ?? null;
}

export function getSeedBook(seedKey) {
  return getDb().prepare('SELECT * FROM books WHERE seed_key = ?').get(seedKey);
}


export async function registerUser(app, overrides = {}) {
  const suffix = Math.random().toString(36).slice(2, 8);
  const payload = {
    username: `tester${suffix}`,
    email: `tester${suffix}@campus.edu`,
    password: 'Tester12345',
    ...overrides,
  };
  const response = await request(app).post('/api/auth/register').set(CSRF).send(payload);
  return { response, payload };
}

export function makeBookPayload(overrides = {}) {
  return {
    title: '测试图书：编译原理',
    author: '测试作者',
    isbn: '9787111111111',
    publisher: '测试出版社',
    publishYear: 2020,
    categoryId: 1,
    originalPrice: 60,
    price: 25,
    condition: 'good',
    description: '用于自动化测试的图书，内页完整。',
    pickupLocation: '图书馆东门',
    ...overrides,
  };
}
