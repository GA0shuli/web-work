import { badRequest } from './AppError.js';

export function requiredString(value, field, { min = 1, max = 200 } = {}) {
  if (typeof value !== 'string') {
    throw badRequest(`${field}不能为空`);
  }
  const trimmed = value.trim();
  if (trimmed.length < min) {
    throw badRequest(min > 1 ? `${field}至少需要 ${min} 个字符` : `${field}不能为空`);
  }
  if (trimmed.length > max) {
    throw badRequest(`${field}不能超过 ${max} 个字符`);
  }
  return trimmed;
}

export function optionalString(value, field, { max = 500 } = {}) {
  if (value === undefined || value === null) return null;
  if (typeof value !== 'string') {
    throw badRequest(`${field}格式不正确`);
  }
  const trimmed = value.trim();
  if (!trimmed) return null;
  if (trimmed.length > max) {
    throw badRequest(`${field}不能超过 ${max} 个字符`);
  }
  return trimmed;
}

export function requiredEmail(value) {
  const email = requiredString(value, '邮箱', { max: 120 }).toLowerCase();
  const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  if (!pattern.test(email)) {
    throw badRequest('请输入有效的邮箱地址');
  }
  return email;
}

export function requiredPassword(value, field = '密码') {
  if (typeof value !== 'string' || value.length < 8 || value.length > 64) {
    throw badRequest(`${field}长度需在 8-64 位之间`);
  }
  if (!/[A-Za-z]/.test(value) || !/\d/.test(value)) {
    throw badRequest(`${field}需同时包含字母和数字`);
  }
  return value;
}

export function parseNumber(value, field, { min = 0, max = Number.MAX_SAFE_INTEGER, required = false } = {}) {
  if (value === undefined || value === null || value === '') {
    if (required) throw badRequest(`${field}不能为空`);
    return null;
  }
  const num = Number(value);
  if (!Number.isFinite(num)) {
    throw badRequest(`${field}必须是数字`);
  }
  if (num < min || num > max) {
    throw badRequest(`${field}需在 ${min} 到 ${max} 之间`);
  }
  return num;
}

export function parseInteger(value, field, options = {}) {
  const num = parseNumber(value, field, options);
  if (num === null) return null;
  if (!Number.isInteger(num)) {
    throw badRequest(`${field}必须是整数`);
  }
  return num;
}

export function parseEnum(value, allowed, field) {
  if (!allowed.includes(value)) {
    throw badRequest(`${field}取值不合法`);
  }
  return value;
}

export function optionalEnum(value, allowed, field, fallback = null) {
  if (value === undefined || value === null || value === '') return fallback;
  return parseEnum(value, allowed, field);
}

export function parseId(value, field = 'ID') {
  const id = parseInteger(value, field, { min: 1, required: true });
  return id;
}

export function parsePagination(query, { defaultPageSize = 12, maxPageSize = 50 } = {}) {
  const page = parseInteger(query.page ?? 1, '页码', { min: 1, max: 100000 }) ?? 1;
  const pageSize = parseInteger(query.pageSize ?? defaultPageSize, '每页数量', {
    min: 1,
    max: maxPageSize,
  }) ?? defaultPageSize;
  return { page, pageSize };
}

export function escapeLike(value) {
  return String(value).replace(/[\\%_]/g, (char) => `\\${char}`);
}

export function normalizeIsbn(value) {
  return String(value ?? '').replace(/[-\s]/g, '').toUpperCase();
}
