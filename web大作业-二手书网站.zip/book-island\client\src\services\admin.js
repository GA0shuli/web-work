import api from './api';

export async function stats() {
  const response = await api.get('/admin/stats');
  return response.data;
}

export async function books(params = {}) {
  const response = await api.get('/admin/books', { params });
  return response.data;
}

export async function reviewBook(id, payload) {
  const response = await api.patch(`/admin/books/${id}/review`, payload);
  return response.data;
}

export async function orders(params = {}) {
  const response = await api.get('/admin/orders', { params });
  return response.data;
}
