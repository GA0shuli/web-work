import { Router } from 'express';
import {
  clearAuthCookie,
  publicUser,
  requireAuth,
  setAuthCookie,
  signToken,
} from '../middleware/auth.js';
import { loginUser, registerUser } from '../services/auth.service.js';
import { success } from '../utils/response.js';
import { validateLogin, validateRegister } from '../validators/auth.validator.js';

export const authRouter = Router();

authRouter.post('/register', (req, res) => {
  const user = registerUser(validateRegister(req.body));
  setAuthCookie(res, signToken(user));
  return success(res, { user }, '注册成功', 201);
});

authRouter.post('/login', (req, res) => {
  const row = loginUser(validateLogin(req.body));
  setAuthCookie(res, signToken(row));
  return success(res, { user: publicUser(row) }, '登录成功');
});

authRouter.post('/logout', (req, res) => {
  clearAuthCookie(res);
  return success(res, null, '已退出登录');
});

authRouter.get('/me', requireAuth, (req, res) => {
  return success(res, { user: publicUser(req.user) }, '获取当前用户成功');
});
