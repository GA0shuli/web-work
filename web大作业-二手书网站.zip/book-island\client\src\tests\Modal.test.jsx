import { useState } from 'react';
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import Modal from '../components/Modal';

function CancelModalHarness() {
  const [open, setOpen] = useState(true);
  const [reason, setReason] = useState('');

  return (
    <Modal
      open={open}
      title="取消订单"
      onClose={() => setOpen(false)}
      footer={<button type="button">确认取消</button>}
    >
      <label htmlFor="reason">取消原因</label>
      <textarea id="reason" value={reason} onChange={(event) => setReason(event.target.value)} />
    </Modal>
  );
}

describe('Modal', () => {
  it('打开时自动聚焦到输入框', () => {
    render(<CancelModalHarness />);
    expect(screen.getByLabelText('取消原因')).toHaveFocus();
  });

  it('连续输入时焦点不会被关闭按钮抢走', async () => {
    const user = userEvent.setup();
    render(<CancelModalHarness />);
    const textarea = screen.getByLabelText('取消原因');

    await user.type(textarea, '时间冲突');

    expect(textarea).toHaveValue('时间冲突');
    expect(textarea).toHaveFocus();
  });

  it('按 Esc 关闭弹窗', async () => {
    const user = userEvent.setup();
    render(<CancelModalHarness />);

    await user.keyboard('{Escape}');

    expect(screen.queryByRole('dialog')).not.toBeInTheDocument();
  });
});
