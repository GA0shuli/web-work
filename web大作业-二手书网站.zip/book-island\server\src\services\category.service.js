import { getDb } from '../database/db.js';

export function listCategories() {
  return getDb()
    .prepare(
      `SELECT c.id, c.name, c.slug, c.description, c.icon, c.sort_order,
              (SELECT COUNT(*) FROM books b
                WHERE b.category_id = c.id
                  AND b.review_status = 'approved'
                  AND b.sale_status = 'available') AS book_count
       FROM categories c
       ORDER BY c.sort_order ASC, c.id ASC`,
    )
    .all()
    .map((row) => ({
      id: row.id,
      name: row.name,
      slug: row.slug,
      description: row.description,
      icon: row.icon,
      bookCount: Number(row.book_count),
    }));
}

export function getPublicStats() {
  const db = getDb();
  const books = db
    .prepare(
      "SELECT COUNT(*) AS count FROM books WHERE review_status = 'approved' AND sale_status = 'available'",
    )
    .get().count;
  const users = db.prepare("SELECT COUNT(*) AS count FROM users WHERE role = 'user'").get().count;
  const completedOrders = db
    .prepare("SELECT COUNT(*) AS count FROM orders WHERE status = 'completed'")
    .get().count;
  const categories = db.prepare('SELECT COUNT(*) AS count FROM categories').get().count;
  const schools = db
    .prepare("SELECT COUNT(DISTINCT campus) AS count FROM users WHERE campus IS NOT NULL AND role = 'user'")
    .get().count;

  return { books, users, completedOrders, categories, campuses: schools };
}
