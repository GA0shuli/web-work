import { useEffect, useRef, useState } from 'react';
import { Link, NavLink, useLocation, useNavigate } from 'react-router-dom';
import {
  ChevronDown,
  LayoutDashboard,
  Library,
  LogIn,
  LogOut,
  Menu,
  ShoppingBag,
  User,
  X,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import { useToast } from '../contexts/ToastContext';
import { Logo } from './common';
import { initials } from '../utils/format';

const NAV_ITEMS = [
  { to: '/', label: '首页', end: true },
  { to: '/books', label: '全部图书' },
  { to: '/recommendations', label: '教材专区' },
  { to: '/publish', label: '发布闲置' },
  { to: '/orders', label: '我的订单' },
];

export default function Navbar() {
  const { user, isAuthenticated, isAdmin, logout, loading: authLoading } = useAuth();
  const { count } = useCart();
  const toast = useToast();
  const navigate = useNavigate();
  const location = useLocation();
  const [menuOpen, setMenuOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const menuRef = useRef(null);

  useEffect(() => {
    setMenuOpen(false);
    setMobileOpen(false);
  }, [location.pathname, location.search]);

  useEffect(() => {
    if (!menuOpen) return undefined;
    const handleClick = (event) => {
      if (menuRef.current && !menuRef.current.contains(event.target)) setMenuOpen(false);
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, [menuOpen]);

  const handleLogout = async () => {
    navigate('/');
    try {
      await logout();
      toast.success('已安全退出登录');
    } catch {
      toast.error('退出登录失败，请稍后重试');
    }
  };

  const redirectToLogin = () => navigate(`/login?redirect=${encodeURIComponent(location.pathname)}`);

  return (
    <header className="navbar">
      <div className="container navbar__inner">
        <Logo />
        <nav className="navbar__nav" aria-label="主导航">
          {NAV_ITEMS.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              end={item.end}
              className={({ isActive }) => `nav-link${isActive ? ' is-active' : ''}`}
            >
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div className="navbar__actions">
          <Link to="/cart" className="icon-button navbar__cart" aria-label={`购物车，${count} 本`}>
            <ShoppingBag size={19} />
            {count > 0 && <span className="badge-dot">{count > 99 ? '99+' : count}</span>}
          </Link>

          {authLoading ? (
            <span className="navbar__auth-skeleton" aria-hidden="true" />
          ) : isAuthenticated ? (
            <div className="user-menu" ref={menuRef}>
              <button
                type="button"
                className="user-menu__trigger"
                onClick={() => setMenuOpen((open) => !open)}
                aria-expanded={menuOpen}
                aria-haspopup="menu"
              >
                <span className="avatar avatar--sm">{initials(user.username)}</span>
                <span className="user-menu__name">{user.username}</span>
                <ChevronDown size={15} className={menuOpen ? 'is-rotated' : ''} />
              </button>
              {menuOpen && (
                <div className="user-menu__dropdown" role="menu">
                  <div className="user-menu__header">
                    <strong>{user.username}</strong>
                    <span>{user.email}</span>
                  </div>
                  <Link to="/profile" role="menuitem">
                    <User size={16} /> 个人中心
                  </Link>
                  <Link to="/orders" role="menuitem">
                    <Library size={16} /> 我的订单
                  </Link>
                  {isAdmin && (
                    <Link to="/admin" role="menuitem">
                      <LayoutDashboard size={16} /> 管理后台
                    </Link>
                  )}
                  <button type="button" role="menuitem" onClick={handleLogout}>
                    <LogOut size={16} /> 退出登录
                  </button>
                </div>
              )}
            </div>
          ) : (
            <div className="navbar__auth">
              <button type="button" className="button button--ghost button--sm" onClick={redirectToLogin}>
                登录
              </button>
              <Link to="/register" className="button button--primary button--sm">
                注册
              </Link>
            </div>
          )}

          <button
            type="button"
            className="icon-button navbar__toggle"
            onClick={() => setMobileOpen((open) => !open)}
            aria-label={mobileOpen ? '关闭菜单' : '打开菜单'}
            aria-expanded={mobileOpen}
          >
            {mobileOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {mobileOpen && (
        <div className="navbar__mobile">
          <nav aria-label="移动端导航">
            {NAV_ITEMS.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.end}
                className={({ isActive }) => `nav-link${isActive ? ' is-active' : ''}`}
              >
                {item.label}
              </NavLink>
            ))}
            <Link to="/cart" className="nav-link">
              购物车{count > 0 ? `（${count}）` : ''}
            </Link>
          </nav>
          {!isAuthenticated ? (
            <div className="navbar__mobile-auth">
              <Link to="/login" className="button button--secondary button--block">
                <LogIn size={16} /> 登录
              </Link>
              <Link to="/register" className="button button--primary button--block">
                注册
              </Link>
            </div>
          ) : (
            <div className="navbar__mobile-auth">
              <Link to="/profile" className="button button--secondary button--block">
                <User size={16} /> 个人中心
              </Link>
              {isAdmin && (
                <Link to="/admin" className="button button--secondary button--block">
                  <LayoutDashboard size={16} /> 管理后台
                </Link>
              )}
              <button type="button" className="button button--ghost button--block" onClick={handleLogout}>
                <LogOut size={16} /> 退出登录
              </button>
            </div>
          )}
        </div>
      )}
    </header>
  );
}
