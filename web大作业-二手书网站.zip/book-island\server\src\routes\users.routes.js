import { Router } from 'express';
import { attachUser, requireAuth } from '../middleware/auth.js';
import {
  getMyBooks,
  getUserProfile,
  updateUserProfile,
} from '../services/user.service.js';
import { notFound } from '../utils/AppError.js';
import { success } from '../utils/response.js';
import { parseId, parsePagination } from '../utils/validate.js';
import { validateProfileUpdate } from '../validators/auth.validator.js';

export const userRouter = Router();

userRouter.get('/me', requireAuth, (req, res) => {
  return success(res, getUserProfile(req.user.id, req.user), '获取个人资料成功');
});

userRouter.patch('/me', requireAuth, (req, res) => {
  const update = validateProfileUpdate(req.body);
  return success(res, updateUserProfile(req.user.id, update, req.user), '个人资料已更新');
});

userRouter.get('/me/books', requireAuth, (req, res) => {
  const { page, pageSize } = parsePagination(req.query);
  return success(res, getMyBooks(req.user.id, { page, pageSize }), '获取我的发布成功');
});


userRouter.get('/:id', attachUser, (req, res) => {
  const id = parseId(req.params.id, '用户 ID');
  const profile = getUserProfile(id, req.user);
  if (!profile) throw notFound('用户不存在');
  return success(res, profile, '获取用户主页成功');
});
