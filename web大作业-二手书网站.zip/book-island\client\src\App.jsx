import { lazy, Suspense } from 'react';
import { BrowserRouter, Route, Routes } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { CartProvider } from './contexts/CartContext';
import { ToastProvider } from './contexts/ToastContext';
import MainLayout from './layouts/MainLayout';
import RouteGuard from './components/RouteGuard';
import HomePage from './pages/HomePage';
import BooksPage from './pages/BooksPage';
import BookDetailPage from './pages/BookDetailPage';
import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import PublishBookPage from './pages/PublishBookPage';
import CartPage from './pages/CartPage';
import OrdersPage from './pages/OrdersPage';
import ProfilePage from './pages/ProfilePage';
import RecommendationPage from './pages/RecommendationPage';
import NotFoundPage from './pages/NotFoundPage';
import { LoadingSpinner } from './components/common';

const AdminPage = lazy(() => import('./pages/AdminPage'));

export default function App() {
  return (
    <ToastProvider>
      <AuthProvider>
        <CartProvider>
          <BrowserRouter>
            <Routes>
              <Route path="/login" element={<LoginPage />} />
              <Route path="/register" element={<RegisterPage />} />

              <Route element={<MainLayout />}>
                <Route index element={<HomePage />} />
                <Route path="books" element={<BooksPage />} />
                <Route path="books/:id" element={<BookDetailPage />} />
                <Route path="recommendations" element={<RecommendationPage />} />

                <Route element={<RouteGuard />}>
                  <Route path="publish" element={<PublishBookPage />} />
                  <Route path="books/:id/edit" element={<PublishBookPage />} />
                  <Route path="cart" element={<CartPage />} />
                  <Route path="orders" element={<OrdersPage />} />
                  <Route path="profile" element={<ProfilePage />} />
                </Route>

                <Route element={<RouteGuard admin />}>
                  <Route
                    path="admin"
                    element={
                      <Suspense
                        fallback={
                          <div className="container page-section">
                            <LoadingSpinner fullScreen label="正在加载管理后台…" />
                          </div>
                        }
                      >
                        <AdminPage />
                      </Suspense>
                    }
                  />
                </Route>

                <Route path="*" element={<NotFoundPage />} />
              </Route>
            </Routes>
          </BrowserRouter>
        </CartProvider>
      </AuthProvider>
    </ToastProvider>
  );
}
