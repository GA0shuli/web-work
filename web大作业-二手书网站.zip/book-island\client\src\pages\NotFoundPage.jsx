import { Link } from 'react-router-dom';
import { ArrowLeft, BookX } from 'lucide-react';
import { useDocumentTitle } from '../hooks/useDocumentTitle';

export default function NotFoundPage() {
  useDocumentTitle('页面不存在');
  return (
    <div className="container page-section">
      <div className="not-found">
        <span className="not-found__icon">
          <BookX size={40} />
        </span>
        <span className="eyebrow eyebrow--plain">404</span>
        <h1>这一页好像被夹进了别的书里</h1>
        <p>你访问的页面不存在，或者图书已经被下架。</p>
        <div className="not-found__actions">
          <Link to="/" className="button button--primary">
            <ArrowLeft size={16} /> 返回首页
          </Link>
          <Link to="/books" className="button button--secondary">
            浏览全部图书
          </Link>
        </div>
      </div>
    </div>
  );
}
