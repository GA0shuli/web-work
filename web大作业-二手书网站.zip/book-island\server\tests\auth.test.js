import { beforeEach, describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../src/app.js';
import { CSRF, registerUser, resetDb } from './helpers.js';

const app = createApp();

beforeEach(() => {
  resetDb();
});

describe('注册与登录', () => {
  it('注册成功后写入 HttpOnly Cookie，响应中不包含密码哈希', async () => {
    const agent = request.agent(app);
    const response = await agent.post('/api/auth/register').set(CSRF).send({
      username: 'newreader',
      email: 'newreader@campus.edu',
      password: 'Newreader12345',
    });

    expect(response.status).toBe(201);
    expect(response.body.data.user.username).toBe('newreader');
    expect(JSON.stringify(response.body)).not.toContain('passwordHash');
    expect(response.headers['set-cookie'].join(';')).toContain('HttpOnly');

    const me = await agent.get('/api/auth/me');
    expect(me.status).toBe(200);
    expect(me.body.data.user.email).toBe('newreader@campus.edu');
  });

  it('重复邮箱返回 409，弱密码返回 400', async () => {
    const first = await registerUser(app, {
      username: 'dupuser',
      email: 'dup@campus.edu',
      password: 'Dup123456',
    });
    expect(first.response.status).toBe(201);

    const duplicate = await registerUser(app, { email: 'dup@campus.edu' });
    expect(duplicate.response.status).toBe(409);

    const weak = await registerUser(app, { password: '12345678' });
    expect(weak.response.status).toBe(400);
  });

  it('登录成功、密码错误与退出登录', async () => {
    const agent = request.agent(app);
    const success = await agent
      .post('/api/auth/login')
      .set(CSRF)
      .send({ identifier: 'linxi@campus.edu', password: 'Demo@12345' });
    expect(success.status).toBe(200);
    expect(success.body.data.user.username).toBe('linxi');

    const wrong = await request(app)
      .post('/api/auth/login')
      .set(CSRF)
      .send({ identifier: 'linxi@campus.edu', password: 'WrongPass123' });
    expect(wrong.status).toBe(401);

    const logout = await agent.post('/api/auth/logout');
    expect(logout.status).toBe(200);
    expect((await agent.get('/api/auth/me')).status).toBe(401);
  });

  it('未登录访问购物车和订单返回 401', async () => {
    expect((await request(app).get('/api/cart')).status).toBe(401);
    expect((await request(app).get('/api/orders')).status).toBe(401);
  });
});
