import { beforeEach, describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../src/app.js';
import { CSRF, login, makeBookPayload, resetDb } from './helpers.js';

const app = createApp();

beforeEach(() => {
  resetDb();
});

describe('图书浏览与搜索', () => {
  it('公开列表只返回审核通过且可交易的图书，并返回分页信息', async () => {
    const response = await request(app).get('/api/books').query({ pageSize: 50 });
    expect(response.status).toBe(200);
    expect(response.body.data.items).toHaveLength(16);
    expect(
      response.body.data.items.every(
        (item) => item.reviewStatus === 'approved' && item.saleStatus === 'available',
      ),
    ).toBe(true);
    expect(response.body.data.pagination).toMatchObject({ total: 16, totalPages: 1 });
  });

  it('关键词、分类、价格、成色筛选和排序都会生效', async () => {
    const search = await request(app).get('/api/books').query({ q: '数据结构' });
    expect(search.body.data.items[0].title).toContain('数据结构');

    const category = await request(app).get('/api/books').query({ category: 'math', pageSize: 50 });
    expect(category.body.data.items).toHaveLength(2);
    expect(category.body.data.items.every((item) => item.category.slug === 'math')).toBe(true);

    const price = await request(app)
      .get('/api/books')
      .query({ minPrice: 15, maxPrice: 30, pageSize: 50 });
    expect(price.body.data.items.every((item) => item.price >= 15 && item.price <= 30)).toBe(true);

    const sorted = await request(app).get('/api/books').query({ sort: 'price_asc', pageSize: 50 });
    const prices = sorted.body.data.items.map((item) => item.price);
    expect(prices).toEqual([...prices].sort((a, b) => a - b));
  });

  it('发布图书需要登录，成功后进入待审核并做后端校验', async () => {
    const anonymous = await request(app).post('/api/books').set(CSRF).send(makeBookPayload());
    expect(anonymous.status).toBe(401);

    const agent = await login(app, 'linxi@campus.edu');
    const created = await agent.post('/api/books').set(CSRF).send(makeBookPayload());
    expect(created.status).toBe(201);
    expect(created.body.data.reviewStatus).toBe('pending');
    expect(created.body.data.seller.username).toBe('linxi');

    const invalidPrice = await agent
      .post('/api/books')
      .set(CSRF)
      .send(makeBookPayload({ price: 80, originalPrice: 50 }));
    expect(invalidPrice.status).toBe(400);
  });

  it('教材推荐支持关键词与 ISBN 匹配，预算和成色是硬性条件', async () => {
    const byKeyword = await request(app)
      .get('/api/books/recommendations')
      .query({ q: '数据结构', maxPrice: 100, limit: 10 });
    expect(byKeyword.status).toBe(200);
    expect(byKeyword.body.data.items[0].title).toContain('数据结构');
    expect(byKeyword.body.data.items[0].scoreBreakdown).toEqual(
      expect.objectContaining({ keyword: expect.any(Number) }),
    );

    const byIsbn = await request(app)
      .get('/api/books/recommendations')
      .query({ q: '9787111407010', limit: 5 });
    expect(byIsbn.body.data.items[0].reasons).toContain('ISBN 完全匹配');

    const budget = await request(app)
      .get('/api/books/recommendations')
      .query({ maxPrice: 15, limit: 30 });
    expect(budget.body.data.items.every((item) => item.price <= 15)).toBe(true);
  });
});
