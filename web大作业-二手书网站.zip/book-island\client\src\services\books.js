import api from './api';

export async function list(params = {}) {
  const response = await api.get('/books', { params });
  return response.data;
}

export async function detail(id) {
  const response = await api.get(`/books/${id}`);
  return response.data;
}

export async function recommendations(params = {}) {
  const response = await api.get('/books/recommendations', { params });
  return response.data;
}

export async function similar(id, params = {}) {
  const response = await api.get(`/books/${id}/similar`, { params });
  return response.data;
}

export async function create(formData) {
  const response = await api.post('/books', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return response.data;
}

export async function update(id, formData) {
  const response = await api.patch(`/books/${id}`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return response.data;
}

export async function offline(id) {
  const response = await api.delete(`/books/${id}`);
  return response.data;
}
