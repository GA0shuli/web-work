import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import { env } from './config/env.js';
import { apiRouter } from './routes/index.js';
import { apiLimiter } from './middleware/rateLimits.js';
import { errorHandler, notFoundHandler } from './middleware/error.js';
import { AppError } from './utils/AppError.js';

export function createApp() {
  const app = express();

  app.disable('x-powered-by');
  if (env.isProduction) app.set('trust proxy', 1);

  app.use(
    helmet({
      contentSecurityPolicy: {
        directives: {
          defaultSrc: ["'self'"],
          scriptSrc: ["'self'"],
          styleSrc: ["'self'", "'unsafe-inline'"],
          imgSrc: ["'self'", 'data:', 'blob:'],
          fontSrc: ["'self'", 'data:'],
          connectSrc: ["'self'"],
          objectSrc: ["'none'"],
          frameAncestors: ["'none'"],
          baseUri: ["'self'"],
          formAction: ["'self'"],
        },
      },
      crossOriginResourcePolicy: { policy: 'cross-origin' },
    }),
  );

  app.use(
    cors({
      origin(origin, callback) {
        if (!origin || env.clientOrigins.includes(origin)) {
          return callback(null, true);
        }
        // 开发环境允许本机任意端口（Vite 端口被占用时会自动顺延到 5174、5175…）
        const isLocal = /^http:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(origin);
        if (!env.isProduction && isLocal) {
          return callback(null, true);
        }
        return callback(
          new AppError(403, `该来源不在允许访问的名单中：${origin}`, 'CORS_FORBIDDEN'),
        );
      },
      credentials: true,
      methods: ['GET', 'POST', 'PATCH', 'PUT', 'DELETE', 'OPTIONS'],
      allowedHeaders: ['Content-Type'],
      maxAge: 86400,
    }),
  );

  app.use(express.json({ limit: '1mb' }));
  app.use(express.urlencoded({ extended: false, limit: '1mb' }));
  app.use(cookieParser());

  app.use(
    '/uploads',
    express.static(env.uploadsDir, {
      maxAge: '7d',
      fallthrough: true,
      index: false,
      setHeaders(res) {
        res.setHeader('X-Content-Type-Options', 'nosniff');
      },
    }),
  );
  app.use('/uploads', (req, res) => {
    res.status(404).end();
  });

  app.use('/api', apiLimiter, apiRouter);
  app.use('/api', notFoundHandler);

  const clientIndex = path.join(env.clientDistDir, 'index.html');
  if (fs.existsSync(clientIndex)) {
    app.use(
      express.static(env.clientDistDir, {
        index: false,
        maxAge: '1h',
      }),
    );
    app.get('*', (req, res) => {
      res.sendFile(clientIndex);
    });
  }

  app.use(notFoundHandler);
  app.use(errorHandler);

  return app;
}
