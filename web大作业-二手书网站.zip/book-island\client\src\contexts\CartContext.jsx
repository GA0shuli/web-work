import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { getCart } from '../services/cart';
import { useAuth } from './AuthContext';

const CartContext = createContext(null);

export function CartProvider({ children }) {
  const { user, loading } = useAuth();
  const [count, setCount] = useState(0);
  const [refreshing, setRefreshing] = useState(false);

  const refresh = useCallback(async () => {
    if (!user) {
      setCount(0);
      return 0;
    }
    setRefreshing(true);
    try {
      const data = await getCart();
      setCount(data.summary.totalItems);
      return data.summary.totalItems;
    } catch {
      setCount(0);
      return 0;
    } finally {
      setRefreshing(false);
    }
  }, [user]);

  useEffect(() => {
    if (!loading) refresh();
  }, [loading, refresh]);

  const value = useMemo(
    () => ({ count, refreshing, refresh, setCount }),
    [count, refreshing, refresh],
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const context = useContext(CartContext);
  if (!context) throw new Error('useCart 必须在 CartProvider 内使用');
  return context;
}
