import bcrypt from 'bcryptjs';
import { getDb } from '../database/db.js';
import { conflict, unauthorized } from '../utils/AppError.js';
import { publicUser } from '../middleware/auth.js';
import { listBooks } from './book.service.js';

const SALT_ROUNDS = 11;

export function getUserProfile(userId, viewer = null) {
  const db = getDb();
  const row = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
  if (!row) return null;

  const myBooks = db.prepare('SELECT COUNT(*) AS c FROM books WHERE seller_id = ?').get(userId).c;
  const availableBooks = db
    .prepare(
      "SELECT COUNT(*) AS c FROM books WHERE seller_id = ? AND review_status = 'approved' AND sale_status = 'available'",
    )
    .get(userId).c;
  const pendingBooks = db
    .prepare("SELECT COUNT(*) AS c FROM books WHERE seller_id = ? AND review_status = 'pending'")
    .get(userId).c;
  const soldBooks = db
    .prepare("SELECT COUNT(*) AS c FROM books WHERE seller_id = ? AND sale_status = 'sold'")
    .get(userId).c;

  const bought = db
    .prepare(
      "SELECT COUNT(*) AS count, COALESCE(SUM(total_amount), 0) AS amount FROM orders WHERE buyer_id = ? AND status = 'completed'",
    )
    .get(userId);
  const sold = db
    .prepare(
      "SELECT COUNT(*) AS count, COALESCE(SUM(total_amount), 0) AS amount FROM orders WHERE seller_id = ? AND status = 'completed'",
    )
    .get(userId);
  const activeOrders = db
    .prepare(
      "SELECT COUNT(*) AS c FROM orders WHERE (buyer_id = ? OR seller_id = ?) AND status IN ('pending_seller', 'in_progress')",
    )
    .get(userId, userId).c;

  const isSelf = viewer?.id === userId || viewer?.role === 'admin';

  return {
    ...publicUser(row),
    ...(isSelf ? { email: row.email } : { email: null }),
    stats: {
      myBooks,
      availableBooks,
      pendingBooks,
      soldBooks,
      boughtOrders: Number(bought.count),
      spent: Number(Number(bought.amount).toFixed(2)),
      soldOrders: Number(sold.count),
      earned: Number(Number(sold.amount).toFixed(2)),
      activeOrders,
    },
  };
}

export function updateUserProfile(userId, update, viewer) {
  const db = getDb();
  const current = db.prepare('SELECT * FROM users WHERE id = ?').get(userId);
  if (!current) return null;

  const fields = [];
  const params = { id: userId };

  if (update.username !== undefined) {
    const conflictRow = db
      .prepare('SELECT id FROM users WHERE lower(username) = lower(?) AND id <> ?')
      .get(update.username, userId);
    if (conflictRow) throw conflict('该用户名已被使用', 'USERNAME_EXISTS');
    fields.push('username = @username');
    params.username = update.username;
  }
  if (update.email !== undefined) {
    const conflictRow = db
      .prepare('SELECT id FROM users WHERE lower(email) = lower(?) AND id <> ?')
      .get(update.email, userId);
    if (conflictRow) throw conflict('该邮箱已被使用', 'EMAIL_EXISTS');
    fields.push('email = @email');
    params.email = update.email.toLowerCase();
  }
  if (update.bio !== undefined) {
    fields.push('bio = @bio');
    params.bio = update.bio;
  }
  if (update.campus !== undefined) {
    fields.push('campus = @campus');
    params.campus = update.campus;
  }
  if (update.newPassword) {
    if (!bcrypt.compareSync(update.currentPassword, current.password_hash)) {
      throw unauthorized('当前密码不正确');
    }
    fields.push('password_hash = @passwordHash');
    params.passwordHash = bcrypt.hashSync(update.newPassword, SALT_ROUNDS);
  }

  if (fields.length) {
    db.prepare(
      `UPDATE users SET ${fields.join(', ')}, updated_at = @updatedAt WHERE id = @id`,
    ).run({ ...params, updatedAt: new Date().toISOString() });
  }
  return getUserProfile(userId, viewer ?? current);
}

export function getMyBooks(userId, { page = 1, pageSize = 12 } = {}) {
  return listBooks({
    viewerId: userId,
    sellerId: userId,
    includeAllStatuses: true,
    page,
    pageSize,
    sort: 'newest',
  });
}

