import { useEffect, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import {
  BookOpen,
  Loader2,
  MapPin,
  Pencil,
  Save,
  Star,
  Trash2,
  UserRound,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import * as usersApi from '../services/users';
import * as booksApi from '../services/books';
import { EmptyState, ErrorMessage, LoadingSpinner, StatusBadge } from '../components/common';
import BookCard from '../components/BookCard';
import Modal from '../components/Modal';
import { useDocumentTitle } from '../hooks/useDocumentTitle';
import { formatDate, formatPrice, getCoverUrl, handleCoverError, initials } from '../utils/format';

const TABS = [
  { key: 'profile', label: '个人资料' },
  { key: 'books', label: '我的发布' },
  { key: 'stats', label: '交易统计' },
];

export default function ProfilePage() {
  useDocumentTitle('个人中心');
  const { user, refresh: refreshAuth } = useAuth();
  const toast = useToast();
  const [searchParams, setSearchParams] = useSearchParams();
  const initialTab = TABS.some((item) => item.key === searchParams.get('tab'))
    ? searchParams.get('tab')
    : 'profile';

  const [tab, setTab] = useState(initialTab);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [reloadKey, setReloadKey] = useState(0);

  const [form, setForm] = useState({ username: '', email: '', campus: '', bio: '', currentPassword: '', newPassword: '' });
  const [formError, setFormError] = useState('');
  const [saving, setSaving] = useState(false);

  const [myBooks, setMyBooks] = useState([]);
  const [booksLoading, setBooksLoading] = useState(false);
  const [booksError, setBooksError] = useState(null);
  const [offlineTarget, setOfflineTarget] = useState(null);
  const [offlineBusy, setOfflineBusy] = useState(false);


  useEffect(() => {
    let active = true;
    setLoading(true);
    setError(null);
    usersApi
      .me()
      .then((data) => {
        if (!active) return;
        setProfile(data);
        setForm({
          username: data.username ?? '',
          email: data.email ?? '',
          campus: data.campus ?? '',
          bio: data.bio ?? '',
          currentPassword: '',
          newPassword: '',
        });
      })
      .catch((loadError) => {
        if (active) setError(loadError.message);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [reloadKey]);

  useEffect(() => {
    const fromUrl = searchParams.get('tab');
    if (fromUrl && fromUrl !== tab && TABS.some((item) => item.key === fromUrl)) {
      setTab(fromUrl);
    }
  }, [searchParams, tab]);

  useEffect(() => {
    if (tab !== 'books') return undefined;
    let active = true;
    setBooksLoading(true);
    setBooksError(null);
    usersApi
      .myBooks({ pageSize: 50 })
      .then((data) => {
        if (active) setMyBooks(data.items);
      })
      .catch((loadError) => {
        if (active) setBooksError(loadError.message);
      })
      .finally(() => {
        if (active) setBooksLoading(false);
      });
    return () => {
      active = false;
    };
  }, [tab, reloadKey]);

  const changeTab = (next) => {
    setTab(next);
    setSearchParams(next === 'profile' ? {} : { tab: next });
  };

  const update = (field) => (event) => {
    setForm((current) => ({ ...current, [field]: event.target.value }));
    setFormError('');
  };

  const saveProfile = async (event) => {
    event.preventDefault();
    setFormError('');
    if (!form.username.trim()) {
      setFormError('用户名不能为空');
      return;
    }
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(form.email.trim())) {
      setFormError('请输入有效的邮箱地址');
      return;
    }
    if (form.newPassword && form.newPassword.length < 8) {
      setFormError('新密码至少需要 8 位');
      return;
    }
    setSaving(true);
    try {
      const payload = {
        username: form.username.trim(),
        email: form.email.trim(),
        campus: form.campus.trim(),
        bio: form.bio.trim(),
      };
      if (form.newPassword) {
        payload.currentPassword = form.currentPassword;
        payload.newPassword = form.newPassword;
      }
      const data = await usersApi.updateMe(payload);
      setProfile(data);
      setForm((current) => ({ ...current, currentPassword: '', newPassword: '' }));
      await refreshAuth();
      toast.success('个人资料已更新');
    } catch (saveError) {
      setFormError(saveError.message);
    } finally {
      setSaving(false);
    }
  };

  const confirmOffline = async () => {
    if (!offlineTarget) return;
    setOfflineBusy(true);
    try {
      await booksApi.offline(offlineTarget.id);
      toast.success('图书已下架');
      setMyBooks((current) =>
        current.map((book) =>
          book.id === offlineTarget.id ? { ...book, saleStatus: 'offline', saleStatusLabel: '已下架' } : book,
        ),
      );
      if (offlineTarget.reviewStatus === 'approved' && offlineTarget.saleStatus === 'available') {
        setProfile((current) =>
          current
            ? {
                ...current,
                stats: {
                  ...current.stats,
                  availableBooks: Math.max(0, current.stats.availableBooks - 1),
                },
              }
            : current,
        );
      }
      setOfflineTarget(null);
    } catch (offlineError) {
      toast.error(offlineError.message);
    } finally {
      setOfflineBusy(false);
    }
  };

  if (loading) {
    return (
      <div className="container page-section">
        <LoadingSpinner label="正在加载个人中心…" />
      </div>
    );
  }

  if (error || !profile) {
    return (
      <div className="container page-section">
        <ErrorMessage message={error ?? '无法加载个人资料'} onRetry={() => setReloadKey((key) => key + 1)} />
      </div>
    );
  }

  const stats = profile.stats;

  return (
    <div className="container page-section">
      <header className="profile-header">
        <span className="avatar avatar--xl">{initials(profile.username)}</span>
        <div className="profile-header__info">
          <span className="eyebrow eyebrow--plain">我的书屿</span>
          <h1>{profile.username}</h1>
          <p>
            {profile.campus ? (
              <>
                <MapPin size={14} /> {profile.campus} ·{' '}
              </>
            ) : null}
            {profile.bio || '还没有填写个人简介'}
          </p>
          <div className="profile-header__rating">
            <span className="pill pill--outline">加入于 {formatDate(profile.createdAt)}</span>
          </div>
        </div>
        <div className="profile-header__stats">
          <div>
            <b>{stats.availableBooks}</b>
            <span>在售</span>
          </div>
          <div>
            <b>{stats.soldBooks}</b>
            <span>已售</span>
          </div>
          <div>
            <b>{stats.boughtOrders}</b>
            <span>买到</span>
          </div>
        </div>
      </header>

      <div className="tabs" role="tablist" aria-label="个人中心导航">
        {TABS.map((item) => (
          <button
            key={item.key}
            type="button"
            role="tab"
            aria-selected={tab === item.key}
            className={`tab${tab === item.key ? ' is-active' : ''}`}
            onClick={() => changeTab(item.key)}
          >
            {item.label}
          </button>
        ))}
      </div>

      {tab === 'profile' && (
        <div className="profile-grid">
          <form className="panel form-stack" onSubmit={saveProfile} noValidate>
            <h2>
              <UserRound size={19} /> 编辑资料
            </h2>
            {formError && (
              <div className="alert alert--danger" role="alert">
                {formError}
              </div>
            )}
            <div className="form-grid">
              <div className="field">
                <label htmlFor="profile-username">用户名</label>
                <input id="profile-username" value={form.username} onChange={update('username')} maxLength={20} />
              </div>
              <div className="field">
                <label htmlFor="profile-email">邮箱</label>
                <input id="profile-email" type="email" value={form.email} onChange={update('email')} maxLength={120} />
              </div>
              <div className="field field--full">
                <label htmlFor="profile-campus">校区</label>
                <input id="profile-campus" value={form.campus} onChange={update('campus')} maxLength={60} placeholder="例如 南湖校区" />
              </div>
              <div className="field field--full">
                <label htmlFor="profile-bio">个人简介</label>
                <textarea id="profile-bio" rows={3} value={form.bio} onChange={update('bio')} maxLength={200} placeholder="介绍一下你的专业和常去的自提地点" />
                <p className="field-hint">{form.bio.length} / 200 字</p>
              </div>
            </div>

            <h3 className="form-subheading">修改密码</h3>
            <div className="form-grid">
              <div className="field">
                <label htmlFor="current-password">当前密码</label>
                <input
                  id="current-password"
                  type="password"
                  autoComplete="current-password"
                  value={form.currentPassword}
                  onChange={update('currentPassword')}
                  placeholder="修改密码时填写"
                />
              </div>
              <div className="field">
                <label htmlFor="new-password">新密码</label>
                <input
                  id="new-password"
                  type="password"
                  autoComplete="new-password"
                  value={form.newPassword}
                  onChange={update('newPassword')}
                  placeholder="至少 8 位，包含字母和数字"
                />
              </div>
            </div>

            <button type="submit" className="button button--primary" disabled={saving}>
              {saving ? <Loader2 size={16} className="loading__icon" /> : <Save size={16} />}
              {saving ? '正在保存…' : '保存资料'}
            </button>
          </form>

          <aside className="panel profile-summary">
            <h3>我的交易足迹</h3>
            <dl>
              <div>
                <dt>累计买入</dt>
                <dd>{stats.boughtOrders} 笔 · {formatPrice(stats.spent, { exact: true })}</dd>
              </div>
              <div>
                <dt>累计卖出</dt>
                <dd>{stats.soldOrders} 笔 · {formatPrice(stats.earned, { exact: true })}</dd>
              </div>
              <div>
                <dt>进行中的订单</dt>
                <dd>{stats.activeOrders} 笔</dd>
              </div>
              <div>
                <dt>待审核图书</dt>
                <dd>{stats.pendingBooks} 本</dd>
              </div>
            </dl>
            <p className="panel__hint">
              交易统计来自真实订单与图书数据，订单完成后自动更新。
            </p>
            <Link to="/orders" className="button button--secondary button--block">
              查看我的订单
            </Link>
          </aside>
        </div>
      )}

      {tab === 'books' && (
        <section className="panel">
          <div className="panel__heading">
            <h2>
              <BookOpen size={19} /> 我的发布
            </h2>
            <Link to="/publish" className="button button--primary button--sm">
              发布新书
            </Link>
          </div>
          {booksLoading ? (
            <LoadingSpinner label="正在读取我的发布…" />
          ) : booksError ? (
            <ErrorMessage message={booksError} onRetry={() => setReloadKey((key) => key + 1)} />
          ) : myBooks.length === 0 ? (
            <EmptyState
              icon={BookOpen}
              title="还没有发布图书"
              description="整理一下书架，把闲置教材发布到书屿吧。"
              action={
                <Link to="/publish" className="button button--primary">
                  发布闲置
                </Link>
              }
            />
          ) : (
            <div className="my-books">
              {myBooks.map((book) => (
                <article className="my-book" key={book.id}>
                  <Link to={`/books/${book.id}`} className="my-book__cover">
                    <img src={getCoverUrl(book.coverPath)} alt={`《${book.title}》封面`} onError={handleCoverError} />
                  </Link>
                  <div className="my-book__info">
                    <Link to={`/books/${book.id}`} className="my-book__title">
                      {book.title}
                    </Link>
                    <p className="muted">{book.author}</p>
                    <div className="my-book__badges">
                      <StatusBadge type="review" status={book.reviewStatus} />
                      <StatusBadge type="sale" status={book.saleStatus} />
                      <span className="pill pill--outline">{book.category?.name}</span>
                    </div>
                    {book.reviewStatus === 'rejected' && book.reviewNote && (
                      <p className="field-error">驳回原因：{book.reviewNote}</p>
                    )}
                  </div>
                  <div className="my-book__side">
                    <strong className="price">{formatPrice(book.price)}</strong>
                    <span className="muted">{formatDate(book.createdAt)}</span>
                    <div className="my-book__actions">
                      <Link to={`/books/${book.id}/edit`} className="button button--secondary button--sm">
                        <Pencil size={14} /> 编辑
                      </Link>
                      {book.saleStatus !== 'offline' && book.saleStatus !== 'sold' && (
                        <button
                          type="button"
                          className="button button--ghost button--sm"
                          onClick={() => setOfflineTarget(book)}
                          disabled={book.saleStatus === 'reserved'}
                        >
                          <Trash2 size={14} /> 下架
                        </button>
                      )}
                    </div>
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>
      )}

      {tab === 'stats' && (
        <section>
          <div className="stat-grid">
            <div className="stat-card">
              <span>发布图书</span>
              <b>{stats.myBooks}</b>
              <small>{stats.availableBooks} 本在售 · {stats.pendingBooks} 本待审核</small>
            </div>
            <div className="stat-card">
              <span>买入订单</span>
              <b>{stats.boughtOrders}</b>
              <small>累计花费 {formatPrice(stats.spent, { exact: true })}</small>
            </div>
            <div className="stat-card">
              <span>卖出订单</span>
              <b>{stats.soldOrders}</b>
              <small>累计收入 {formatPrice(stats.earned, { exact: true })}</small>
            </div>
          </div>
        </section>
      )}

      <Modal
        open={Boolean(offlineTarget)}
        title="确认下架这本书？"
        onClose={() => !offlineBusy && setOfflineTarget(null)}
        footer={
          <>
            <button type="button" className="button button--ghost" onClick={() => setOfflineTarget(null)} disabled={offlineBusy}>
              取消
            </button>
            <button type="button" className="button button--danger" onClick={confirmOffline} disabled={offlineBusy}>
              {offlineBusy ? '正在下架…' : '确认下架'}
            </button>
          </>
        }
      >
        <p>《{offlineTarget?.title}》下架后不会再出现在公开列表中，已有订单不受影响。</p>
      </Modal>
    </div>
  );
}
