import { Link, Navigate, Outlet, useLocation } from 'react-router-dom';
import { ShieldAlert } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { EmptyState, LoadingSpinner } from './common';

// admin 为 true 时额外校验管理员角色，其余情况和普通登录守卫一样
export default function RouteGuard({ admin = false }) {
  const { isAuthenticated, isAdmin, loading } = useAuth();
  const location = useLocation();

  if (loading) {
    return <LoadingSpinner fullScreen label={admin ? '正在验证管理员身份…' : '正在确认登录状态…'} />;
  }
  if (!isAuthenticated) {
    const redirect = encodeURIComponent(`${location.pathname}${location.search}`);
    return <Navigate to={`/login?redirect=${redirect}`} replace />;
  }
  if (admin && !isAdmin) {
    return (
      <div className="container page-section">
        <EmptyState
          icon={ShieldAlert}
          title="无权访问管理后台"
          description="该区域仅对平台管理员开放，前端路由与后端接口都会校验管理员角色。"
          action={
            <Link to="/" className="button button--primary">
              返回首页
            </Link>
          }
        />
      </div>
    );
  }
  return <Outlet />;
}
