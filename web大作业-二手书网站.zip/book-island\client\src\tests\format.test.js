import { describe, expect, it } from 'vitest';
import {
  conditionLabel,
  discountPercent,
  formatPrice,
  getCoverUrl,
  relativeTime,
} from '../utils/format';

describe('格式化工具', () => {
  it('价格格式化保留必要的小数位', () => {
    expect(formatPrice(18)).toBe('¥18');
    expect(formatPrice(18.5)).toBe('¥18.50');
    expect(formatPrice(18.5, { exact: true })).toBe('¥18.50');
    expect(formatPrice(Number.NaN)).toBe('—');
  });

  it('计算相对原价的折扣百分比', () => {
    expect(discountPercent(100, 60)).toBe(40);
    expect(discountPercent(39.5, 18)).toBe(54);
    expect(discountPercent(20, 30)).toBeNull();
    expect(discountPercent(null, 10)).toBeNull();
  });

  it('成色标签与封面回退地址正确', () => {
    expect(conditionLabel('like_new')).toBe('近全新');
    expect(conditionLabel('good')).toBe('良好');
    expect(conditionLabel('unknown')).toBe('unknown');
    expect(getCoverUrl(null)).toBe('/covers/default.svg');
    expect(getCoverUrl('/covers/seed-01.svg')).toBe('/covers/seed-01.svg');
  });

  it('相对时间对无效输入返回空字符串', () => {
    expect(relativeTime(null)).toBe('');
    expect(relativeTime('not-a-date')).toBe('');
    expect(relativeTime(new Date().toISOString())).toBe('刚刚');
  });
});
