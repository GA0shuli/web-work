import rateLimit from 'express-rate-limit';
import { env } from '../config/env.js';
import { tooManyRequests } from '../utils/AppError.js';

// 一个全局限流就够了：15 分钟内单个 IP 最多 300 次请求
export const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  limit: 300,
  standardHeaders: 'draft-7',
  legacyHeaders: false,
  skip: () => env.isTest,
  handler: (req, res, next) => next(tooManyRequests('操作过于频繁，请稍后再试')),
});
