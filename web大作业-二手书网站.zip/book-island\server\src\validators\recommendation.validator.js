import { BOOK_CONDITIONS } from '../config/constants.js';
import { optionalString, parseEnum, parseInteger, parseNumber } from '../utils/validate.js';

export function validateRecommendationQuery(query = {}) {
  const keyword = optionalString(query.q ?? query.keyword, '搜索关键词', { max: 100 });
  const categoryId = parseInteger(query.categoryId, '分类', { min: 1, max: 1_000_000 });
  const maxPrice = parseNumber(query.maxPrice, '预算', { min: 0.01, max: 9999 });
  const minCondition = parseEnum(
    query.minCondition || 'fair',
    Object.keys(BOOK_CONDITIONS),
    '最低成色',
  );
  const limit = parseInteger(query.limit ?? 8, '返回数量', { min: 1, max: 30 }) ?? 8;
  return { keyword, categoryId, maxPrice, minCondition, limit };
}

export function validateAdminQuery(query = {}) {
  const reviewStatus = query.reviewStatus
    ? parseEnum(query.reviewStatus, ['pending', 'approved', 'rejected'], '审核状态')
    : null;
  const status = query.status
    ? parseEnum(query.status, ['pending_seller', 'in_progress', 'completed', 'cancelled'], '订单状态')
    : null;
  return {
    q: optionalString(query.q, '关键词', { max: 100 }),
    reviewStatus,
    status,
    role: query.role ? parseEnum(query.role, ['user', 'admin'], '角色') : null,
    userStatus: query.userStatus
      ? parseEnum(query.userStatus, ['active', 'disabled'], '用户状态')
      : null,
  };
}
