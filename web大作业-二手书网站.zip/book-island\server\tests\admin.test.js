import { beforeEach, describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../src/app.js';
import { CSRF, findBook, login, loginAdmin, resetDb } from './helpers.js';

const app = createApp();

beforeEach(() => {
  resetDb();
});

describe('管理后台', () => {
  it('访客和普通用户不能访问管理接口', async () => {
    expect((await request(app).get('/api/admin/books')).status).toBe(401);

    const user = await login(app, 'linxi@campus.edu');
    expect((await user.get('/api/admin/books')).status).toBe(403);
    expect(
      (await user.patch('/api/admin/books/1/review').set(CSRF).send({ action: 'approve' })).status,
    ).toBe(403);
  });

  it('审核通过后图书进入公开列表，下架后消失', async () => {
    const admin = await loginAdmin(app);

    const pending = await admin.get('/api/admin/books').query({ reviewStatus: 'pending' });
    const pendingBook = pending.body.data.items.find(
      (item) => item.title === '高等数学辅导讲义（2024版）',
    );
    expect(pendingBook).toBeTruthy();

    const approved = await admin
      .patch(`/api/admin/books/${pendingBook.id}/review`)
      .set(CSRF)
      .send({ action: 'approve', reason: '信息完整，允许上架' });
    expect(approved.body.data.reviewStatus).toBe('approved');

    const approvedSearch = await request(app).get('/api/books').query({ q: '高等数学辅导讲义' });
    expect(approvedSearch.body.data.items.some((item) => item.id === pendingBook.id)).toBe(true);

    const book = await findBook(app, '数据结构（C语言版）');
    const removed = await admin
      .patch(`/api/admin/books/${book.id}/review`)
      .set(CSRF)
      .send({ action: 'remove', reason: '内容疑似违规，暂时下架' });
    expect(removed.body.data.saleStatus).toBe('offline');

    const afterRemove = await request(app).get('/api/books').query({ q: '数据结构' });
    expect(afterRemove.body.data.items.some((item) => item.id === book.id)).toBe(false);
  });
});
