import api from './api';

export async function list() {
  const response = await api.get('/categories');
  return response.data.items;
}

export async function publicStats() {
  const response = await api.get('/stats');
  return response.data;
}
