import crypto from 'node:crypto';
import { getDb } from '../database/db.js';
import { ORDER_STATUS, ORDER_TRANSITIONS } from '../config/constants.js';
import { badRequest, conflict, forbidden, notFound } from '../utils/AppError.js';
import { serializeOrder } from '../utils/serializers.js';

const ORDER_SELECT = `
  SELECT o.*,
         bu.username AS buyer_username, bu.campus AS buyer_campus,
         su.username AS seller_username, su.campus AS seller_campus
  FROM orders o
  JOIN users bu ON bu.id = o.buyer_id
  JOIN users su ON su.id = o.seller_id
`;

function money(value) {
  return Math.round((Number(value) + Number.EPSILON) * 100) / 100;
}

function generateOrderNo() {
  const now = new Date();
  const stamp = [
    now.getUTCFullYear(),
    String(now.getUTCMonth() + 1).padStart(2, '0'),
    String(now.getUTCDate()).padStart(2, '0'),
  ].join('');
  return `BI${stamp}${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
}

function viewerRole(order, user) {
  if (user.role === 'admin') return 'admin';
  if (order.buyer_id === user.id) return 'buyer';
  if (order.seller_id === user.id) return 'seller';
  return null;
}

function permissionsFor(order, role) {
  return {
    canConfirm: role === 'seller' && order.status === 'pending_seller',
    canComplete: role === 'buyer' && order.status === 'in_progress',
    canCancel:
      ['buyer', 'seller', 'admin'].includes(role) &&
      ['pending_seller', 'in_progress'].includes(order.status),
  };
}

function loadItems(orderIds) {
  if (!orderIds.length) return new Map();
  const placeholders = orderIds.map(() => '?').join(', ');
  const rows = getDb()
    .prepare(`SELECT * FROM order_items WHERE order_id IN (${placeholders}) ORDER BY id ASC`)
    .all(...orderIds);
  const grouped = new Map();
  for (const row of rows) {
    if (!grouped.has(row.order_id)) grouped.set(row.order_id, []);
    grouped.get(row.order_id).push(row);
  }
  return grouped;
}

function serializeOrderWithRole(row, items, role) {
  return serializeOrder(row, items, {
    viewerRole: role,
    permissions: permissionsFor(row, role),
  });
}

export function getOrderById(orderId, user) {
  const row = getDb().prepare(`${ORDER_SELECT} WHERE o.id = ?`).get(orderId);
  if (!row) throw notFound('订单不存在');
  const role = viewerRole(row, user);
  if (!role) throw forbidden('无权查看该订单');
  const items = loadItems([row.id]).get(row.id) ?? [];
  return serializeOrderWithRole(row, items, role);
}

export function listOrders(userId, { role = 'buyer', status = null, page = 1, pageSize = 10 } = {}) {
  const db = getDb();
  const column = role === 'seller' ? 'o.seller_id' : 'o.buyer_id';
  const where = [`${column} = @userId`];
  const params = { userId };
  if (status && Object.hasOwn(ORDER_STATUS, status)) {
    where.push('o.status = @status');
    params.status = status;
  }
  const whereSql = `WHERE ${where.join(' AND ')}`;
  const total = db
    .prepare(`SELECT COUNT(*) AS count FROM orders o ${whereSql}`)
    .get(params).count;
  const offset = (page - 1) * pageSize;
  const rows = db
    .prepare(`${ORDER_SELECT} ${whereSql} ORDER BY o.created_at DESC LIMIT @limit OFFSET @offset`)
    .all({ ...params, limit: pageSize, offset });
  const itemsMap = loadItems(rows.map((row) => row.id));

  return {
    items: rows.map((row) =>
      serializeOrderWithRole(row, itemsMap.get(row.id) ?? [], role === 'seller' ? 'seller' : 'buyer'),
    ),
    pagination: {
      page,
      pageSize,
      total,
      totalPages: Math.max(1, Math.ceil(total / pageSize)),
    },
    role,
  };
}

export function createOrders(user, payload) {
  const db = getDb();
  const create = db.transaction(() => {
    const placeholders = payload.bookIds.map(() => '?').join(', ');
    const books = db
      .prepare(
        `SELECT b.*, u.username AS seller_username
         FROM books b JOIN users u ON u.id = b.seller_id
         WHERE b.id IN (${placeholders})`,
      )
      .all(...payload.bookIds);

    if (books.length !== payload.bookIds.length) {
      throw notFound('部分图书不存在，请刷新购物车');
    }

    for (const book of books) {
      if (book.seller_id === user.id) {
        throw badRequest(`不能购买自己发布的《${book.title}》`);
      }
      if (book.review_status !== 'approved') {
        throw conflict(`《${book.title}》尚未通过审核，暂时无法购买`, 'BOOK_NOT_AVAILABLE');
      }
      if (book.sale_status !== 'available') {
        throw conflict(`《${book.title}》已售出或不可交易`, 'BOOK_NOT_AVAILABLE');
      }
    }

    const groups = new Map();
    for (const book of books) {
      if (!groups.has(book.seller_id)) groups.set(book.seller_id, []);
      groups.get(book.seller_id).push(book);
    }

    const now = new Date().toISOString();
    const reserveBook = db.prepare(
      `UPDATE books SET sale_status = 'reserved', updated_at = @now
       WHERE id = @id AND sale_status = 'available' AND review_status = 'approved'`,
    );
    const insertOrder = db.prepare(
      `INSERT INTO orders (
        order_no, buyer_id, seller_id, total_amount, status,
        contact_name, contact_phone, pickup_location, note, created_at, updated_at
      ) VALUES (
        @orderNo, @buyerId, @sellerId, @totalAmount, 'pending_seller',
        @contactName, @contactPhone, @pickupLocation, @note, @now, @now
      )`,
    );
    const insertItem = db.prepare(
      `INSERT INTO order_items (
        order_id, book_id, title_snapshot, author_snapshot, price, condition_snapshot, cover_snapshot
      ) VALUES (
        @orderId, @bookId, @title, @author, @price, @condition, @coverPath
      )`,
    );

    const createdIds = [];
    for (const [sellerId, group] of groups) {
      for (const book of group) {
        const result = reserveBook.run({ now, id: book.id });
        if (result.changes !== 1) {
          throw conflict(`《${book.title}》刚刚被其他同学购买，请刷新后重试`, 'BOOK_CONFLICT');
        }
      }

      const totalAmount = money(group.reduce((sum, book) => sum + book.price, 0));
      let orderId = null;
      for (let attempt = 0; attempt < 4 && !orderId; attempt += 1) {
        try {
          const result = insertOrder.run({
            orderNo: generateOrderNo(),
            buyerId: user.id,
            sellerId,
            totalAmount,
            contactName: payload.contactName,
            contactPhone: payload.contactPhone,
            pickupLocation: payload.pickupLocation,
            note: payload.note,
            now,
          });
          orderId = Number(result.lastInsertRowid);
        } catch (error) {
          if (!String(error.code).includes('SQLITE_CONSTRAINT_UNIQUE')) throw error;
        }
      }
      if (!orderId) throw conflict('订单号生成失败，请重试', 'ORDER_NO_CONFLICT');

      for (const book of group) {
        insertItem.run({
          orderId,
          bookId: book.id,
          title: book.title,
          author: book.author,
          price: book.price,
          condition: book.book_condition,
          coverPath: book.cover_path,
        });
      }
      createdIds.push(orderId);
    }

    // 下单成功后从购物车移除已购买图书。
    db.prepare(
      `DELETE FROM cart_items WHERE user_id = ? AND book_id IN (${placeholders})`,
    ).run(user.id, ...payload.bookIds);

    return createdIds.map((id) => getOrderById(id, user));
  });

  return create();
}

export function updateOrderStatus(orderId, user, { status, reason }) {
  const db = getDb();
  const row = db.prepare('SELECT * FROM orders WHERE id = ?').get(orderId);
  if (!row) throw notFound('订单不存在');
  const role = viewerRole(row, user);
  if (!role) throw forbidden('无权操作该订单');

  const allowedRoles = ORDER_TRANSITIONS[row.status]?.[status] ?? [];
  if (!allowedRoles.includes(role)) {
    throw badRequest(
      `订单当前状态为“${ORDER_STATUS[row.status]}”，不能变更为“${ORDER_STATUS[status] ?? status}”`,
    );
  }

  const now = new Date().toISOString();
  const run = db.transaction(() => {
    if (status === 'cancelled') {
      db.prepare(
        `UPDATE orders SET status = 'cancelled', cancel_reason = ?, updated_at = ? WHERE id = ?`,
      ).run(reason, now, orderId);
      db.prepare(
        `UPDATE books SET sale_status = 'available', updated_at = ?
         WHERE sale_status = 'reserved' AND review_status = 'approved'
           AND id IN (SELECT book_id FROM order_items WHERE order_id = ? AND book_id IS NOT NULL)`,
      ).run(now, orderId);
    } else if (status === 'completed') {
      db.prepare(`UPDATE orders SET status = 'completed', updated_at = ? WHERE id = ?`).run(
        now,
        orderId,
      );
      db.prepare(
        `UPDATE books SET sale_status = 'sold', sold_at = ?, updated_at = ?
         WHERE id IN (SELECT book_id FROM order_items WHERE order_id = ? AND book_id IS NOT NULL)`,
      ).run(now, now, orderId);
    } else {
      db.prepare('UPDATE orders SET status = ?, updated_at = ? WHERE id = ?').run(
        status,
        now,
        orderId,
      );
    }
  });
  run();

  return getOrderById(orderId, user);
}
