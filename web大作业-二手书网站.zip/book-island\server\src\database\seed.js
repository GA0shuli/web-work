import bcrypt from 'bcryptjs';
import { env } from '../config/env.js';
import { getDb } from './db.js';
import { initSchema } from './schema.js';
import { books, categories, demoUsers, seedOrders } from './seed-data.js';

const DAY_MS = 24 * 60 * 60 * 1000;

function daysAgoIso(days) {
  return new Date(Date.now() - days * DAY_MS).toISOString();
}

function hash(password, rounds = 10) {
  return bcrypt.hashSync(password, rounds);
}

export function seedDatabase() {
  const db = getDb();
  initSchema();

  const summary = {
    categories: 0,
    users: 0,
    books: 0,
    orders: 0,
  };

  const insertCategory = db.prepare(
    `INSERT OR IGNORE INTO categories (name, slug, description, icon, sort_order)
     VALUES (@name, @slug, @description, @icon, @sortOrder)`,
  );
  const insertUser = db.prepare(
    `INSERT OR IGNORE INTO users (username, email, password_hash, role, campus, bio, created_at, updated_at)
     VALUES (@username, @email, @passwordHash, @role, @campus, @bio, @createdAt, @createdAt)`,
  );

  const seed = db.transaction(() => {
    for (const category of categories) {
      const result = insertCategory.run(category);
      summary.categories += result.changes;
    }

    const adminResult = insertUser.run({
      username: env.admin.username,
      email: env.admin.email.toLowerCase(),
      passwordHash: hash(env.admin.password),
      role: 'admin',
      campus: '平台管理',
      bio: '书屿平台管理员，负责图书审核与交易秩序维护。',
      createdAt: daysAgoIso(60),
    });
    summary.users += adminResult.changes;

    const demoHash = hash(env.demoPassword);
    for (const user of demoUsers) {
      const result = insertUser.run({
        username: user.username,
        email: user.email.toLowerCase(),
        passwordHash: demoHash,
        role: 'user',
        campus: user.campus,
        bio: user.bio,
        createdAt: daysAgoIso(user.createdDaysAgo ?? 30),
      });
      summary.users += result.changes;
    }

    const admin = db
      .prepare('SELECT id FROM users WHERE email = ?')
      .get(env.admin.email.toLowerCase());
    const categoryIds = new Map(
      db.prepare('SELECT id, slug FROM categories').all().map((row) => [row.slug, row.id]),
    );
    const userIds = new Map(
      db
        .prepare('SELECT id, username FROM users WHERE role = ?')
        .all('user')
        .map((row) => [row.username, row.id]),
    );

    const insertBook = db.prepare(
      `INSERT OR IGNORE INTO books (
        seller_id, category_id, title, author, isbn, publisher, publish_year,
        original_price, price, book_condition, description, pickup_location, cover_path,
        review_status, review_note, reviewed_by, reviewed_at, sale_status, sold_at, seed_key,
        created_at, updated_at
      ) VALUES (
        @sellerId, @categoryId, @title, @author, @isbn, @publisher, @publishYear,
        @originalPrice, @price, @condition, @description, @pickup, @coverPath,
        @reviewStatus, @reviewNote, @reviewedBy, @reviewedAt, @saleStatus, @soldAt, @seedKey,
        @createdAt, @createdAt
      )`,
    );

    for (const book of books) {
      const reviewStatus = book.reviewStatus ?? 'approved';
      const saleStatus = book.saleStatus ?? 'available';
      const createdDaysAgo = book.createdDaysAgo ?? 20;
      const result = insertBook.run({
        sellerId: userIds.get(book.seller),
        categoryId: categoryIds.get(book.category),
        title: book.title,
        author: book.author,
        isbn: book.isbn,
        publisher: book.publisher,
        publishYear: book.publishYear,
        originalPrice: book.originalPrice,
        price: book.price,
        condition: book.condition,
        description: book.description,
        pickup: book.pickup,
        coverPath: `/covers/${book.seedKey}.svg`,
        reviewStatus,
        reviewNote: book.reviewNote ?? null,
        reviewedBy: reviewStatus === 'pending' ? null : admin?.id ?? null,
        reviewedAt:
          reviewStatus === 'pending' ? null : daysAgoIso(Math.max(0, createdDaysAgo - 1)),
        saleStatus,
        soldAt: book.soldDaysAgo ? daysAgoIso(book.soldDaysAgo) : null,
        seedKey: book.seedKey,
        createdAt: daysAgoIso(createdDaysAgo),
      });
      summary.books += result.changes;
    }

    const bookRows = db
      .prepare('SELECT * FROM books WHERE seed_key IS NOT NULL')
      .all()
      .reduce((map, row) => map.set(row.seed_key, row), new Map());

    const insertOrder = db.prepare(
      `INSERT OR IGNORE INTO orders (
        order_no, buyer_id, seller_id, total_amount, status,
        contact_name, contact_phone, pickup_location, note, created_at, updated_at
      ) VALUES (
        @orderNo, @buyerId, @sellerId, @totalAmount, @status,
        @contactName, @contactPhone, @pickupLocation, @note, @createdAt, @updatedAt
      )`,
    );
    const insertOrderItem = db.prepare(
      `INSERT INTO order_items (
        order_id, book_id, title_snapshot, author_snapshot, price, condition_snapshot, cover_snapshot
      ) VALUES (
        @orderId, @bookId, @title, @author, @price, @condition, @coverPath
      )`,
    );
    const updateBookStatus = db.prepare(
      'UPDATE books SET sale_status = ?, sold_at = ? WHERE id = ?',
    );

    for (const order of seedOrders) {
      const existing = db.prepare('SELECT id FROM orders WHERE order_no = ?').get(order.orderNo);
      if (existing) continue;

      const items = order.items.map((key) => bookRows.get(key)).filter(Boolean);
      if (!items.length) continue;
      const buyerId = userIds.get(order.buyer);
      const sellerId = userIds.get(order.seller);
      if (!buyerId || !sellerId) continue;

      const totalAmount = Number(items.reduce((sum, item) => sum + item.price, 0).toFixed(2));
      const createdAt = daysAgoIso(order.daysAgo);
      const updatedAt = order.status === 'completed' ? daysAgoIso(order.daysAgo - 1) : createdAt;
      const result = insertOrder.run({
        orderNo: order.orderNo,
        buyerId,
        sellerId,
        totalAmount,
        status: order.status,
        contactName: order.contactName,
        contactPhone: order.contactPhone,
        pickupLocation: order.pickupLocation,
        note: order.note,
        createdAt,
        updatedAt,
      });
      if (!result.changes) continue;
      summary.orders += 1;
      const orderId = result.lastInsertRowid;

      for (const item of items) {
        insertOrderItem.run({
          orderId,
          bookId: item.id,
          title: item.title,
          author: item.author,
          price: item.price,
          condition: item.book_condition,
          coverPath: item.cover_path,
        });
        if (order.status === 'completed') {
          updateBookStatus.run('sold', daysAgoIso(order.daysAgo - 1), item.id);
        } else if (order.status === 'pending_seller' || order.status === 'in_progress') {
          updateBookStatus.run('reserved', null, item.id);
        }
      }
    }
  });

  seed();

  return summary;
}
