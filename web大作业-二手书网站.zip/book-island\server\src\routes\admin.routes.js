import { Router } from 'express';
import { requireAdmin } from '../middleware/auth.js';
import {
  getAdminStats,
  listAdminBooks,
  listAdminOrders,
  reviewBook,
} from '../services/admin.service.js';
import { success } from '../utils/response.js';
import { parseId, parseNumber, parsePagination } from '../utils/validate.js';
import { validateAdminReview } from '../validators/book.validator.js';
import { validateAdminQuery } from '../validators/recommendation.validator.js';

export const adminRouter = Router();
adminRouter.use(requireAdmin);

adminRouter.get('/stats', (req, res) => success(res, getAdminStats(), '获取管理统计成功'));

adminRouter.get('/books', (req, res) => {
  const { page, pageSize } = parsePagination(req.query, { defaultPageSize: 12 });
  const filters = validateAdminQuery(req.query);
  const categoryId = parseNumber(req.query.categoryId, '分类', { min: 1, max: 1_000_000 });
  return success(
    res,
    listAdminBooks({ ...filters, categoryId, page, pageSize, q: filters.q }),
    '获取图书审核列表成功',
  );
});

adminRouter.patch('/books/:id/review', (req, res) => {
  const id = parseId(req.params.id, '图书 ID');
  const payload = validateAdminReview(req.body);
  return success(res, reviewBook(req.user.id, id, payload), '图书审核操作成功');
});

adminRouter.get('/orders', (req, res) => {
  const { page, pageSize } = parsePagination(req.query, { defaultPageSize: 20 });
  const filters = validateAdminQuery(req.query);
  return success(res, listAdminOrders({ ...filters, page, pageSize, q: filters.q }), '获取订单列表成功');
});
