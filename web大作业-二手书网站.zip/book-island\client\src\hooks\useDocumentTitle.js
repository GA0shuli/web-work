import { useEffect } from 'react';

export function useDocumentTitle(title) {
  useEffect(() => {
    document.title = title ? `${title} · 书屿` : '书屿 · 校园二手书交易平台';
  }, [title]);
}
