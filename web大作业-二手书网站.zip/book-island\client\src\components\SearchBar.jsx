import { useEffect, useState } from 'react';
import { Search } from 'lucide-react';

export default function SearchBar({
  initialValue = '',
  onSearch,
  placeholder = '搜索书名、作者或 ISBN',
  buttonText = '搜索',
  size = 'md',
  autoFocus = false,
}) {
  const [value, setValue] = useState(initialValue);

  useEffect(() => {
    setValue(initialValue);
  }, [initialValue]);

  const submit = (event) => {
    event.preventDefault();
    onSearch?.(value.trim());
  };

  return (
    <form className={`search-bar search-bar--${size}`} role="search" onSubmit={submit}>
      <Search size={18} className="search-bar__icon" aria-hidden="true" />
      <label className="sr-only" htmlFor="global-search-input">
        搜索图书
      </label>
      <input
        id="global-search-input"
        type="search"
        value={value}
        onChange={(event) => setValue(event.target.value)}
        placeholder={placeholder}
        autoFocus={autoFocus}
      />
      <button type="submit" className="button button--primary search-bar__button">
        {buttonText}
      </button>
    </form>
  );
}
