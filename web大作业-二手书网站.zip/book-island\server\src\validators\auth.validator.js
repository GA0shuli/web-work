import { badRequest } from '../utils/AppError.js';
import {
  optionalString,
  requiredEmail,
  requiredPassword,
  requiredString,
} from '../utils/validate.js';

const USERNAME_PATTERN = /^[\w\u4e00-\u9fa5.-]{3,20}$/u;

export function validateRegister(body = {}) {
  const username = requiredString(body.username, '用户名', { min: 3, max: 20 });
  if (!USERNAME_PATTERN.test(username)) {
    throw badRequest('用户名只能包含中文、字母、数字、下划线、点和短横线，长度 3-20 位');
  }
  const email = requiredEmail(body.email);
  const password = requiredPassword(body.password);
  return { username, email, password };
}

export function validateLogin(body = {}) {
  const identifier = requiredString(body.identifier ?? body.email ?? body.username, '邮箱或用户名', {
    max: 120,
  });
  if (typeof body.password !== 'string' || body.password.length === 0) {
    throw badRequest('密码不能为空');
  }
  return { identifier, password: body.password };
}

export function validateProfileUpdate(body = {}) {
  const update = {};

  if (body.username !== undefined) {
    const username = requiredString(body.username, '用户名', { min: 3, max: 20 });
    if (!USERNAME_PATTERN.test(username)) {
      throw badRequest('用户名只能包含中文、字母、数字、下划线、点和短横线，长度 3-20 位');
    }
    update.username = username;
  }
  if (body.email !== undefined) {
    update.email = requiredEmail(body.email);
  }
  if (body.bio !== undefined) {
    update.bio = optionalString(body.bio, '个人简介', { max: 200 });
  }
  if (body.campus !== undefined) {
    update.campus = optionalString(body.campus, '校区', { max: 60 });
  }
  if (body.newPassword !== undefined && body.newPassword !== '') {
    if (!body.currentPassword) {
      throw badRequest('修改密码需要提供当前密码');
    }
    update.currentPassword = String(body.currentPassword);
    update.newPassword = requiredPassword(body.newPassword, '新密码');
  }

  if (Object.keys(update).length === 0) {
    throw badRequest('没有需要更新的资料');
  }
  return update;
}
