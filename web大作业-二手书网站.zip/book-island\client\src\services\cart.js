import api from './api';

export async function getCart() {
  const response = await api.get('/cart');
  return response.data;
}

export async function addBook(bookId) {
  const response = await api.post('/cart', { bookId });
  return response.data;
}

export async function updateItem(id, quantity = 1) {
  const response = await api.patch(`/cart/${id}`, { quantity });
  return response.data;
}

export async function removeItem(id) {
  const response = await api.delete(`/cart/${id}`);
  return response.data;
}
