import { getDb } from '../database/db.js';
import { BOOK_SORTS, PAGINATION } from '../config/constants.js';
import { badRequest, conflict, forbidden, notFound } from '../utils/AppError.js';
import { escapeLike } from '../utils/validate.js';
import { saveCoverImage, removeCoverImage } from '../utils/image.js';
import { serializeBook } from '../utils/serializers.js';

const BOOK_SELECT = `
  SELECT b.*,
         c.name AS category_name,
         c.slug AS category_slug,
         u.username AS seller_username,
         u.campus AS seller_campus
  FROM books b
  JOIN categories c ON c.id = b.category_id
  JOIN users u ON u.id = b.seller_id
`;

function sortClause(sort) {
  switch (sort) {
    case 'oldest':
      return 'b.created_at ASC';
    case 'price_asc':
      return 'b.price ASC, b.created_at DESC';
    case 'price_desc':
      return 'b.price DESC, b.created_at DESC';
    case 'newest':
    default:
      return 'b.created_at DESC';
  }
}

export function listBooks({
  viewerId = null,
  q = null,
  category = null,
  categories = null,
  conditions = null,
  minPrice = null,
  maxPrice = null,
  sort = 'newest',
  page = PAGINATION.defaultPage,
  pageSize = PAGINATION.defaultPageSize,
  sellerId = null,
  includeAllStatuses = false,
} = {}) {
  const db = getDb();
  const where = [];
  const params = {};

  if (viewerId) params.viewerId = viewerId;

  if (!includeAllStatuses) {
    where.push("b.review_status = 'approved'");
    where.push("b.sale_status = 'available'");
  }
  if (sellerId) {
    where.push('b.seller_id = @sellerId');
    params.sellerId = sellerId;
  }
  if (q) {
    const keyword = `%${escapeLike(q)}%`;
    where.push(
      "(b.title LIKE @q ESCAPE '\\' OR b.author LIKE @q ESCAPE '\\' OR b.isbn LIKE @q ESCAPE '\\' OR COALESCE(b.publisher, '') LIKE @q ESCAPE '\\' OR COALESCE(b.description, '') LIKE @q ESCAPE '\\')",
    );
    params.q = keyword;
  }
  if (category) {
    const numeric = Number(category);
    if (Number.isInteger(numeric) && numeric > 0) {
      where.push('b.category_id = @categoryId');
      params.categoryId = numeric;
    } else {
      where.push('c.slug = @categorySlug');
      params.categorySlug = String(category);
    }
  }
  if (Array.isArray(categories) && categories.length > 0) {
    const placeholders = categories.map((item, index) => {
      params[`category${index}`] = Number(item);
      return `@category${index}`;
    });
    where.push(`b.category_id IN (${placeholders.join(', ')})`);
  }
  if (Array.isArray(conditions) && conditions.length > 0) {
    const placeholders = conditions.map((item, index) => {
      params[`condition${index}`] = item;
      return `@condition${index}`;
    });
    where.push(`b.book_condition IN (${placeholders.join(', ')})`);
  }
  if (minPrice !== null) {
    where.push('b.price >= @minPrice');
    params.minPrice = minPrice;
  }
  if (maxPrice !== null) {
    where.push('b.price <= @maxPrice');
    params.maxPrice = maxPrice;
  }

  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const safeSort = BOOK_SORTS.includes(sort) ? sort : 'newest';
  const offset = (page - 1) * pageSize;

  const rows = db
    .prepare(
      `${BOOK_SELECT}
       ${whereSql}
       ORDER BY ${sortClause(safeSort)}
       LIMIT @limit OFFSET @offset`,
    )
    .all({ ...params, limit: pageSize, offset });
  const total = db
    .prepare(
      `SELECT COUNT(*) AS count
       FROM books b
       JOIN categories c ON c.id = b.category_id
       ${whereSql}`,
    )
    .get(params).count;

  return {
    items: rows.map((row) => serializeBook(row)),
    pagination: {
      page,
      pageSize,
      total,
      totalPages: Math.max(1, Math.ceil(total / pageSize)),
    },
    sort: safeSort,
  };
}

const DETAIL_SELECT = `
  SELECT b.*,
         c.name AS category_name,
         c.slug AS category_slug,
         u.username AS seller_username,
         u.campus AS seller_campus,
         u.bio AS seller_bio
  FROM books b
  JOIN categories c ON c.id = b.category_id
  JOIN users u ON u.id = b.seller_id
  WHERE b.id = @id
`;

export function findBookRow(id) {
  return getDb().prepare(DETAIL_SELECT).get({ id });
}

export function getBookDetail(id, viewer = null) {
  const row = findBookRow(id, viewer?.id ?? null);
  if (!row) throw notFound('图书不存在');
  const isOwner = viewer && viewer.id === row.seller_id;
  const isAdmin = viewer?.role === 'admin';
  if (!isAdmin && !isOwner) {
    if (row.review_status !== 'approved' || row.sale_status === 'offline') {
      throw notFound('图书不存在或已下架');
    }
  }
  return serializeBook(row, {
    seller: {
      id: row.seller_id,
      username: row.seller_username,
      campus: row.seller_campus,
      bio: row.seller_bio,
    },
  });
}

export function getOwnedBook(id, userId) {
  const row = getDb().prepare('SELECT * FROM books WHERE id = ?').get(id);
  if (!row) throw notFound('图书不存在');
  if (row.seller_id !== userId) throw forbidden('只能管理自己发布的图书');
  return row;
}

function ensureCategory(categoryId) {
  const category = getDb().prepare('SELECT id FROM categories WHERE id = ?').get(categoryId);
  if (!category) throw badRequest('图书分类不存在');
}

function ensurePricePair(price, originalPrice) {
  if (originalPrice !== null && originalPrice !== undefined && originalPrice < price) {
    throw badRequest('新书参考价不能低于二手售价');
  }
}

export async function createBook({ userId, payload, file }) {
  ensureCategory(payload.categoryId);
  ensurePricePair(payload.price, payload.originalPrice);

  let coverPath = null;
  if (file) {
    coverPath = await saveCoverImage(file);
  }

  const db = getDb();
  try {
    const result = db
      .prepare(
        `INSERT INTO books (
          seller_id, category_id, title, author, isbn, publisher, publish_year,
          original_price, price, book_condition, description, pickup_location, cover_path,
          review_status, sale_status
        ) VALUES (
          @sellerId, @categoryId, @title, @author, @isbn, @publisher, @publishYear,
          @originalPrice, @price, @condition, @description, @pickupLocation, @coverPath,
          'pending', 'available'
        )`,
      )
      .run({
        sellerId: userId,
        categoryId: payload.categoryId,
        title: payload.title,
        author: payload.author,
        isbn: payload.isbn,
        publisher: payload.publisher,
        publishYear: payload.publishYear,
        originalPrice: payload.originalPrice,
        price: payload.price,
        condition: payload.condition,
        description: payload.description,
        pickupLocation: payload.pickupLocation,
        coverPath,
      });
    return getBookDetail(Number(result.lastInsertRowid), { id: userId, role: 'user' });
  } catch (error) {
    if (coverPath) await removeCoverImage(coverPath);
    throw error;
  }
}

export async function updateBook({ userId, bookId, payload, file }) {
  const existing = getOwnedBook(bookId, userId);
  if (existing.sale_status === 'reserved' || existing.sale_status === 'sold') {
    throw conflict('交易中的图书不能编辑，请先完成或取消订单');
  }

  if (payload.categoryId !== undefined) ensureCategory(payload.categoryId);
  const nextPrice = payload.price ?? existing.price;
  const nextOriginal = payload.originalPrice !== undefined ? payload.originalPrice : existing.original_price;
  ensurePricePair(nextPrice, nextOriginal);

  let newCover = null;
  if (file) {
    newCover = await saveCoverImage(file);
  }

  const fields = [];
  const params = { id: bookId, updatedAt: new Date().toISOString() };
  const mapping = {
    title: 'title',
    author: 'author',
    isbn: 'isbn',
    publisher: 'publisher',
    publishYear: 'publish_year',
    categoryId: 'category_id',
    originalPrice: 'original_price',
    price: 'price',
    condition: 'book_condition',
    description: 'description',
    pickupLocation: 'pickup_location',
  };
  for (const [key, column] of Object.entries(mapping)) {
    if (payload[key] !== undefined) {
      fields.push(`${column} = @${key}`);
      params[key] = payload[key];
    }
  }
  if (newCover) {
    fields.push('cover_path = @coverPath');
    params.coverPath = newCover;
  }

  // 修改后的图书重新进入待审核队列，避免绕过审核直接修改商品信息。
  fields.push("review_status = 'pending'", 'review_note = NULL', 'reviewed_by = NULL', 'reviewed_at = NULL');

  const db = getDb();
  try {
    db.prepare(
      `UPDATE books SET ${fields.join(', ')}, updated_at = @updatedAt WHERE id = @id AND seller_id = @sellerId`,
    ).run({ ...params, sellerId: userId });
  } catch (error) {
    if (newCover) await removeCoverImage(newCover);
    throw error;
  }

  if (newCover && existing.cover_path) {
    await removeCoverImage(existing.cover_path);
  }
  return getBookDetail(bookId, { id: userId, role: 'user' });
}

export function offlineBook({ userId, bookId }) {
  const existing = getOwnedBook(bookId, userId);
  if (existing.sale_status === 'reserved') {
    throw conflict('该图书存在进行中的订单，暂时不能下架');
  }
  if (existing.sale_status === 'sold') {
    throw conflict('已售出的图书不能下架');
  }
  if (existing.sale_status === 'offline') {
    return getBookDetail(bookId, { id: userId, role: 'user' });
  }
  getDb()
    .prepare("UPDATE books SET sale_status = 'offline', updated_at = ? WHERE id = ?")
    .run(new Date().toISOString(), bookId);
  return getBookDetail(bookId, { id: userId, role: 'user' });
}
