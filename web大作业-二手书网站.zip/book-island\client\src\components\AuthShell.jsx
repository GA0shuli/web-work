import { Link } from 'react-router-dom';
import { ArrowLeft, BookOpen, GraduationCap, ShieldCheck, Sparkles } from 'lucide-react';
import { Logo } from './common';

const POINTS = [
  { icon: ShieldCheck, text: '审核上架，真实书况' },
  { icon: GraduationCap, text: '同校教材，当面自提' },
  { icon: Sparkles, text: '教材智能匹配推荐' },
];

export default function AuthShell({ title, subtitle, children, footer }) {
  return (
    <div className="auth-page">
      <div className="auth-panel">
        <div className="auth-panel__top">
          <Link to="/" className="auth-back">
            <ArrowLeft size={16} /> 返回首页
          </Link>
          <Logo />
        </div>
        <div className="auth-panel__content">
          <span className="eyebrow eyebrow--light">
            <BookOpen size={15} /> 校园二手书交易平台
          </span>
          <h1>让旧书继续旅行，让知识更轻一点。</h1>
          <p>
            在书屿发布闲置教材、搜索下一门课的参考书，用更低的成本完成学习，也让书架重新呼吸。
          </p>
          <ul className="auth-points">
            {POINTS.map(({ icon: Icon, text }) => (
              <li key={text}>
                <Icon size={17} /> {text}
              </li>
            ))}
          </ul>
          <div className="auth-panel__covers" aria-hidden="true">
            <img src="/covers/seed-01.svg" alt="" />
            <img src="/covers/seed-09.svg" alt="" />
            <img src="/covers/seed-05.svg" alt="" />
          </div>
        </div>
        <p className="auth-panel__note">课程作业演示项目 · 不接入真实支付</p>
      </div>

      <div className="auth-main">
        <div className="auth-main__card">
          <div className="auth-main__brand">
            <Logo />
          </div>
          <h2>{title}</h2>
          {subtitle && <p className="auth-subtitle">{subtitle}</p>}
          {children}
          {footer && <div className="auth-footer">{footer}</div>}
        </div>
      </div>
    </div>
  );
}
