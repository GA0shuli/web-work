import { Link } from 'react-router-dom';
import { AlertTriangle, BookOpen, Loader2, RefreshCw } from 'lucide-react';
import {
  ORDER_STATUS_LABELS,
  REVIEW_STATUS_LABELS,
  SALE_STATUS_LABELS,
  orderStatusTone,
} from '../utils/format';

export function Logo({ compact = false }) {
  return (
    <Link to="/" className="logo" aria-label="书屿首页">
      <span className="logo__mark" aria-hidden="true">
        <BookOpen size={20} strokeWidth={2.2} />
      </span>
      <span className="logo__text">
        <strong>书屿</strong>
        {!compact && <small>BOOK ISLAND</small>}
      </span>
    </Link>
  );
}

export function LoadingSpinner({ label = '正在加载…', fullScreen = false }) {
  return (
    <div className={`loading${fullScreen ? ' loading--full' : ''}`} role="status" aria-live="polite">
      <Loader2 className="loading__icon" size={26} />
      <span>{label}</span>
    </div>
  );
}

export function BookGridSkeleton({ count = 8 }) {
  return (
    <div className="book-grid" aria-hidden="true">
      {Array.from({ length: count }).map((_, index) => (
        <div className="book-card book-card--skeleton" key={index}>
          <div className="skeleton skeleton--cover" />
          <div className="book-card__body">
            <div className="skeleton skeleton--line skeleton--short" />
            <div className="skeleton skeleton--line" />
            <div className="skeleton skeleton--line skeleton--short" />
            <div className="skeleton skeleton--line" />
          </div>
        </div>
      ))}
    </div>
  );
}

export function EmptyState({
  icon: Icon = BookOpen,
  title = '这里还没有内容',
  description = '',
  action = null,
}) {
  return (
    <div className="empty-state">
      <span className="empty-state__icon" aria-hidden="true">
        <Icon size={30} />
      </span>
      <h3>{title}</h3>
      {description && <p>{description}</p>}
      {action}
    </div>
  );
}

export function ErrorMessage({ message = '加载失败，请稍后重试', onRetry = null }) {
  return (
    <div className="error-message" role="alert">
      <AlertTriangle size={20} />
      <span>{message}</span>
      {onRetry && (
        <button type="button" className="button button--secondary button--sm" onClick={onRetry}>
          <RefreshCw size={14} /> 重新加载
        </button>
      )}
    </div>
  );
}

const STATUS_MAP = {
  order: {
    labels: ORDER_STATUS_LABELS,
    tones: {
      pending_seller: 'warning',
      in_progress: 'info',
      completed: 'success',
      cancelled: 'muted',
    },
  },
  review: {
    labels: REVIEW_STATUS_LABELS,
    tones: { pending: 'warning', approved: 'success', rejected: 'danger' },
  },
  sale: {
    labels: SALE_STATUS_LABELS,
    tones: { available: 'success', reserved: 'info', sold: 'muted', offline: 'muted' },
  },
};

export function StatusBadge({ type = 'order', status, tone = null, label = null }) {
  const config = STATUS_MAP[type] ?? STATUS_MAP.order;
  const resolvedTone = tone ?? config.tones[status] ?? (type === 'order' ? orderStatusTone(status) : 'muted');
  return (
    <span className={`status-badge status-badge--${resolvedTone}`}>
      {label ?? config.labels[status] ?? status}
    </span>
  );
}
