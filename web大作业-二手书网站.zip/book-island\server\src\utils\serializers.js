import { BOOK_CONDITIONS, ORDER_STATUS, REVIEW_STATUS, SALE_STATUS } from '../config/constants.js';

export function serializeUserSummary(row) {
  if (!row) return null;
  return {
    id: row.id,
    username: row.username,
    campus: row.campus ?? null,
  };
}

export function serializeBook(row, extra = {}) {
  if (!row) return null;
  const condition = BOOK_CONDITIONS[row.book_condition];
  return {
    id: row.id,
    title: row.title,
    author: row.author,
    isbn: row.isbn,
    publisher: row.publisher,
    publishYear: row.publish_year,
    originalPrice: row.original_price === null ? null : Number(row.original_price),
    price: Number(row.price),
    condition: row.book_condition,
    conditionLabel: condition?.label ?? row.book_condition,
    description: row.description,
    pickupLocation: row.pickup_location,
    coverPath: row.cover_path,
    reviewStatus: row.review_status,
    reviewStatusLabel: REVIEW_STATUS[row.review_status] ?? row.review_status,
    reviewNote: row.review_note,
    saleStatus: row.sale_status,
    saleStatusLabel: SALE_STATUS[row.sale_status] ?? row.sale_status,
    soldAt: row.sold_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    category: row.category_id
      ? {
          id: row.category_id,
          name: row.category_name ?? null,
          slug: row.category_slug ?? null,
        }
      : null,
    seller: row.seller_id
      ? {
          id: row.seller_id,
          username: row.seller_username ?? null,
          campus: row.seller_campus ?? null,
        }
      : null,
    ...extra,
  };
}

export function serializeOrder(row, items = [], extra = {}) {
  if (!row) return null;
  return {
    id: row.id,
    orderNo: row.order_no,
    buyer: row.buyer_id
      ? { id: row.buyer_id, username: row.buyer_username ?? null, campus: row.buyer_campus ?? null }
      : null,
    seller: row.seller_id
      ? {
          id: row.seller_id,
          username: row.seller_username ?? null,
          campus: row.seller_campus ?? null,
        }
      : null,
    totalAmount: Number(row.total_amount),
    status: row.status,
    statusLabel: ORDER_STATUS[row.status] ?? row.status,
    contactName: row.contact_name,
    contactPhone: row.contact_phone,
    pickupLocation: row.pickup_location,
    note: row.note,
    cancelReason: row.cancel_reason,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    items: items.map((item) => ({
      id: item.id,
      bookId: item.book_id,
      title: item.title_snapshot,
      author: item.author_snapshot,
      price: Number(item.price),
      condition: item.condition_snapshot,
      conditionLabel: BOOK_CONDITIONS[item.condition_snapshot]?.label ?? item.condition_snapshot,
      coverPath: item.cover_snapshot,
    })),
    ...extra,
  };
}
