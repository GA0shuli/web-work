export const CONDITION_OPTIONS = [
  { value: 'like_new', label: '近全新', description: '几乎未翻阅，内页干净' },
  { value: 'good', label: '良好', description: '正常使用痕迹，无缺页' },
  { value: 'fair', label: '一般', description: '有笔记或磨损，内容完整' },
];

export const ORDER_STATUS_OPTIONS = [
  { value: 'pending_seller', label: '待卖家确认' },
  { value: 'in_progress', label: '交易进行中' },
  { value: 'completed', label: '已完成' },
  { value: 'cancelled', label: '已取消' },
];

export function formatPrice(value, { exact = false } = {}) {
  const number = Number(value);
  if (!Number.isFinite(number)) return '—';
  if (exact) return `¥${number.toFixed(2)}`;
  return `¥${Number.isInteger(number) ? number : number.toFixed(2)}`;
}

export function formatDate(value, { withTime = false } = {}) {
  if (!value) return '—';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '—';
  const options = { year: 'numeric', month: '2-digit', day: '2-digit' };
  if (withTime) {
    options.hour = '2-digit';
    options.minute = '2-digit';
  }
  return new Intl.DateTimeFormat('zh-CN', options).format(date);
}

export function relativeTime(value) {
  if (!value) return '';
  const time = new Date(value).getTime();
  if (Number.isNaN(time)) return '';
  const diff = Date.now() - time;
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return '刚刚';
  if (minutes < 60) return `${minutes} 分钟前`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours} 小时前`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days} 天前`;
  return formatDate(value);
}

export function conditionLabel(value) {
  return CONDITION_OPTIONS.find((item) => item.value === value)?.label ?? value ?? '—';
}

export const REVIEW_STATUS_LABELS = {
  pending: '待审核',
  approved: '已通过',
  rejected: '已驳回',
};

export const SALE_STATUS_LABELS = {
  available: '可交易',
  reserved: '交易中',
  sold: '已售出',
  offline: '已下架',
};

export const ORDER_STATUS_LABELS = Object.fromEntries(
  ORDER_STATUS_OPTIONS.map((item) => [item.value, item.label]),
);

export function orderStatusTone(status) {
  return (
    {
      pending_seller: 'warning',
      in_progress: 'info',
      completed: 'success',
      cancelled: 'muted',
    }[status] ?? 'muted'
  );
}

export function getCoverUrl(coverPath) {
  if (!coverPath) return '/covers/default.svg';
  if (/^https?:\/\//i.test(coverPath)) return coverPath;
  return coverPath;
}

export function handleCoverError(event) {
  const image = event.currentTarget;
  if (!image.src.endsWith('/covers/default.svg')) {
    image.src = '/covers/default.svg';
  }
}

export function truncate(text, length = 80) {
  if (!text) return '';
  return text.length > length ? `${text.slice(0, length)}…` : text;
}

export function initials(name) {
  if (!name) return '书';
  return Array.from(name)[0].toUpperCase();
}

export function discountPercent(originalPrice, price) {
  const original = Number(originalPrice);
  const current = Number(price);
  if (!original || original <= current) return null;
  return Math.round((1 - current / original) * 100);
}
