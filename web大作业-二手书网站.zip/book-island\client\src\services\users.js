import api from './api';

export async function me() {
  const response = await api.get('/users/me');
  return response.data;
}

export async function updateMe(payload) {
  const response = await api.patch('/users/me', payload);
  return response.data;
}

export async function myBooks(params = {}) {
  const response = await api.get('/users/me/books', { params });
  return response.data;
}

export async function publicProfile(id) {
  const response = await api.get(`/users/${id}`);
  return response.data;
}
