import { ORDER_STATUS } from '../config/constants.js';
import { badRequest } from '../utils/AppError.js';
import { optionalString, parseId } from '../utils/validate.js';

const PHONE_PATTERN = /^[0-9+\-\s]{6,20}$/;

export function validateCartAdd(body = {}) {
  return { bookId: parseId(body.bookId, '图书') };
}

export function validateOrderCreate(body = {}) {
  const rawIds = Array.isArray(body.bookIds) ? body.bookIds : [];
  if (rawIds.length === 0) throw badRequest('请选择要购买的图书');
  if (rawIds.length > 20) throw badRequest('单次最多购买 20 本书');
  const bookIds = [...new Set(rawIds.map((id) => parseId(id, '图书')))];
  if (bookIds.length !== rawIds.length) throw badRequest('存在重复的图书');

  const contactName = optionalString(body.contactName, '联系人', { max: 30 });
  if (!contactName || contactName.length < 2) throw badRequest('请填写正确的联系人姓名');

  const contactPhone = optionalString(body.contactPhone, '联系电话', { max: 20 });
  if (!contactPhone || !PHONE_PATTERN.test(contactPhone)) {
    throw badRequest('请填写正确的联系电话');
  }

  return {
    bookIds,
    contactName,
    contactPhone,
    pickupLocation: optionalString(body.pickupLocation, '自提地点', { max: 120 }),
    note: optionalString(body.note, '交易备注', { max: 300 }),
  };
}

export function validateOrderStatus(body = {}) {
  const status = Object.hasOwn(ORDER_STATUS, body.status) ? body.status : null;
  if (!status) throw badRequest('订单状态取值不合法');
  const reason = optionalString(body.reason, '取消原因', { max: 200 });
  if (status === 'cancelled' && (!reason || reason.length < 2)) {
    throw badRequest('取消订单时请填写原因');
  }
  return { status, reason };
}
