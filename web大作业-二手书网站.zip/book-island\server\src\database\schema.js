import { getDb } from './db.js';

const NOW = `(strftime('%Y-%m-%dT%H:%M:%fZ','now'))`;

const SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin')),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'disabled')),
  bio TEXT,
  campus TEXT,
  created_at TEXT NOT NULL DEFAULT ${NOW},
  updated_at TEXT NOT NULL DEFAULT ${NOW}
);

CREATE TABLE IF NOT EXISTS categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL UNIQUE,
  slug TEXT NOT NULL UNIQUE,
  description TEXT,
  icon TEXT,
  sort_order INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS books (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  seller_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category_id INTEGER NOT NULL REFERENCES categories(id),
  title TEXT NOT NULL,
  author TEXT NOT NULL,
  isbn TEXT NOT NULL,
  publisher TEXT,
  publish_year INTEGER,
  original_price REAL,
  price REAL NOT NULL CHECK (price >= 0),
  book_condition TEXT NOT NULL CHECK (book_condition IN ('like_new', 'good', 'fair')),
  description TEXT,
  pickup_location TEXT,
  cover_path TEXT,
  review_status TEXT NOT NULL DEFAULT 'pending' CHECK (review_status IN ('pending', 'approved', 'rejected')),
  review_note TEXT,
  reviewed_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
  reviewed_at TEXT,
  sale_status TEXT NOT NULL DEFAULT 'available' CHECK (sale_status IN ('available', 'reserved', 'sold', 'offline')),
  sold_at TEXT,
  seed_key TEXT UNIQUE,
  created_at TEXT NOT NULL DEFAULT ${NOW},
  updated_at TEXT NOT NULL DEFAULT ${NOW}
);

CREATE INDEX IF NOT EXISTS idx_books_public ON books (review_status, sale_status);
CREATE INDEX IF NOT EXISTS idx_books_category ON books (category_id);
CREATE INDEX IF NOT EXISTS idx_books_seller ON books (seller_id);
CREATE INDEX IF NOT EXISTS idx_books_created ON books (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_books_price ON books (price);

CREATE TABLE IF NOT EXISTS cart_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  book_id INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE,
  quantity INTEGER NOT NULL DEFAULT 1 CHECK (quantity = 1),
  created_at TEXT NOT NULL DEFAULT ${NOW},
  UNIQUE (user_id, book_id)
);

CREATE INDEX IF NOT EXISTS idx_cart_user ON cart_items (user_id);

CREATE TABLE IF NOT EXISTS orders (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_no TEXT NOT NULL UNIQUE,
  buyer_id INTEGER NOT NULL REFERENCES users(id),
  seller_id INTEGER NOT NULL REFERENCES users(id),
  total_amount REAL NOT NULL CHECK (total_amount >= 0),
  status TEXT NOT NULL DEFAULT 'pending_seller' CHECK (status IN ('pending_seller', 'in_progress', 'completed', 'cancelled')),
  contact_name TEXT NOT NULL,
  contact_phone TEXT NOT NULL,
  pickup_location TEXT,
  note TEXT,
  cancel_reason TEXT,
  created_at TEXT NOT NULL DEFAULT ${NOW},
  updated_at TEXT NOT NULL DEFAULT ${NOW}
);

CREATE INDEX IF NOT EXISTS idx_orders_buyer ON orders (buyer_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_seller ON orders (seller_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_orders_status ON orders (status);

CREATE TABLE IF NOT EXISTS order_items (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  order_id INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  book_id INTEGER REFERENCES books(id) ON DELETE SET NULL,
  title_snapshot TEXT NOT NULL,
  author_snapshot TEXT NOT NULL,
  price REAL NOT NULL CHECK (price >= 0),
  condition_snapshot TEXT NOT NULL,
  cover_snapshot TEXT
);

CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items (order_id);

`;

export function initSchema() {
  const db = getDb();
  db.exec(SCHEMA_SQL);
  return db;
}
