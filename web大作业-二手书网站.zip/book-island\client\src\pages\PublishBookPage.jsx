import { useEffect, useRef, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import {
  ArrowLeft,
  ImagePlus,
  Info,
  Loader2,
  Send,
  ShieldCheck,
  Trash2,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import * as booksApi from '../services/books';
import * as categoriesApi from '../services/categories';
import { ErrorMessage, LoadingSpinner } from '../components/common';
import { useDocumentTitle } from '../hooks/useDocumentTitle';
import { CONDITION_OPTIONS, formatPrice } from '../utils/format';
import { hasErrors, validateBookForm } from '../utils/validation';

const INITIAL_FORM = {
  title: '',
  author: '',
  isbn: '',
  publisher: '',
  publishYear: '',
  categoryId: '',
  originalPrice: '',
  price: '',
  condition: 'good',
  description: '',
  pickupLocation: '',
};

export default function PublishBookPage() {
  const { id } = useParams();
  const isEditing = Boolean(id);
  useDocumentTitle(isEditing ? '编辑图书' : '发布闲置');
  const { user } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const fileInputRef = useRef(null);

  const [form, setForm] = useState(INITIAL_FORM);
  const [categories, setCategories] = useState([]);
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [loading, setLoading] = useState(isEditing);
  const [submitting, setSubmitting] = useState(false);
  const [coverFile, setCoverFile] = useState(null);
  const [coverPreview, setCoverPreview] = useState('');
  const [existingCover, setExistingCover] = useState('');

  useEffect(() => {
    categoriesApi
      .list()
      .then(setCategories)
      .catch(() => setServerError('分类加载失败，请刷新页面重试'));
  }, []);

  useEffect(() => {
    if (!isEditing) return;
    let active = true;
    setLoading(true);
    booksApi
      .detail(id)
      .then((book) => {
        if (!active) return;
        if (book.seller?.id !== user?.id) {
          setServerError('只能编辑自己发布的图书');
          return;
        }
        setForm({
          title: book.title ?? '',
          author: book.author ?? '',
          isbn: book.isbn ?? '',
          publisher: book.publisher ?? '',
          publishYear: book.publishYear ?? '',
          categoryId: String(book.category?.id ?? ''),
          originalPrice: book.originalPrice ?? '',
          price: book.price ?? '',
          condition: book.condition ?? 'good',
          description: book.description ?? '',
          pickupLocation: book.pickupLocation ?? '',
        });
        setExistingCover(book.coverPath ?? '');
      })
      .catch((loadError) => {
        if (active) setServerError(loadError.message);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [id, isEditing, user?.id]);

  useEffect(
    () => () => {
      if (coverPreview) URL.revokeObjectURL(coverPreview);
    },
    [coverPreview],
  );

  const update = (field) => (event) => {
    setForm((current) => ({ ...current, [field]: event.target.value }));
    setErrors((current) => ({ ...current, [field]: undefined }));
    setServerError('');
  };

  const handleFile = (event) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
      setErrors((current) => ({ ...current, cover: '封面仅支持 JPG、PNG 或 WebP' }));
      return;
    }
    if (file.size > 3 * 1024 * 1024) {
      setErrors((current) => ({ ...current, cover: '封面图片不能超过 3MB' }));
      return;
    }
    if (coverPreview) URL.revokeObjectURL(coverPreview);
    setCoverFile(file);
    setCoverPreview(URL.createObjectURL(file));
    setErrors((current) => ({ ...current, cover: undefined }));
  };

  const removeCover = () => {
    if (coverPreview) URL.revokeObjectURL(coverPreview);
    setCoverFile(null);
    setCoverPreview('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const submit = async (event) => {
    event.preventDefault();
    const nextErrors = validateBookForm(form);
    setErrors(nextErrors);
    if (hasErrors(nextErrors)) {
      const first = document.querySelector('.is-invalid');
      first?.focus();
      return;
    }

    setSubmitting(true);
    setServerError('');
    const payload = new FormData();
    Object.entries(form).forEach(([key, value]) => {
      payload.append(key, value === null || value === undefined ? '' : String(value));
    });
    if (coverFile) payload.append('cover', coverFile);

    try {
      const book = isEditing ? await booksApi.update(id, payload) : await booksApi.create(payload);
      toast.success(isEditing ? '修改已提交，等待管理员重新审核' : '发布成功，等待管理员审核');
      navigate(`/books/${book.id}`);
    } catch (submitError) {
      setServerError(submitError.message);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } finally {
      setSubmitting(false);
    }
  };

  const previewPrice = Number(form.price);
  const previewOriginal = Number(form.originalPrice);
  const previewDiscount =
    previewOriginal > 0 && previewPrice > 0 && previewOriginal > previewPrice
      ? Math.round((1 - previewPrice / previewOriginal) * 100)
      : null;

  if (loading) {
    return (
      <div className="container page-section">
        <LoadingSpinner label="正在读取图书信息…" />
      </div>
    );
  }

  if (serverError && isEditing && !form.title) {
    return (
      <div className="container page-section">
        <ErrorMessage message={serverError} />
        <Link to="/profile?tab=books" className="button button--secondary" style={{ marginTop: 16 }}>
          <ArrowLeft size={16} /> 返回我的发布
        </Link>
      </div>
    );
  }

  return (
    <div className="container page-section">
      <Link to={isEditing ? `/books/${id}` : '/profile?tab=books'} className="back-link">
        <ArrowLeft size={16} /> {isEditing ? '返回图书详情' : '返回个人中心'}
      </Link>

      <header className="page-header">
        <div>
          <span className="eyebrow eyebrow--plain">{isEditing ? '更新图书信息' : '让旧书继续旅行'}</span>
          <h1>{isEditing ? '编辑图书' : '发布闲置图书'}</h1>
          <p>
            信息越完整，越快找到合适的同学。提交后会进入待审核状态，管理员通过后才会公开展示。
          </p>
        </div>
      </header>

      {serverError && (
        <div className="alert alert--danger" role="alert">
          {serverError}
        </div>
      )}

      <form className="publish-layout" onSubmit={submit} noValidate>
        <div className="publish-form">
          <section className="panel">
            <h2>基本信息</h2>
            <div className="form-grid">
              <div className="field field--full">
                <label htmlFor="book-title">
                  书名 <span className="required">*</span>
                </label>
                <input
                  id="book-title"
                  value={form.title}
                  onChange={update('title')}
                  className={errors.title ? 'is-invalid' : ''}
                  placeholder="例如 数据结构（C语言版）"
                  maxLength={120}
                  aria-invalid={Boolean(errors.title)}
                />
                {errors.title && <p className="field-error">{errors.title}</p>}
              </div>

              <div className="field">
                <label htmlFor="book-author">
                  作者 <span className="required">*</span>
                </label>
                <input
                  id="book-author"
                  value={form.author}
                  onChange={update('author')}
                  className={errors.author ? 'is-invalid' : ''}
                  placeholder="例如 严蔚敏"
                  maxLength={80}
                  aria-invalid={Boolean(errors.author)}
                />
                {errors.author && <p className="field-error">{errors.author}</p>}
              </div>

              <div className="field">
                <label htmlFor="book-isbn">
                  ISBN <span className="required">*</span>
                </label>
                <input
                  id="book-isbn"
                  value={form.isbn}
                  onChange={update('isbn')}
                  className={errors.isbn ? 'is-invalid' : ''}
                  placeholder="10 位或 13 位 ISBN"
                  maxLength={30}
                  aria-invalid={Boolean(errors.isbn)}
                />
                {errors.isbn && <p className="field-error">{errors.isbn}</p>}
              </div>

              <div className="field">
                <label htmlFor="book-category">
                  图书分类 <span className="required">*</span>
                </label>
                <select
                  id="book-category"
                  value={form.categoryId}
                  onChange={update('categoryId')}
                  className={errors.categoryId ? 'is-invalid' : ''}
                  aria-invalid={Boolean(errors.categoryId)}
                >
                  <option value="">请选择分类</option>
                  {categories.map((category) => (
                    <option key={category.id} value={category.id}>
                      {category.name}
                    </option>
                  ))}
                </select>
                {errors.categoryId && <p className="field-error">{errors.categoryId}</p>}
              </div>

              <div className="field">
                <label htmlFor="book-publisher">出版社</label>
                <input
                  id="book-publisher"
                  value={form.publisher}
                  onChange={update('publisher')}
                  placeholder="例如 清华大学出版社"
                  maxLength={80}
                />
              </div>

              <div className="field">
                <label htmlFor="book-year">出版年份</label>
                <input
                  id="book-year"
                  type="number"
                  min="1900"
                  max={new Date().getFullYear() + 1}
                  value={form.publishYear}
                  onChange={update('publishYear')}
                  className={errors.publishYear ? 'is-invalid' : ''}
                  placeholder="例如 2018"
                  aria-invalid={Boolean(errors.publishYear)}
                />
                {errors.publishYear && <p className="field-error">{errors.publishYear}</p>}
              </div>
            </div>
          </section>

          <section className="panel">
            <h2>价格与成色</h2>
            <div className="form-grid">
              <div className="field">
                <label htmlFor="book-original-price">新书参考价（元）</label>
                <input
                  id="book-original-price"
                  type="number"
                  min="0"
                  step="any"
                  value={form.originalPrice}
                  onChange={update('originalPrice')}
                  className={errors.originalPrice ? 'is-invalid' : ''}
                  placeholder="例如 39.50"
                  aria-invalid={Boolean(errors.originalPrice)}
                />
                {errors.originalPrice && <p className="field-error">{errors.originalPrice}</p>}
              </div>

              <div className="field">
                <label htmlFor="book-price">
                  二手售价（元） <span className="required">*</span>
                </label>
                <input
                  id="book-price"
                  type="number"
                  min="0.01"
                  step="any"
                  value={form.price}
                  onChange={update('price')}
                  className={errors.price ? 'is-invalid' : ''}
                  placeholder="例如 18.00"
                  aria-invalid={Boolean(errors.price)}
                />
                {errors.price && <p className="field-error">{errors.price}</p>}
              </div>

              <fieldset className="field field--full condition-field">
                <legend>
                  成色等级 <span className="required">*</span>
                </legend>
                <div className="condition-options">
                  {CONDITION_OPTIONS.map((option) => (
                    <label
                      key={option.value}
                      className={`condition-option${form.condition === option.value ? ' is-selected' : ''}`}
                    >
                      <input
                        type="radio"
                        name="condition"
                        value={option.value}
                        checked={form.condition === option.value}
                        onChange={update('condition')}
                      />
                      <span>
                        <b>{option.label}</b>
                        <small>{option.description}</small>
                      </span>
                    </label>
                  ))}
                </div>
                {errors.condition && <p className="field-error">{errors.condition}</p>}
              </fieldset>
            </div>
          </section>

          <section className="panel">
            <h2>交易信息</h2>
            <div className="form-grid">
              <div className="field field--full">
                <label htmlFor="book-description">图书描述</label>
                <textarea
                  id="book-description"
                  rows={5}
                  value={form.description}
                  onChange={update('description')}
                  maxLength={2000}
                  placeholder="描述书况、笔记情况、是否缺页、附赠资料等，帮助买家判断。"
                />
                <p className="field-hint">已填写 {form.description.length} / 2000 字</p>
              </div>

              <div className="field field--full">
                <label htmlFor="book-pickup">校园自提地点</label>
                <input
                  id="book-pickup"
                  value={form.pickupLocation}
                  onChange={update('pickupLocation')}
                  maxLength={120}
                  placeholder="例如 图书馆东门 / 学生公寓 6 号楼"
                />
                <p className="field-hint">请选择校内公共区域，方便双方当面验书。</p>
              </div>
            </div>
          </section>

          <section className="panel">
            <h2>图书封面</h2>
            <div className="cover-upload">
              <div className="cover-upload__preview">
                {coverPreview || existingCover ? (
                  <img
                    src={coverPreview || existingCover}
                    alt="封面预览"
                    onError={(event) => {
                      event.currentTarget.src = '/covers/default.svg';
                    }}
                  />
                ) : (
                  <span className="cover-upload__placeholder">
                    <ImagePlus size={26} />
                    暂无封面
                  </span>
                )}
              </div>
              <div className="cover-upload__actions">
                <input
                  ref={fileInputRef}
                  id="book-cover"
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  onChange={handleFile}
                  className="sr-only"
                />
                <button
                  type="button"
                  className="button button--secondary"
                  onClick={() => fileInputRef.current?.click()}
                >
                  <ImagePlus size={16} /> {coverPreview || existingCover ? '更换封面' : '上传封面'}
                </button>
                {(coverPreview || existingCover) && (
                  <button type="button" className="button button--ghost" onClick={removeCover}>
                    <Trash2 size={15} /> 移除
                  </button>
                )}
                <p className="field-hint">支持 JPG、PNG、WebP，大小不超过 3MB。不上传则使用默认封面。</p>
                {errors.cover && <p className="field-error">{errors.cover}</p>}
              </div>
            </div>
          </section>

          <div className="publish-actions">
            <button type="submit" className="button button--primary button--lg" disabled={submitting}>
              {submitting ? <Loader2 size={17} className="loading__icon" /> : <Send size={17} />}
              {submitting ? '正在提交…' : isEditing ? '保存修改并提交审核' : '发布图书'}
            </button>
            <button
              type="button"
              className="button button--ghost button--lg"
              onClick={() => navigate(-1)}
              disabled={submitting}
            >
              取消
            </button>
          </div>
        </div>

        <aside className="publish-aside">
          <div className="panel preview-card">
            <span className="eyebrow eyebrow--plain">信息预览</span>
            <div className="preview-card__cover">
              {coverPreview || existingCover ? (
                <img src={coverPreview || existingCover} alt="" />
              ) : (
                <img src="/covers/default.svg" alt="" />
              )}
            </div>
            <h3>{form.title || '你的书名'}</h3>
            <p className="muted">{form.author || '作者'}</p>
            <div className="preview-card__price">
              <strong className="price">{formatPrice(previewPrice || 0)}</strong>
              {previewOriginal > 0 && <s>{formatPrice(previewOriginal)}</s>}
            </div>
            {previewDiscount && <span className="discount">比原价低 {previewDiscount}%</span>}
            <p className="muted">
              {CONDITION_OPTIONS.find((item) => item.value === form.condition)?.label} ·{' '}
              {form.pickupLocation || '校内自提'}
            </p>
          </div>

          <div className="panel tips-panel">
            <h3>
              <ShieldCheck size={17} /> 发布提示
            </h3>
            <ul>
              <li>真实填写 ISBN 和出版社，方便同学搜索。</li>
              <li>如实描述笔记、折痕和缺页情况，减少交易纠纷。</li>
              <li>上传清晰封面，避免使用来源不明的图片。</li>
              <li>发布后默认待审核，修改信息会重新触发审核。</li>
            </ul>
            <p className="panel__hint">
              <Info size={14} /> 禁止发布盗版、复印教材或与图书无关的商品。
            </p>
          </div>
        </aside>
      </form>
    </div>
  );
}
