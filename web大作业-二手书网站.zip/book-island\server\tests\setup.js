import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const testsDir = path.dirname(fileURLToPath(import.meta.url));
const tmpDir = path.join(testsDir, 'tmp');
fs.mkdirSync(tmpDir, { recursive: true });

process.env.NODE_ENV = 'test';
process.env.JWT_SECRET = 'book-island-test-secret-do-not-use-in-production';
process.env.JWT_EXPIRES_IN = '1h';
process.env.DB_PATH = path.join(tmpDir, 'test.db');
process.env.ADMIN_USERNAME = 'admin';
process.env.ADMIN_EMAIL = 'admin@test.local';
process.env.ADMIN_PASSWORD = 'Admin@12345';
process.env.DEMO_PASSWORD = 'Demo@12345';
process.env.CLIENT_ORIGIN = 'http://localhost:5173';

const { initDatabase } = await import('../src/database/db.js');
const { resetTestDatabase } = await import('./reset.js');

initDatabase();
resetTestDatabase();
