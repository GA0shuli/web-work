import { getDb } from '../database/db.js';
import { BOOK_CONDITIONS } from '../config/constants.js';
import { notFound } from '../utils/AppError.js';
import { serializeBook } from '../utils/serializers.js';

// 这四个权重只影响排序，不参与过滤，改起来不会影响业务正确性
const WEIGHTS = { keyword: 0.4, price: 0.25, condition: 0.2, freshness: 0.15 };

const CONDITION_ORDER = ['fair', 'good', 'like_new'];

function clamp(value, min = 0, max = 100) {
  return Math.min(max, Math.max(min, value));
}

function round(value) {
  return Math.round((value + Number.EPSILON) * 100) / 100;
}

// 关键词只做“包含”判断：书名最优先，其次作者、出版社、简介
export function keywordScore(row, keyword) {
  const raw = String(keyword ?? '').trim().toLowerCase();
  if (!raw) return { score: 60, reasons: [] };

  // 输入 ISBN 时直接精确匹配，比模糊包含更准
  const digits = raw.replace(/[^0-9x]/g, '');
  if (digits.length >= 10 && digits === String(row.isbn ?? '')) {
    return { score: 100, reasons: ['ISBN 完全匹配'] };
  }

  const title = String(row.title ?? '').toLowerCase();
  if (title.includes(raw)) return { score: 100, reasons: [`书名包含“${keyword}”`] };

  const author = String(row.author ?? '').toLowerCase();
  if (author.includes(raw)) return { score: 85, reasons: [`作者是“${row.author}”`] };

  const publisher = String(row.publisher ?? '').toLowerCase();
  if (publisher.includes(raw)) return { score: 70, reasons: [`出版社是“${row.publisher}”`] };

  const description = String(row.description ?? '').toLowerCase();
  if (description.includes(raw)) return { score: 55, reasons: ['简介中提到了该关键词'] };

  if (row.category_name && raw.includes(String(row.category_name).toLowerCase())) {
    return { score: 50, reasons: [`属于${row.category_name}分类`] };
  }
  return { score: 0, reasons: [] };
}

export function freshnessScore(createdAt) {
  const time = new Date(createdAt).getTime();
  if (!Number.isFinite(time)) return 60;
  const days = Math.max(0, (Date.now() - time) / 86400000);
  if (days <= 7) return 100;
  return clamp(Math.round(100 - (days - 7) * 3));
}

function buildCandidateRows({ categoryId, maxPrice, minCondition, viewerId }) {
  const db = getDb();
  const where = ["b.review_status = 'approved'", "b.sale_status = 'available'"];
  const params = {};

  if (categoryId) {
    where.push('b.category_id = @categoryId');
    params.categoryId = categoryId;
  }
  if (maxPrice) {
    where.push('b.price <= @maxPrice');
    params.maxPrice = maxPrice;
  }
  const minRank = BOOK_CONDITIONS[minCondition]?.rank ?? 0;
  const allowed = CONDITION_ORDER.filter((item) => BOOK_CONDITIONS[item].rank >= minRank);
  where.push(`b.book_condition IN (${allowed.map((c, i) => `@cond${i}`).join(', ')})`);
  allowed.forEach((condition, index) => {
    params[`cond${index}`] = condition;
  });
  if (viewerId) params.viewerId = viewerId;

  return db
    .prepare(
      `SELECT b.*, c.name AS category_name, c.slug AS category_slug,
              u.username AS seller_username, u.campus AS seller_campus
       FROM books b
       JOIN categories c ON c.id = b.category_id
       JOIN users u ON u.id = b.seller_id
       WHERE ${where.join(' AND ')}`,
    )
    .all(params);
}

export function recommendBooks({ keyword, categoryId, maxPrice, minCondition, limit }, viewerId = null) {
  const rows = buildCandidateRows({ categoryId, maxPrice, minCondition, viewerId });

  const scored = rows.map((row) => {
    const price = Number(row.price);
    const keywordPart = keywordScore(row, keyword);
    const pricePart = maxPrice ? clamp(100 - (price / maxPrice) * 60, 20, 100) : 60;
    const conditionPart = BOOK_CONDITIONS[row.book_condition]?.score ?? 50;
    const freshPart = freshnessScore(row.created_at);

    const reasons = [...keywordPart.reasons];
    if (maxPrice) {
      reasons.push(`售价 ¥${price.toFixed(2)} 在预算 ¥${maxPrice.toFixed(2)} 内`);
    }
    if (row.original_price && row.original_price > price) {
      reasons.push(`比原价低 ${Math.round((1 - price / row.original_price) * 100)}%`);
    }
    if (row.book_condition === 'like_new') reasons.push('成色接近全新');
    if (freshPart === 100) reasons.push('近 7 天内发布');

    const total = round(
      keywordPart.score * WEIGHTS.keyword +
        pricePart * WEIGHTS.price +
        conditionPart * WEIGHTS.condition +
        freshPart * WEIGHTS.freshness,
    );

    return serializeBook(row, {
      score: total,
      scoreBreakdown: {
        keyword: round(keywordPart.score),
        price: round(pricePart),
        condition: round(conditionPart),
        freshness: round(freshPart),
      },
      reasons,
      priceComparison: {
        savingsPercent:
          row.original_price && row.original_price > price
            ? Math.round((1 - price / row.original_price) * 100)
            : null,
      },
    });
  });

  const ranked = scored
    .filter((item) => (keyword ? item.scoreBreakdown.keyword > 0 : true))
    .sort((a, b) => b.score - a.score || a.price - b.price);
  const items = ranked.slice(0, limit);
  const prices = ranked.map((item) => item.price);

  return {
    query: { keyword: keyword ?? null, categoryId: categoryId ?? null, maxPrice: maxPrice ?? null, minCondition, limit },
    items,
    summary: {
      total: ranked.length,
      minPrice: prices.length ? Math.min(...prices) : null,
      maxPrice: prices.length ? Math.max(...prices) : null,
      avgPrice: prices.length
        ? Number((prices.reduce((sum, price) => sum + price, 0) / prices.length).toFixed(2))
        : null,
    },
    algorithm: {
      formula: '总分 = 0.40 × 关键词匹配 + 0.25 × 价格 + 0.20 × 成色 + 0.15 × 新鲜度',
      weights: WEIGHTS,
      note: '先按分类、预算、成色做硬性过滤，再用分数排序；分数不参与下单校验。',
    },
  };
}

export function similarBooks(bookId, viewerId = null, limit = 6) {
  const db = getDb();
  const parent = db
    .prepare("SELECT * FROM books WHERE id = ? AND review_status = 'approved'")
    .get(bookId);
  if (!parent) throw notFound('图书不存在');

  const rows = db
    .prepare(
      `SELECT b.*, c.name AS category_name, c.slug AS category_slug,
              u.username AS seller_username, u.campus AS seller_campus
       FROM books b
       JOIN categories c ON c.id = b.category_id
       JOIN users u ON u.id = b.seller_id
       WHERE b.id <> @bookId AND b.review_status = 'approved' AND b.sale_status = 'available'`,
    )
    .all({ bookId });

  const items = rows
    .map((row) => {
      const reasons = [];
      let similarity = 0;
      if (row.isbn && row.isbn === parent.isbn) {
        similarity += 40;
        reasons.push('ISBN 相同');
      }
      if (row.category_id === parent.category_id) {
        similarity += 35;
        reasons.push('同类教材');
      }
      if (row.author && row.author === parent.author) {
        similarity += 25;
        reasons.push('同一作者');
      }
      return serializeBook(row, { similarity, reasons });
    })
    .filter((item) => item.similarity >= 35)
    .sort((a, b) => b.similarity - a.similarity || a.price - b.price)
    .slice(0, limit);

  return { items };
}

export const recommendationWeights = WEIGHTS;
