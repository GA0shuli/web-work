import { ChevronLeft, ChevronRight } from 'lucide-react';

export function buildPageList(current, total) {
  if (total <= 7) return Array.from({ length: total }, (_, index) => index + 1);
  const pages = [...new Set([1, total, current - 1, current, current + 1])]
    .filter((page) => page >= 1 && page <= total)
    .sort((a, b) => a - b);
  const result = [];
  for (let index = 0; index < pages.length; index += 1) {
    if (index > 0 && pages[index] - pages[index - 1] > 1) result.push('...');
    result.push(pages[index]);
  }
  return result;
}

export default function Pagination({ page = 1, totalPages = 1, onChange, total = 0 }) {
  if (totalPages <= 1) return null;
  const items = buildPageList(page, totalPages);

  return (
    <nav className="pagination" aria-label="分页导航">
      <button
        type="button"
        className="pagination__button"
        onClick={() => onChange(page - 1)}
        disabled={page <= 1}
        aria-label="上一页"
      >
        <ChevronLeft size={16} />
      </button>
      {items.map((item, index) =>
        item === '...' ? (
          <span key={`gap-${index}`} className="pagination__gap">
            …
          </span>
        ) : (
          <button
            key={item}
            type="button"
            className={`pagination__button${item === page ? ' is-active' : ''}`}
            onClick={() => onChange(item)}
            aria-current={item === page ? 'page' : undefined}
            aria-label={`第 ${item} 页`}
          >
            {item}
          </button>
        ),
      )}
      <button
        type="button"
        className="pagination__button"
        onClick={() => onChange(page + 1)}
        disabled={page >= totalPages}
        aria-label="下一页"
      >
        <ChevronRight size={16} />
      </button>
      {total > 0 && <span className="pagination__total">共 {total} 本</span>}
    </nav>
  );
}
