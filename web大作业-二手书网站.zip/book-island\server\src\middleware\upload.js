import multer from 'multer';
import { ALLOWED_IMAGE_TYPES, MAX_UPLOAD_BYTES } from '../config/constants.js';
import { badRequest } from '../utils/AppError.js';

const storage = multer.memoryStorage();

export const coverUpload = multer({
  storage,
  limits: {
    fileSize: MAX_UPLOAD_BYTES,
    files: 1,
    fields: 20,
  },
  fileFilter(req, file, callback) {
    if (!ALLOWED_IMAGE_TYPES.includes(file.mimetype)) {
      return callback(badRequest('封面仅支持 JPG、PNG 或 WebP 格式'));
    }
    return callback(null, true);
  },
}).single('cover');
