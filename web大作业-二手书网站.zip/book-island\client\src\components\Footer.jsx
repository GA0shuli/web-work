import { Link } from 'react-router-dom';
import { BookOpen, Mail, MapPin } from 'lucide-react';
import { Logo } from './common';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="container footer__grid">
        <div className="footer__brand">
          <Logo />
          <p>
            书屿是面向校园的二手书交易平台。让闲置教材在同学之间继续旅行，用更轻的成本完成一门课程。
          </p>
          <span className="footer__note">
            <BookOpen size={15} /> 课程作业演示项目 · 线下自提交易
          </span>
        </div>

        <div className="footer__links">
          <h3>逛一逛</h3>
          <Link to="/books">全部图书</Link>
          <Link to="/recommendations">教材智能匹配</Link>
          <Link to="/publish">发布闲置</Link>
          <Link to="/orders">我的订单</Link>
        </div>

        <div className="footer__links">
          <h3>交易说明</h3>
          <Link to="/books?condition=like_new">近全新教材</Link>
          <Link to="/books?sort=price_asc">低价优先</Link>
          <span>校园自提 · 当面验书</span>
          <span>订单状态全程记录</span>
        </div>

        <div className="footer__contact">
          <h3>联系我们</h3>
          <p>
            <Mail size={15} /> support@bookisland.local
          </p>
          <p>
            <MapPin size={15} /> 华中师范大学南湖校区 · 学生服务中心
          </p>
          <p className="footer__small">本平台不接入真实支付，交易请在校内当面完成。</p>
        </div>
      </div>
      <div className="container footer__bottom">
        <span>© {new Date().getFullYear()} 书屿 BookIsland</span>
        <span>用一本旧书，连接两位同学</span>
      </div>
    </footer>
  );
}
