import fs from 'node:fs';
import path from 'node:path';
import { env } from '../config/env.js';
import { closeDatabase, initDatabase } from './db.js';
import { initSchema } from './schema.js';
import { seedDatabase } from './seed.js';

export function bootstrapDatabase({ reset = false } = {}) {
  if (reset && env.dbPath !== ':memory:') {
    closeDatabase();
    for (const suffix of ['', '-wal', '-shm']) {
      fs.rmSync(`${env.dbPath}${suffix}`, { force: true });
    }
  }
  fs.mkdirSync(path.dirname(env.dbPath), { recursive: true });
  fs.mkdirSync(env.uploadsDir, { recursive: true });
  initDatabase();
  initSchema();
  return seedDatabase();
}
