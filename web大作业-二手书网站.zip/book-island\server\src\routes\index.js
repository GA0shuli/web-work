import { Router } from 'express';
import { authRouter } from './auth.routes.js';
import { bookRouter } from './books.routes.js';
import { cartRouter } from './cart.routes.js';
import { categoryRouter } from './categories.routes.js';
import { orderRouter } from './orders.routes.js';
import { userRouter } from './users.routes.js';
import { adminRouter } from './admin.routes.js';
import { attachUser } from '../middleware/auth.js';
import { getPublicStats } from '../services/category.service.js';
import { success } from '../utils/response.js';

export const apiRouter = Router();

apiRouter.get('/health', (req, res) => {
  res.json({
    success: true,
    message: '服务运行正常',
    data: {
      status: 'ok',
      uptimeSeconds: Math.round(process.uptime()),
      timestamp: new Date().toISOString(),
    },
  });
});

apiRouter.get('/stats', (req, res) => success(res, getPublicStats(), '获取平台统计成功'));

apiRouter.use(attachUser);

apiRouter.use('/auth', authRouter);
apiRouter.use('/books', bookRouter);
apiRouter.use('/categories', categoryRouter);
apiRouter.use('/cart', cartRouter);
apiRouter.use('/orders', orderRouter);
apiRouter.use('/users', userRouter);
apiRouter.use('/admin', adminRouter);
