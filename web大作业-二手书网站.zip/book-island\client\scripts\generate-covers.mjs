import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { books, categories } from '../../server/src/database/seed-data.js';

const scriptDir = path.dirname(fileURLToPath(import.meta.url));
const outputDir = path.resolve(scriptDir, '../public/covers');
fs.mkdirSync(outputDir, { recursive: true });

const palettes = {
  computer: ['#1e4335', '#3d7059', '#a9c3ae'],
  literature: ['#6f3a2c', '#a5604a', '#e0b9a2'],
  business: ['#32435c', '#597192', '#b9c8da'],
  language: ['#445333', '#74874f', '#c7d3a4'],
  postgraduate: ['#51395c', '#7d5a8a', '#d4bcdc'],
  math: ['#2b4553', '#4b7286', '#b3ccd7'],
  science: ['#4c4435', '#7d7050', '#d3c6a4'],
  art: ['#5c4132', '#966e51', '#ddc1a6'],
};

function escapeXml(value) {
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function wrapTitle(title) {
  const chars = Array.from(title);
  const lines = [];
  let current = '';
  for (const char of chars) {
    current += char;
    if (Array.from(current).length >= 7) {
      lines.push(current);
      current = '';
    }
    if (lines.length === 3) break;
  }
  if (current && lines.length < 3) lines.push(current);
  if (lines.length === 3) {
    const remaining = chars.slice(Array.from(lines.join('')).length);
    if (remaining.length) {
      lines[2] = `${Array.from(lines[2]).slice(0, 5).join('')}…`;
    }
  }
  return lines;
}

const categoryMap = new Map(categories.map((category) => [category.slug, category]));

for (const book of books) {
  const [dark, mid, light] = palettes[book.category] ?? palettes.computer;
  const category = categoryMap.get(book.category);
  const lines = wrapTitle(book.title);
  const lineHeight = 46;
  const titleTop = 178 - ((lines.length - 1) * lineHeight) / 2;

  const titleSvg = lines
    .map(
      (line, index) =>
        `<text x="150" y="${titleTop + index * lineHeight}" text-anchor="middle" font-family="'Noto Serif SC','Songti SC',serif" font-size="32" font-weight="700" fill="#ffffff">${escapeXml(line)}</text>`,
    )
    .join('\n  ');

  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="300" height="400" viewBox="0 0 300 400" role="img" aria-label="${escapeXml(book.title)}封面">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="${dark}"/>
      <stop offset="1" stop-color="${mid}"/>
    </linearGradient>
    <pattern id="lines" width="18" height="18" patternUnits="userSpaceOnUse" patternTransform="rotate(35)">
      <line x1="0" y1="0" x2="0" y2="18" stroke="${light}" stroke-opacity="0.12" stroke-width="1"/>
    </pattern>
  </defs>
  <rect width="300" height="400" fill="url(#bg)"/>
  <rect width="300" height="400" fill="url(#lines)"/>
  <circle cx="258" cy="58" r="52" fill="${light}" opacity="0.13"/>
  <circle cx="40" cy="352" r="68" fill="${light}" opacity="0.1"/>
  <rect x="26" y="26" width="248" height="348" rx="10" fill="none" stroke="${light}" stroke-opacity="0.35"/>
  <text x="150" y="70" text-anchor="middle" font-family="'Noto Sans SC',sans-serif" font-size="12" letter-spacing="4" fill="${light}">${escapeXml(category?.name ?? '校园二手书')}</text>
  <line x1="105" y1="88" x2="195" y2="88" stroke="${light}" stroke-opacity="0.5"/>
  ${titleSvg}
  <line x1="118" y1="316" x2="182" y2="316" stroke="${light}" stroke-opacity="0.5"/>
  <text x="150" y="344" text-anchor="middle" font-family="'Noto Sans SC',sans-serif" font-size="13" fill="${light}">${escapeXml(Array.from(book.author).slice(0, 12).join(''))}</text>
  <text x="150" y="372" text-anchor="middle" font-family="'Noto Serif SC',serif" font-size="11" letter-spacing="6" fill="${light}" opacity="0.85">书屿 · BOOK ISLAND</text>
</svg>
`;
  fs.writeFileSync(path.join(outputDir, `${book.seedKey}.svg`), svg, 'utf8');
}

const fallback = `<svg xmlns="http://www.w3.org/2000/svg" width="300" height="400" viewBox="0 0 300 400" role="img" aria-label="书屿默认封面">
  <rect width="300" height="400" fill="#e8e2d2"/>
  <rect x="26" y="26" width="248" height="348" rx="10" fill="#f7f3ea" stroke="#c9c0aa"/>
  <path d="M96 166h108v96H96z" fill="none" stroke="#2f6b4a" stroke-width="4"/>
  <path d="M120 166v96M180 166v96" stroke="#2f6b4a" stroke-width="2" opacity="0.4"/>
  <text x="150" y="300" text-anchor="middle" font-family="'Noto Serif SC',serif" font-size="22" fill="#1f2a24">书屿</text>
  <text x="150" y="326" text-anchor="middle" font-family="sans-serif" font-size="11" letter-spacing="3" fill="#6f7b73">BOOK ISLAND</text>
</svg>
`;
fs.writeFileSync(path.join(outputDir, 'default.svg'), fallback, 'utf8');

console.log(`已生成 ${books.length + 1} 个本地封面文件：${outputDir}`);
