import jwt from 'jsonwebtoken';
import { env } from '../config/env.js';
import { getDb } from '../database/db.js';
import { forbidden, unauthorized } from '../utils/AppError.js';

export function publicUser(user) {
  if (!user) return null;
  return {
    id: user.id,
    username: user.username,
    email: user.email,
    role: user.role,
    status: user.status,
    bio: user.bio,
    campus: user.campus,
    createdAt: user.created_at,
    updatedAt: user.updated_at,
  };
}

export function signToken(user) {
  return jwt.sign({ sub: String(user.id), role: user.role }, env.jwtSecret, {
    expiresIn: env.jwtExpiresIn,
  });
}

function cookieOptions() {
  return {
    httpOnly: true,
    sameSite: 'lax',
    secure: env.isProduction,
    path: '/',
    maxAge: 7 * 24 * 60 * 60 * 1000,
  };
}

export function setAuthCookie(res, token) {
  res.cookie(env.cookieName, token, cookieOptions());
}

export function clearAuthCookie(res) {
  res.clearCookie(env.cookieName, { ...cookieOptions(), maxAge: undefined });
}

export function readToken(req) {
  const authorization = req.get('authorization');
  if (authorization && authorization.startsWith('Bearer ')) {
    return authorization.slice(7).trim();
  }
  return req.cookies?.[env.cookieName] ?? null;
}

export function attachUser(req, res, next) {
  req.user = null;
  const token = readToken(req);
  if (!token) return next();

  try {
    const payload = jwt.verify(token, env.jwtSecret);
    const user = getDb()
      .prepare('SELECT * FROM users WHERE id = ?')
      .get(Number(payload.sub));
    if (!user || user.status !== 'active') {
      clearAuthCookie(res);
      return next();
    }
    req.user = user;
    return next();
  } catch {
    clearAuthCookie(res);
    return next();
  }
}

export function requireAuth(req, res, next) {
  if (!req.user) return next(unauthorized());
  return next();
}

export function requireAdmin(req, res, next) {
  if (!req.user) return next(unauthorized());
  if (req.user.role !== 'admin') return next(forbidden('该接口仅限管理员访问'));
  return next();
}
