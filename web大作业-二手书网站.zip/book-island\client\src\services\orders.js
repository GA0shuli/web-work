import api from './api';

export async function create(payload) {
  const response = await api.post('/orders', payload);
  return response.data;
}

export async function list(params = {}) {
  const response = await api.get('/orders', { params });
  return response.data;
}

export async function detail(id) {
  const response = await api.get(`/orders/${id}`);
  return response.data;
}

export async function updateStatus(id, payload) {
  const response = await api.patch(`/orders/${id}/status`, payload);
  return response.data;
}
