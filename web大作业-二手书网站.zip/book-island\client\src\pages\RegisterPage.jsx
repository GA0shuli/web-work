import { useState } from 'react';
import { Link, Navigate, useNavigate, useSearchParams } from 'react-router-dom';
import { Eye, EyeOff, UserPlus } from 'lucide-react';
import AuthShell from '../components/AuthShell';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { useDocumentTitle } from '../hooks/useDocumentTitle';
import { hasErrors, passwordStrength, validateRegister } from '../utils/validation';

export default function RegisterPage() {
  useDocumentTitle('注册');
  const { register, isAuthenticated, loading } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const rawRedirect = searchParams.get('redirect') ?? '/';
  const redirect = rawRedirect.startsWith('/') && !rawRedirect.startsWith('//') ? rawRedirect : '/';

  const [form, setForm] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
  });
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const strength = passwordStrength(form.password);

  if (!loading && isAuthenticated) return <Navigate to={redirect} replace />;

  const update = (field) => (event) => {
    setForm((current) => ({ ...current, [field]: event.target.value }));
    setErrors((current) => ({ ...current, [field]: undefined }));
    setServerError('');
  };

  const submit = async (event) => {
    event.preventDefault();
    const nextErrors = validateRegister(form);
    setErrors(nextErrors);
    if (hasErrors(nextErrors)) return;

    setSubmitting(true);
    setServerError('');
    try {
      const user = await register({
        username: form.username.trim(),
        email: form.email.trim(),
        password: form.password,
      });
      toast.success(`注册成功，欢迎加入书屿，${user.username}`);
      navigate(redirect, { replace: true });
    } catch (error) {
      setServerError(error.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AuthShell
      title="加入书屿"
      subtitle="创建一个账号，开始整理和寻找你的教材。"
      footer={
        <p>
          已有账号？{' '}
          <Link to={`/login${searchParams.get('redirect') ? `?redirect=${encodeURIComponent(redirect)}` : ''}`}>
            直接登录
          </Link>
        </p>
      }
    >
      <form className="form-stack" onSubmit={submit} noValidate>
        {serverError && (
          <div className="alert alert--danger" role="alert">
            {serverError}
          </div>
        )}

        <div className="field">
          <label htmlFor="username">用户名</label>
          <input
            id="username"
            type="text"
            autoComplete="username"
            value={form.username}
            onChange={update('username')}
            className={errors.username ? 'is-invalid' : ''}
            placeholder="3-20 位，支持中文"
            aria-invalid={Boolean(errors.username)}
            aria-describedby={errors.username ? 'username-error' : undefined}
          />
          {errors.username && (
            <p className="field-error" id="username-error">
              {errors.username}
            </p>
          )}
        </div>

        <div className="field">
          <label htmlFor="email">邮箱</label>
          <input
            id="email"
            type="email"
            autoComplete="email"
            value={form.email}
            onChange={update('email')}
            className={errors.email ? 'is-invalid' : ''}
            placeholder="name@campus.edu"
            aria-invalid={Boolean(errors.email)}
            aria-describedby={errors.email ? 'email-error' : undefined}
          />
          {errors.email && (
            <p className="field-error" id="email-error">
              {errors.email}
            </p>
          )}
        </div>

        <div className="field">
          <label htmlFor="register-password">密码</label>
          <div className="password-field">
            <input
              id="register-password"
              type={showPassword ? 'text' : 'password'}
              autoComplete="new-password"
              value={form.password}
              onChange={update('password')}
              className={errors.password ? 'is-invalid' : ''}
              placeholder="至少 8 位，包含字母和数字"
              aria-invalid={Boolean(errors.password)}
              aria-describedby="password-strength"
            />
            <button
              type="button"
              className="password-field__toggle"
              onClick={() => setShowPassword((visible) => !visible)}
              aria-label={showPassword ? '隐藏密码' : '显示密码'}
            >
              {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
            </button>
          </div>
          <div className="strength" id="password-strength" aria-live="polite">
            <div className="strength__bars" aria-hidden="true">
              {[1, 2, 3, 4].map((level) => (
                <span key={level} className={strength.score >= level ? `is-on strength--${strength.score}` : ''} />
              ))}
            </div>
            <small>{form.password ? `密码强度：${strength.label}` : '建议混合字母、数字和符号'}</small>
          </div>
          {errors.password && <p className="field-error">{errors.password}</p>}
        </div>

        <div className="field">
          <label htmlFor="confirm-password">确认密码</label>
          <input
            id="confirm-password"
            type={showPassword ? 'text' : 'password'}
            autoComplete="new-password"
            value={form.confirmPassword}
            onChange={update('confirmPassword')}
            className={errors.confirmPassword ? 'is-invalid' : ''}
            placeholder="再次输入密码"
            aria-invalid={Boolean(errors.confirmPassword)}
            aria-describedby={errors.confirmPassword ? 'confirm-error' : undefined}
          />
          {errors.confirmPassword && (
            <p className="field-error" id="confirm-error">
              {errors.confirmPassword}
            </p>
          )}
        </div>

        <button type="submit" className="button button--primary button--block button--lg" disabled={submitting}>
          <UserPlus size={17} /> {submitting ? '正在创建账号…' : '创建账号'}
        </button>
        <p className="form-note">
          注册即表示你同意校园交易的诚信约定：真实描述书况、按约自提、尊重彼此时间。
        </p>
      </form>
    </AuthShell>
  );
}
