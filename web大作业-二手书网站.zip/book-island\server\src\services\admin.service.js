import { getDb } from '../database/db.js';
import { PAGINATION } from '../config/constants.js';
import { conflict, notFound } from '../utils/AppError.js';
import { serializeBook } from '../utils/serializers.js';
import { getBookDetail } from './book.service.js';
import { escapeLike } from '../utils/validate.js';

export function getAdminStats() {
  const db = getDb();
  const count = (sql, ...params) => db.prepare(sql).get(...params).count;

  const totalUsers = count("SELECT COUNT(*) AS count FROM users WHERE role = 'user'");
  const totalBooks = count('SELECT COUNT(*) AS count FROM books');
  const pendingBooks = count("SELECT COUNT(*) AS count FROM books WHERE review_status = 'pending'");
  const totalOrders = count('SELECT COUNT(*) AS count FROM orders');
  const completedOrders = count("SELECT COUNT(*) AS count FROM orders WHERE status = 'completed'");
  const availableBooks = count(
    "SELECT COUNT(*) AS count FROM books WHERE review_status = 'approved' AND sale_status = 'available'",
  );
  const gmv = db
    .prepare("SELECT COALESCE(SUM(total_amount), 0) AS amount FROM orders WHERE status = 'completed'")
    .get().amount;
  const today = new Date().toISOString().slice(0, 10);
  const todayUsers = count(
    "SELECT COUNT(*) AS count FROM users WHERE role = 'user' AND substr(created_at, 1, 10) = ?",
    today,
  );
  const todayBooks = count('SELECT COUNT(*) AS count FROM books WHERE substr(created_at, 1, 10) = ?', today);
  const todayOrders = count('SELECT COUNT(*) AS count FROM orders WHERE substr(created_at, 1, 10) = ?', today);

  const pendingPreview = db
    .prepare(
      `SELECT b.*, c.name AS category_name, c.slug AS category_slug,
              u.username AS seller_username, u.campus AS seller_campus
       FROM books b
       JOIN categories c ON c.id = b.category_id
       JOIN users u ON u.id = b.seller_id
       WHERE b.review_status = 'pending'
       ORDER BY b.created_at ASC LIMIT 5`,
    )
    .all()
    .map((row) => serializeBook(row));

  return {
    totals: {
      users: totalUsers,
      books: totalBooks,
      pendingBooks,
      orders: totalOrders,
      completedOrders,
      availableBooks,
      gmv: Number(Number(gmv).toFixed(2)),
      todayUsers,
      todayBooks,
      todayOrders,
    },
    pendingPreview,
  };
}

export function listAdminBooks(query = {}) {
  const db = getDb();
  const page = query.page ?? PAGINATION.defaultPage;
  const pageSize = query.pageSize ?? PAGINATION.defaultPageSize;
  const where = [];
  const params = {};

  if (query.q) {
    params.q = `%${escapeLike(query.q)}%`;
    where.push(
      "(b.title LIKE @q ESCAPE '\\' OR b.author LIKE @q ESCAPE '\\' OR b.isbn LIKE @q ESCAPE '\\' OR u.username LIKE @q ESCAPE '\\')",
    );
  }
  if (query.reviewStatus) {
    where.push('b.review_status = @reviewStatus');
    params.reviewStatus = query.reviewStatus;
  }
  if (query.categoryId) {
    where.push('b.category_id = @categoryId');
    params.categoryId = query.categoryId;
  }
  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const total = db
    .prepare(
      `SELECT COUNT(*) AS count FROM books b JOIN users u ON u.id = b.seller_id ${whereSql}`,
    )
    .get(params).count;
  const rows = db
    .prepare(
      `SELECT b.*, c.name AS category_name, c.slug AS category_slug,
              u.username AS seller_username, u.campus AS seller_campus
       FROM books b
       JOIN categories c ON c.id = b.category_id
       JOIN users u ON u.id = b.seller_id
       ${whereSql}
       ORDER BY CASE b.review_status WHEN 'pending' THEN 0 ELSE 1 END, b.created_at DESC
       LIMIT @limit OFFSET @offset`,
    )
    .all({ ...params, limit: pageSize, offset: (page - 1) * pageSize });

  return {
    items: rows.map((row) => serializeBook(row)),
    pagination: {
      page,
      pageSize,
      total,
      totalPages: Math.max(1, Math.ceil(total / pageSize)),
    },
  };
}

export function reviewBook(adminId, bookId, { action, reason }) {
  const db = getDb();
  const book = db.prepare('SELECT * FROM books WHERE id = ?').get(bookId);
  if (!book) throw notFound('图书不存在');
  if (book.sale_status === 'reserved') {
    throw conflict('该图书存在进行中的订单，无法审核操作');
  }

  const now = new Date().toISOString();
  if (action === 'approve') {
    const nextSale = book.sale_status === 'offline' ? 'available' : book.sale_status;
    db.prepare(
      `UPDATE books SET review_status = 'approved', review_note = ?, reviewed_by = ?,
        reviewed_at = ?, sale_status = ?, updated_at = ? WHERE id = ?`,
    ).run(reason ?? null, adminId, now, nextSale, now, bookId);
  } else if (action === 'reject') {
    db.prepare(
      `UPDATE books SET review_status = 'rejected', review_note = ?, reviewed_by = ?,
        reviewed_at = ?, sale_status = 'offline', updated_at = ? WHERE id = ?`,
    ).run(reason, adminId, now, now, bookId);
  } else {
    if (book.sale_status === 'sold') throw conflict('已售出的图书不能下架');
    db.prepare(
      `UPDATE books SET sale_status = 'offline', review_note = ?, reviewed_by = ?,
        reviewed_at = ?, updated_at = ? WHERE id = ?`,
    ).run(reason, adminId, now, now, bookId);
  }

  return getBookDetail(bookId, { id: adminId, role: 'admin' });
}

export function listAdminOrders(query = {}) {
  const db = getDb();
  const page = query.page ?? 1;
  const pageSize = query.pageSize ?? 20;
  const where = [];
  const params = {};
  if (query.q) {
    params.q = `%${escapeLike(query.q)}%`;
    where.push(
      "(o.order_no LIKE @q ESCAPE '\\' OR bu.username LIKE @q ESCAPE '\\' OR su.username LIKE @q ESCAPE '\\')",
    );
  }
  if (query.status) {
    where.push('o.status = @status');
    params.status = query.status;
  }
  const whereSql = where.length ? `WHERE ${where.join(' AND ')}` : '';
  const total = db
    .prepare(
      `SELECT COUNT(*) AS count FROM orders o
       JOIN users bu ON bu.id = o.buyer_id
       JOIN users su ON su.id = o.seller_id ${whereSql}`,
    )
    .get(params).count;
  const rows = db
    .prepare(
      `SELECT o.*, bu.username AS buyer_username, su.username AS seller_username,
              (SELECT COUNT(*) FROM order_items oi WHERE oi.order_id = o.id) AS item_count,
              (SELECT title_snapshot FROM order_items oi WHERE oi.order_id = o.id ORDER BY oi.id LIMIT 1) AS first_title
       FROM orders o
       JOIN users bu ON bu.id = o.buyer_id
       JOIN users su ON su.id = o.seller_id
       ${whereSql}
       ORDER BY o.created_at DESC
       LIMIT @limit OFFSET @offset`,
    )
    .all({ ...params, limit: pageSize, offset: (page - 1) * pageSize });

  return {
    items: rows.map((row) => ({
      id: row.id,
      orderNo: row.order_no,
      buyer: { id: row.buyer_id, username: row.buyer_username },
      seller: { id: row.seller_id, username: row.seller_username },
      totalAmount: Number(row.total_amount),
      status: row.status,
      itemCount: Number(row.item_count),
      firstTitle: row.first_title,
      contactName: row.contact_name,
      contactPhone: row.contact_phone,
      createdAt: row.created_at,
      updatedAt: row.updated_at,
    })),
    pagination: {
      page,
      pageSize,
      total,
      totalPages: Math.max(1, Math.ceil(total / pageSize)),
    },
  };
}
