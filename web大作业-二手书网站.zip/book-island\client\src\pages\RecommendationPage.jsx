import { useEffect, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Info, Search, Sparkles, Wand2 } from 'lucide-react';
import * as booksApi from '../services/books';
import * as categoriesApi from '../services/categories';
import RecommendationCard from '../components/RecommendationCard';
import { EmptyState, ErrorMessage, LoadingSpinner } from '../components/common';
import { useDocumentTitle } from '../hooks/useDocumentTitle';
import { CONDITION_OPTIONS, formatPrice } from '../utils/format';

const BUDGET_PRESETS = [20, 40, 80, 150];

export default function RecommendationPage() {
  useDocumentTitle('教材智能匹配');
  const [searchParams, setSearchParams] = useSearchParams();
  const [categories, setCategories] = useState([]);
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [reloadKey, setReloadKey] = useState(0);

  const [form, setForm] = useState({
    q: searchParams.get('q') ?? '',
    categoryId: searchParams.get('categoryId') ?? '',
    maxPrice: searchParams.get('maxPrice') ?? '',
    minCondition: searchParams.get('minCondition') ?? 'fair',
  });

  const queryKey = searchParams.toString();

  useEffect(() => {
    categoriesApi
      .list()
      .then(setCategories)
      .catch(() => setCategories([]));
  }, []);

  useEffect(() => {
    setForm({
      q: searchParams.get('q') ?? '',
      categoryId: searchParams.get('categoryId') ?? '',
      maxPrice: searchParams.get('maxPrice') ?? '',
      minCondition: searchParams.get('minCondition') ?? 'fair',
    });
  }, [queryKey, searchParams]);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError(null);
    booksApi
      .recommendations({
        q: searchParams.get('q') || undefined,
        categoryId: searchParams.get('categoryId') || undefined,
        maxPrice: searchParams.get('maxPrice') || undefined,
        minCondition: searchParams.get('minCondition') || 'fair',
        limit: 12,
      })
      .then((data) => {
        if (active) setResult(data);
      })
      .catch((loadError) => {
        if (active) setError(loadError.message);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [queryKey, reloadKey, searchParams]);

  const update = (field) => (event) => {
    setForm((current) => ({ ...current, [field]: event.target.value }));
  };

  const submit = (event) => {
    event.preventDefault();
    const next = new URLSearchParams();
    if (form.q.trim()) next.set('q', form.q.trim());
    if (form.categoryId) next.set('categoryId', form.categoryId);
    if (form.maxPrice) next.set('maxPrice', form.maxPrice);
    if (form.minCondition !== 'fair') next.set('minCondition', form.minCondition);
    const nextKey = next.toString();
    setSearchParams(next);
    if (nextKey === queryKey) setReloadKey((key) => key + 1);
  };

  const reset = () => {
    setSearchParams({});
    setForm({ q: '', categoryId: '', maxPrice: '', minCondition: 'fair' });
  };

  const summary = result?.summary;
  const selectedCondition = CONDITION_OPTIONS.find((item) => item.value === form.minCondition);

  return (
    <div className="container page-section">
      <header className="recommend-hero">
        <div>
          <span className="eyebrow">
            <Sparkles size={15} /> 规则推荐 · 可解释排序
          </span>
          <h1>教材智能匹配</h1>
          <p>
            输入课程名称、教材关键词或 ISBN，结合分类、预算和最低成色筛选可交易图书。
            推荐分数仅用于排序，不替代下单时的交易校验。
          </p>
        </div>
        <div className="recommend-hero__formula" aria-label="推荐公式">
          <Wand2 size={20} />
          <span>总分 =</span>
          <b>0.40</b>关键词 + <b>0.25</b>价格 + <b>0.20</b>成色 + <b>0.15</b>新鲜度
        </div>
      </header>

      <form className="recommend-form panel" onSubmit={submit}>
        <div className="recommend-form__row">
          <div className="field recommend-form__keyword">
            <label htmlFor="recommend-keyword">课程 / 教材关键词 / ISBN</label>
            <div className="input-with-icon">
              <Search size={17} />
              <input
                id="recommend-keyword"
                value={form.q}
                onChange={update('q')}
                maxLength={100}
                placeholder="例如 数据结构、高等数学、9787302147510"
              />
            </div>
          </div>
          <div className="field">
            <label htmlFor="recommend-category">分类</label>
            <select id="recommend-category" value={form.categoryId} onChange={update('categoryId')}>
              <option value="">全部分类</option>
              {categories.map((category) => (
                <option key={category.id} value={category.id}>
                  {category.name}
                </option>
              ))}
            </select>
          </div>
          <div className="field">
            <label htmlFor="recommend-price">预算上限（元）</label>
            <input
              id="recommend-price"
              type="number"
              min="0"
              max="9999"
              step="any"
              value={form.maxPrice}
              onChange={update('maxPrice')}
              placeholder="不设预算"
            />
          </div>
        </div>

        <div className="recommend-form__row recommend-form__row--secondary">
          <div className="field">
            <span className="field-label">预算快捷选择</span>
            <div className="filter-chips">
              {BUDGET_PRESETS.map((preset) => (
                <button
                  key={preset}
                  type="button"
                  className={`chip${String(form.maxPrice) === String(preset) ? ' is-active' : ''}`}
                  onClick={() => setForm((current) => ({ ...current, maxPrice: String(preset) }))}
                >
                  ¥{preset}
                </button>
              ))}
              <button
                type="button"
                className={`chip${form.maxPrice === '' ? ' is-active' : ''}`}
                onClick={() => setForm((current) => ({ ...current, maxPrice: '' }))}
              >
                不限预算
              </button>
            </div>
          </div>
          <fieldset className="field condition-field recommend-form__condition">
            <legend>最低成色</legend>
            <div className="segmented">
              {CONDITION_OPTIONS.map((option) => (
                <label key={option.value} className={form.minCondition === option.value ? 'is-active' : ''}>
                  <input
                    type="radio"
                    name="minCondition"
                    value={option.value}
                    checked={form.minCondition === option.value}
                    onChange={update('minCondition')}
                  />
                  {option.label}
                </label>
              ))}
            </div>
            <p className="field-hint">将过滤低于「{selectedCondition?.label}」成色的图书。</p>
          </fieldset>
          <div className="recommend-form__actions">
            <button type="submit" className="button button--primary button--lg">
              <Sparkles size={17} /> 生成推荐
            </button>
            <button type="button" className="button button--ghost" onClick={reset}>
              重置
            </button>
          </div>
        </div>
      </form>

      {loading ? (
        <LoadingSpinner label="正在计算推荐分数…" />
      ) : error ? (
        <ErrorMessage message={error} onRetry={() => setReloadKey((key) => key + 1)} />
      ) : (
        <div className="recommend-layout">
          <section className="recommend-results" aria-label="推荐结果">
            <div className="results-meta">
              <span>
                <Sparkles size={14} /> 找到 {summary?.total ?? 0} 本符合条件的教材
                {form.q ? ` · 关键词「${form.q}」` : ''}
              </span>
              {summary?.total > 0 && (
                <span>
                  价格 {formatPrice(summary.minPrice)} — {formatPrice(summary.maxPrice)} · 均价{' '}
                  {formatPrice(summary.avgPrice)}
                </span>
              )}
            </div>

            {result?.items.length ? (
              <div className="recommend-list">
                {result.items.map((item) => (
                  <RecommendationCard key={item.id} item={item} showBreakdown />
                ))}
              </div>
            ) : (
              <EmptyState
                icon={Sparkles}
                title="暂时没有匹配的教材"
                description="可以降低成色要求、提高预算，或换一个课程关键词再试试。"
                action={
                  <button type="button" className="button button--secondary" onClick={reset}>
                    清除条件
                  </button>
                }
              />
            )}
          </section>

          <aside className="recommend-aside">
            <div className="panel">
              <h3>
                <Info size={17} /> 推荐如何计算
              </h3>
              <ol className="algorithm-steps">
                <li>先过滤：已售出、待审核、已下架和不符合分类/预算/成色的图书会被排除。</li>
                <li>关键词匹配：ISBN 完全匹配、书名包含、关键词命中与书名相似度。</li>
                <li>价格匹配：售价越接近预算下限得分越高；未设预算时与候选集最高价比较。</li>
                <li>成色与新鲜度：近全新 100、良好 75、一般 50；发布时间越新得分越高。</li>
                <li>加权总分排序，并生成“符合预算”“成色较好”等可解释理由。</li>
              </ol>
            </div>
            <div className="panel panel--accent">
              <h3>温馨提示</h3>
              <p>
                推荐结果只负责帮你排序，不保证交易一定成功。下单时后端仍会校验图书状态、
                卖家身份与金额，避免同时购买或购买自己的图书。
              </p>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
}
