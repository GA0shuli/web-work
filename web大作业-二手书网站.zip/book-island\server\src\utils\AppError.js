export class AppError extends Error {
  constructor(status, message, code = 'REQUEST_ERROR', details = undefined) {
    super(message);
    this.name = 'AppError';
    this.status = status;
    this.code = code;
    this.details = details;
  }
}

export const badRequest = (message = '请求参数有误', details) =>
  new AppError(400, message, 'VALIDATION_ERROR', details);

export const unauthorized = (message = '请先登录后再操作') =>
  new AppError(401, message, 'UNAUTHORIZED');

export const forbidden = (message = '没有权限执行该操作') =>
  new AppError(403, message, 'FORBIDDEN');

export const notFound = (message = '资源不存在') =>
  new AppError(404, message, 'NOT_FOUND');

export const conflict = (message = '操作冲突，请刷新后重试', code = 'CONFLICT') =>
  new AppError(409, message, code);

export const tooManyRequests = (message = '操作过于频繁，请稍后再试') =>
  new AppError(429, message, 'RATE_LIMITED');
