import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
  withCredentials: true,
  timeout: 15000,
});

api.interceptors.response.use(
  (response) => response.data,
  (error) => {
    const payload = error.response?.data;
    const normalized = new Error(payload?.message || '网络异常，请检查网络后重试');
    normalized.status = error.response?.status ?? 0;
    normalized.code = payload?.code;
    normalized.details = payload?.details;
    const url = error.config?.url ?? '';
    if (normalized.status === 401 && !url.startsWith('/auth/')) {
      window.dispatchEvent(new Event('bookisland:unauthorized'));
    }
    return Promise.reject(normalized);
  },
);

export default api;
