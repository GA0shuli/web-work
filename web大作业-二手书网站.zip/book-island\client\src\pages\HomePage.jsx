import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  ArrowRight,
  Atom,
  BadgeCheck,
  BookMarked,
  BookOpen,
  Briefcase,
  Code2,
  GraduationCap,
  Languages,
  MapPin,
  Palette,
  ShieldCheck,
  Sigma,
  Sparkles,
  Users,
} from 'lucide-react';
import SearchBar from '../components/SearchBar';
import BookCard from '../components/BookCard';
import RecommendationCard from '../components/RecommendationCard';
import { BookGridSkeleton, ErrorMessage } from '../components/common';
import * as categoriesApi from '../services/categories';
import * as booksApi from '../services/books';
import { useDocumentTitle } from '../hooks/useDocumentTitle';

const CATEGORY_ICONS = { Atom, BookOpen, Briefcase, Code2, GraduationCap, Languages, Palette, Sigma };

function CategoryIcon({ name, size = 22 }) {
  const Icon = CATEGORY_ICONS[name] ?? BookOpen;
  return <Icon size={size} aria-hidden="true" />;
}

const QUICK_TAGS = ['数据结构', '高等数学', '考研英语', '算法导论'];

const FEATURES = [
  {
    icon: ShieldCheck,
    title: '人工审核上架',
    text: '每本图书经过平台审核，违规或信息不完整的书籍不会进入交易区。',
  },
  {
    icon: MapPin,
    title: '校内当面自提',
    text: '约在图书馆、食堂或宿舍楼下，先验书再确认交易，省去快递等待。',
  },
  {
    icon: BadgeCheck,
    title: '订单状态可追踪',
    text: '从待卖家确认到交易完成，每一步都有记录，取消时自动恢复图书状态。',
  },
  {
    icon: Sparkles,
    title: '教材智能匹配',
    text: '按课程、ISBN、预算和成色计算推荐分数，并给出可解释的推荐理由。',
  },
];

export default function HomePage() {
  useDocumentTitle('首页');
  const navigate = useNavigate();
  const [categories, setCategories] = useState([]);
  const [stats, setStats] = useState(null);
  const [recommended, setRecommended] = useState([]);
  const [hot, setHot] = useState([]);
  const [newest, setNewest] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError(null);
    Promise.all([
      categoriesApi.list(),
      categoriesApi.publicStats(),
      booksApi.recommendations({ minCondition: 'good', limit: 4 }),
      booksApi.list({ sort: 'price_asc', pageSize: 4 }),
      booksApi.list({ sort: 'newest', pageSize: 8 }),
    ])
      .then(([categoryList, statsData, recData, hotData, newestData]) => {
        if (!active) return;
        setCategories(categoryList);
        setStats(statsData);
        setRecommended(recData.items);
        setHot(hotData.items);
        setNewest(newestData.items);
      })
      .catch((loadError) => {
        if (active) setError(loadError.message);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [reloadKey]);

  const handleSearch = (keyword) => {
    navigate(keyword ? `/books?q=${encodeURIComponent(keyword)}` : '/books');
  };

  return (
    <>
      <section className="hero">
        <div className="container hero__inner">
          <div className="hero__content">
            <span className="eyebrow">
              <BookMarked size={15} /> 校园闲置教材 · 循环阅读
            </span>
            <h1>
              让每一本教材，
              <br />
              找到<span>下一位同学</span>
            </h1>
            <p className="hero__lead">
              在书屿，用一杯咖啡的价格带走一门课的教材。真实书况、校内自提、订单全程可追踪，
              让旧书继续旅行。
            </p>
            <SearchBar
              onSearch={handleSearch}
              size="lg"
              placeholder="输入课程名称、书名、作者或 ISBN"
            />
            <div className="hero__tags">
              <span>大家都在找</span>
              {QUICK_TAGS.map((tag) => (
                <button key={tag} type="button" className="tag-link" onClick={() => handleSearch(tag)}>
                  {tag}
                </button>
              ))}
            </div>
            <dl className="hero__stats">
              <div>
                <dt>在售图书</dt>
                <dd>{stats?.books ?? '—'}</dd>
              </div>
              <div>
                <dt>注册同学</dt>
                <dd>{stats?.users ?? '—'}</dd>
              </div>
              <div>
                <dt>完成交易</dt>
                <dd>{stats?.completedOrders ?? '—'}</dd>
              </div>
            </dl>
          </div>

          <div className="hero__visual" aria-hidden="true">
            <div className="hero__glow" />
            <div className="hero__stack">
              <img className="hero__book hero__book--back" src="/covers/seed-05.svg" alt="" />
              <img className="hero__book hero__book--mid" src="/covers/seed-02.svg" alt="" />
              <img className="hero__book hero__book--front" src="/covers/seed-09.svg" alt="" />
            </div>
            <div className="floating-card floating-card--top">
              <BadgeCheck size={17} />
              <span>
                <b>书况已审核</b>
                <small>真实描述 · 无隐藏缺页</small>
              </span>
            </div>
            <div className="floating-card floating-card--bottom">
              <Users size={17} />
              <span>
                <b>同校交易</b>
                <small>约在图书馆，当面验书</small>
              </span>
            </div>
          </div>
        </div>
      </section>

      <section className="page-section page-section--tight">
        <div className="container">
          <div className="section-heading">
            <div>
              <span className="eyebrow eyebrow--plain">按分类逛逛</span>
              <h2>从你的课程出发</h2>
            </div>
            <Link to="/books" className="link-arrow">
              查看全部图书 <ArrowRight size={16} />
            </Link>
          </div>
          {loading ? (
            <div className="category-grid">
              {Array.from({ length: 8 }).map((_, index) => (
                <div className="category-card category-card--skeleton" key={index} />
              ))}
            </div>
          ) : (
            <div className="category-grid">
              {categories.map((category) => (
                <Link
                  key={category.id}
                  to={`/books?category=${category.slug}`}
                  className="category-card"
                >
                  <span className="category-card__icon">
                    <CategoryIcon name={category.icon} />
                  </span>
                  <span className="category-card__text">
                    <b>{category.name}</b>
                    <small>{category.description}</small>
                  </span>
                  <span className="category-card__count">{category.bookCount} 本</span>
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>

      {error && (
        <div className="container">
          <ErrorMessage message={error} onRetry={() => setReloadKey((key) => key + 1)} />
        </div>
      )}

      {!error && (
        <>
          <section className="page-section page-section--tint">
            <div className="container">
              <div className="section-heading">
                <div>
                  <span className="eyebrow eyebrow--plain">
                    <Sparkles size={14} /> 规则推荐
                  </span>
                  <h2>教材精选</h2>
                  <p>综合关键词、价格、成色与发布时间计算推荐分数。</p>
                </div>
                <Link to="/recommendations" className="link-arrow">
                  打开智能匹配 <ArrowRight size={16} />
                </Link>
              </div>
              {loading ? (
                <div className="recommend-grid">
                  {Array.from({ length: 4 }).map((_, index) => (
                    <div className="recommend-card skeleton-card" key={index} />
                  ))}
                </div>
              ) : recommended.length ? (
                <div className="recommend-grid">
                  {recommended.map((item) => (
                    <RecommendationCard key={item.id} item={item} />
                  ))}
                </div>
              ) : (
                <p className="muted">暂时没有满足条件的推荐，请到教材专区调整筛选条件。</p>
              )}
            </div>
          </section>

          <section className="page-section">
            <div className="container">
              <div className="section-heading">
                <div>
                  <span className="eyebrow eyebrow--plain">低价优先</span>
                  <h2>便宜好书</h2>
                </div>
                <Link to="/books?sort=price_asc" className="link-arrow">
                  更多低价书 <ArrowRight size={16} />
                </Link>
              </div>
              {loading ? (
                <BookGridSkeleton count={4} />
              ) : (
                <div className="book-grid book-grid--four">
                  {hot.map((book) => (
                    <BookCard key={book.id} book={book} />
                  ))}
                </div>
              )}
            </div>
          </section>

          <section className="page-section page-section--tint">
            <div className="container">
              <div className="section-heading">
                <div>
                  <span className="eyebrow eyebrow--plain">刚刚上架</span>
                  <h2>最新发布</h2>
                </div>
                <Link to="/books?sort=newest" className="link-arrow">
                  查看全部 <ArrowRight size={16} />
                </Link>
              </div>
              {loading ? (
                <BookGridSkeleton count={8} />
              ) : (
                <div className="book-grid">
                  {newest.map((book) => (
                    <BookCard key={book.id} book={book} />
                  ))}
                </div>
              )}
            </div>
          </section>

          <section className="page-section">
            <div className="container">
              <div className="section-heading">
                <div>
                  <span className="eyebrow eyebrow--plain">为什么选择书屿</span>
                  <h2>把交易做得更踏实</h2>
                </div>
              </div>
              <div className="feature-grid">
                {FEATURES.map(({ icon: Icon, title, text }) => (
                  <div className="feature-card" key={title}>
                    <span className="feature-card__icon">
                      <Icon size={21} />
                    </span>
                    <h3>{title}</h3>
                    <p>{text}</p>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="page-section page-section--cta">
            <div className="container">
              <div className="cta-banner">
              <div>
                <span className="eyebrow eyebrow--light">你的书架，也许正是别人需要的</span>
                <h2>把闲置教材交给下一位同学</h2>
                <p>几分钟完成发布，经审核后即可展示。售价、成色与自提地点都由你决定。</p>
              </div>
              <Link to="/publish" className="button button--amber button--lg">
                发布闲置 <ArrowRight size={17} />
              </Link>
            </div>
            </div>
          </section>
        </>
      )}
    </>
  );
}
