export const BOOK_CONDITIONS = {
  like_new: { label: '近全新', score: 100, rank: 3 },
  good: { label: '良好', score: 75, rank: 2 },
  fair: { label: '一般', score: 50, rank: 1 },
};

export const REVIEW_STATUS = {
  pending: '待审核',
  approved: '已通过',
  rejected: '已驳回',
};

export const SALE_STATUS = {
  available: '可交易',
  reserved: '交易中',
  sold: '已售出',
  offline: '已下架',
};

export const ORDER_STATUS = {
  pending_seller: '待卖家确认',
  in_progress: '交易进行中',
  completed: '已完成',
  cancelled: '已取消',
};

// 允许的状态流转：目标状态 -> 允许的操作者
export const ORDER_TRANSITIONS = {
  pending_seller: {
    in_progress: ['seller'],
    cancelled: ['buyer', 'seller', 'admin'],
  },
  in_progress: {
    completed: ['buyer'],
    cancelled: ['buyer', 'seller', 'admin'],
  },
  completed: {},
  cancelled: {},
};

export const BOOK_SORTS = ['newest', 'oldest', 'price_asc', 'price_desc'];

export const PAGINATION = {
  defaultPage: 1,
  defaultPageSize: 12,
  maxPageSize: 50,
};

export const MAX_UPLOAD_BYTES = 3 * 1024 * 1024;
export const ALLOWED_IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp'];
