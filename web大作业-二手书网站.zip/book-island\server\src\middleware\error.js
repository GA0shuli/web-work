import multer from 'multer';
import { AppError } from '../utils/AppError.js';

export function notFoundHandler(req, res) {
  res.status(404).json({
    success: false,
    message: '接口不存在',
    code: 'NOT_FOUND',
  });
}

export function errorHandler(error, req, res, next) {
  if (res.headersSent) return next(error);

  if (error instanceof multer.MulterError) {
    const message =
      error.code === 'LIMIT_FILE_SIZE' ? '封面图片不能超过 3MB' : '上传的文件不符合要求';
    return res.status(400).json({ success: false, message, code: 'UPLOAD_ERROR' });
  }

  if (error.type === 'entity.parse.failed') {
    return res.status(400).json({ success: false, message: '请求体不是合法的 JSON', code: 'INVALID_JSON' });
  }
  if (error.type === 'entity.too.large') {
    return res.status(413).json({ success: false, message: '请求体过大', code: 'PAYLOAD_TOO_LARGE' });
  }

  const status = error instanceof AppError ? error.status : 500;
  if (status >= 500) {
    console.error('[server-error]', error);
  }

  const payload = {
    success: false,
    message: status >= 500 ? '服务器内部错误，请稍后重试' : error.message,
    code: status >= 500 ? 'INTERNAL_ERROR' : error.code || 'REQUEST_ERROR',
  };
  if (error.details) payload.details = error.details;

  return res.status(status).json(payload);
}
