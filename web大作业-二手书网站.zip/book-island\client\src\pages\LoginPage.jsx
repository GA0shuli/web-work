import { useState } from 'react';
import { Link, Navigate, useNavigate, useSearchParams } from 'react-router-dom';
import { Eye, EyeOff, LogIn } from 'lucide-react';
import AuthShell from '../components/AuthShell';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import { useDocumentTitle } from '../hooks/useDocumentTitle';
import { validateLogin } from '../utils/validation';

export default function LoginPage() {
  useDocumentTitle('登录');
  const { login, isAuthenticated, loading } = useAuth();
  const toast = useToast();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const rawRedirect = searchParams.get('redirect') ?? '/';
  const redirect = rawRedirect.startsWith('/') && !rawRedirect.startsWith('//') ? rawRedirect : '/';

  const [form, setForm] = useState({ identifier: '', password: '' });
  const [errors, setErrors] = useState({});
  const [serverError, setServerError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  if (!loading && isAuthenticated) return <Navigate to={redirect} replace />;

  const update = (field) => (event) => {
    setForm((current) => ({ ...current, [field]: event.target.value }));
    setErrors((current) => ({ ...current, [field]: undefined }));
    setServerError('');
  };

  const submit = async (event) => {
    event.preventDefault();
    const nextErrors = validateLogin(form);
    setErrors(nextErrors);
    if (Object.keys(nextErrors).length) return;

    setSubmitting(true);
    setServerError('');
    try {
      const user = await login({ identifier: form.identifier.trim(), password: form.password });
      toast.success(`欢迎回来，${user.username}`);
      navigate(redirect, { replace: true });
    } catch (error) {
      setServerError(error.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AuthShell
      title="登录书屿"
      subtitle="使用邮箱或用户名继续你的校园书架。"
      footer={
        <p>
          还没有账号？{' '}
          <Link to={`/register${searchParams.get('redirect') ? `?redirect=${encodeURIComponent(redirect)}` : ''}`}>
            免费注册
          </Link>
        </p>
      }
    >
      <form className="form-stack" onSubmit={submit} noValidate>
        {serverError && (
          <div className="alert alert--danger" role="alert">
            {serverError}
          </div>
        )}
        <div className="field">
          <label htmlFor="identifier">邮箱或用户名</label>
          <input
            id="identifier"
            type="text"
            autoComplete="username"
            value={form.identifier}
            onChange={update('identifier')}
            className={errors.identifier ? 'is-invalid' : ''}
            placeholder="例如 linxi@campus.edu"
            aria-invalid={Boolean(errors.identifier)}
            aria-describedby={errors.identifier ? 'identifier-error' : undefined}
          />
          {errors.identifier && (
            <p className="field-error" id="identifier-error">
              {errors.identifier}
            </p>
          )}
        </div>
        <div className="field">
          <label htmlFor="password">密码</label>
          <div className="password-field">
            <input
              id="password"
              type={showPassword ? 'text' : 'password'}
              autoComplete="current-password"
              value={form.password}
              onChange={update('password')}
              className={errors.password ? 'is-invalid' : ''}
              placeholder="请输入密码"
              aria-invalid={Boolean(errors.password)}
              aria-describedby={errors.password ? 'password-error' : undefined}
            />
            <button
              type="button"
              className="password-field__toggle"
              onClick={() => setShowPassword((visible) => !visible)}
              aria-label={showPassword ? '隐藏密码' : '显示密码'}
            >
              {showPassword ? <EyeOff size={17} /> : <Eye size={17} />}
            </button>
          </div>
          {errors.password && (
            <p className="field-error" id="password-error">
              {errors.password}
            </p>
          )}
        </div>
        <button type="submit" className="button button--primary button--block button--lg" disabled={submitting}>
          <LogIn size={17} /> {submitting ? '正在登录…' : '登录'}
        </button>
      </form>

      <div className="demo-credentials">
        <strong>本地演示账号</strong>
        <span>linxi@campus.edu / Demo@12345</span>
        <small>仅用于开发环境演示，请勿用于真实数据。</small>
      </div>
    </AuthShell>
  );
}
