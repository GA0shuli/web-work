import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Ban,
  BookOpen,
  Check,
  LayoutDashboard,
  Loader2,
  Search,
  ShieldCheck,
  ShoppingBag,
  TrendingUp,
  UserCog,
  Users,
  X,
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../contexts/ToastContext';
import * as adminApi from '../services/admin';
import * as categoriesApi from '../services/categories';
import { useDocumentTitle } from '../hooks/useDocumentTitle';
import { useDebounce } from '../hooks/useDebounce';
import Pagination from '../components/Pagination';
import { EmptyState, ErrorMessage, LoadingSpinner, StatusBadge } from '../components/common';
import Modal from '../components/Modal';
import {
  formatDate,
  formatPrice,
  getCoverUrl,
  handleCoverError,
  ORDER_STATUS_OPTIONS,
} from '../utils/format';

const TABS = [
  { key: 'overview', label: '数据概览', icon: LayoutDashboard },
  { key: 'books', label: '图书审核', icon: BookOpen },
  { key: 'orders', label: '订单管理', icon: ShoppingBag },
];

const REVIEW_ACTIONS = {
  approve: { title: '通过图书审核', button: '确认通过', className: 'button--primary' },
  reject: { title: '驳回图书', button: '确认驳回', className: 'button--danger' },
  remove: { title: '下架图书', button: '确认下架', className: 'button--danger' },
};

export default function AdminPage() {
  useDocumentTitle('管理后台');
  const { user: currentUser } = useAuth();
  const toast = useToast();
  const [tab, setTab] = useState('overview');
  const [categories, setCategories] = useState([]);

  const [stats, setStats] = useState(null);
  const [statsLoading, setStatsLoading] = useState(true);
  const [statsError, setStatsError] = useState(null);
  const [statsReload, setStatsReload] = useState(0);

  const [bookQ, setBookQ] = useState('');
  const [bookStatus, setBookStatus] = useState('');
  const [bookCategory, setBookCategory] = useState('');
  const [bookPage, setBookPage] = useState(1);
  const [adminBooks, setAdminBooks] = useState(null);
  const [booksLoading, setBooksLoading] = useState(false);
  const [booksError, setBooksError] = useState(null);
  const [booksReload, setBooksReload] = useState(0);

  const [orderQ, setOrderQ] = useState('');
  const [orderStatus, setOrderStatus] = useState('');
  const [orderPage, setOrderPage] = useState(1);
  const [adminOrders, setAdminOrders] = useState(null);
  const [ordersLoading, setOrdersLoading] = useState(false);
  const [ordersError, setOrdersError] = useState(null);
  const [ordersReload, setOrdersReload] = useState(0);

  const [reviewTarget, setReviewTarget] = useState(null);
  const [reviewReason, setReviewReason] = useState('');
  const [modalBusy, setModalBusy] = useState(false);
  const [modalError, setModalError] = useState('');

  const debouncedBookQ = useDebounce(bookQ, 350);
  const debouncedOrderQ = useDebounce(orderQ, 350);

  useEffect(() => {
    categoriesApi.list().then(setCategories).catch(() => setCategories([]));
  }, []);

  useEffect(() => {
    if (tab !== 'overview') return undefined;
    let active = true;
    setStatsLoading(true);
    setStatsError(null);
    adminApi
      .stats()
      .then((data) => {
        if (active) setStats(data);
      })
      .catch((loadError) => {
        if (active) setStatsError(loadError.message);
      })
      .finally(() => {
        if (active) setStatsLoading(false);
      });
    return () => {
      active = false;
    };
  }, [tab, statsReload]);

  useEffect(() => {
    setBookPage(1);
  }, [debouncedBookQ, bookStatus, bookCategory]);

  useEffect(() => {
    if (tab !== 'books') return undefined;
    let active = true;
    setBooksLoading(true);
    setBooksError(null);
    adminApi
      .books({
        q: debouncedBookQ || undefined,
        reviewStatus: bookStatus || undefined,
        categoryId: bookCategory || undefined,
        page: bookPage,
        pageSize: 10,
      })
      .then((data) => {
        if (active) setAdminBooks(data);
      })
      .catch((loadError) => {
        if (active) setBooksError(loadError.message);
      })
      .finally(() => {
        if (active) setBooksLoading(false);
      });
    return () => {
      active = false;
    };
  }, [tab, debouncedBookQ, bookStatus, bookCategory, bookPage, booksReload]);

  useEffect(() => {
    setOrderPage(1);
  }, [debouncedOrderQ, orderStatus]);

  useEffect(() => {
    if (tab !== 'orders') return undefined;
    let active = true;
    setOrdersLoading(true);
    setOrdersError(null);
    adminApi
      .orders({
        q: debouncedOrderQ || undefined,
        status: orderStatus || undefined,
        page: orderPage,
        pageSize: 10,
      })
      .then((data) => {
        if (active) setAdminOrders(data);
      })
      .catch((loadError) => {
        if (active) setOrdersError(loadError.message);
      })
      .finally(() => {
        if (active) setOrdersLoading(false);
      });
    return () => {
      active = false;
    };
  }, [tab, debouncedOrderQ, orderStatus, orderPage, ordersReload]);

  const openReview = (book, action) => {
    setReviewTarget({ book, action });
    setReviewReason('');
    setModalError('');
  };

  const submitReview = async () => {
    if (!reviewTarget) return;
    if (reviewTarget.action !== 'approve' && reviewReason.trim().length < 2) {
      setModalError('请填写至少 2 个字符的审核说明');
      return;
    }
    setModalBusy(true);
    setModalError('');
    try {
      await adminApi.reviewBook(reviewTarget.book.id, {
        action: reviewTarget.action,
        reason: reviewReason.trim() || undefined,
      });
      toast.success(
        reviewTarget.action === 'approve'
          ? '图书已通过审核'
          : reviewTarget.action === 'reject'
            ? '图书已驳回'
            : '图书已下架',
      );
      setReviewTarget(null);
      setBooksReload((key) => key + 1);
      setStatsReload((key) => key + 1);
    } catch (actionError) {
      setModalError(actionError.message);
    } finally {
      setModalBusy(false);
    }
  };

  return (
    <div className="container page-section admin-page">
      <header className="page-header">
        <div>
          <span className="eyebrow eyebrow--plain">
            <ShieldCheck size={14} /> 管理员工作台
          </span>
          <h1>管理后台</h1>
          <p>所有管理操作都会在后端校验管理员权限。</p>
        </div>
        <span className="pill pill--soft">
          <UserCog size={14} /> {currentUser?.username}
        </span>
      </header>

      <div className="admin-layout">
        <aside className="admin-sidebar" aria-label="管理导航">
          {TABS.map(({ key, label, icon: Icon }) => (
            <button
              key={key}
              type="button"
              className={`admin-nav${tab === key ? ' is-active' : ''}`}
              onClick={() => setTab(key)}
            >
              <Icon size={17} /> {label}
              {key === 'books' && stats?.totals.pendingBooks > 0 && (
                <span className="admin-nav__badge">{stats.totals.pendingBooks}</span>
              )}
            </button>
          ))}
        </aside>

        <div className="admin-content">
          {tab === 'overview' && (
            <>
              {statsLoading ? (
                <LoadingSpinner label="正在汇总平台数据…" />
              ) : statsError ? (
                <ErrorMessage message={statsError} onRetry={() => setStatsReload((key) => key + 1)} />
              ) : (
                <>
                  <div className="stat-grid stat-grid--admin">
                    <div className="stat-card">
                      <span>
                        <Users size={15} /> 注册用户
                      </span>
                      <b>{stats.totals.users}</b>
                      <small>今日新增 {stats.totals.todayUsers}</small>
                    </div>
                    <div className="stat-card">
                      <span>
                        <BookOpen size={15} /> 图书总数
                      </span>
                      <b>{stats.totals.books}</b>
                      <small>在售 {stats.totals.availableBooks} 本</small>
                    </div>
                    <div className="stat-card stat-card--warning">
                      <span>
                        <ShieldCheck size={15} /> 待审核
                      </span>
                      <b>{stats.totals.pendingBooks}</b>
                      <button type="button" className="link-arrow" onClick={() => setTab('books')}>
                        去处理
                      </button>
                    </div>
                    <div className="stat-card">
                      <span>
                        <ShoppingBag size={15} /> 订单总数
                      </span>
                      <b>{stats.totals.orders}</b>
                      <small>今日新增 {stats.totals.todayOrders}</small>
                    </div>
                    <div className="stat-card stat-card--accent">
                      <span>
                        <TrendingUp size={15} /> 累计成交额
                      </span>
                      <b>{formatPrice(stats.totals.gmv, { exact: true })}</b>
                      <small>{stats.totals.completedOrders} 笔已完成</small>
                    </div>
                  </div>

                  <div className="admin-grid">
                    <section className="panel">
                      <div className="panel__heading">
                        <h2>待审核图书</h2>
                        <button type="button" className="link-arrow" onClick={() => setTab('books')}>
                          查看全部
                        </button>
                      </div>
                      {stats.pendingPreview.length === 0 ? (
                        <EmptyState
                          icon={Check}
                          title="审核队列已清空"
                          description="当前没有等待审核的图书。"
                        />
                      ) : (
                        <div className="pending-list">
                          {stats.pendingPreview.map((book) => (
                            <div className="pending-item" key={book.id}>
                              <img
                                src={getCoverUrl(book.coverPath)}
                                alt={`《${book.title}》封面`}
                                onError={handleCoverError}
                              />
                              <div>
                                <strong>{book.title}</strong>
                                <span className="muted">
                                  {book.seller?.username} · {formatPrice(book.price)}
                                </span>
                              </div>
                              <button
                                type="button"
                                className="button button--secondary button--sm"
                                onClick={() => openReview(book, 'approve')}
                              >
                                审核
                              </button>
                            </div>
                          ))}
                        </div>
                      )}
                    </section>
                  </div>
                </>
              )}
            </>
          )}

          {tab === 'books' && (
            <section className="panel panel--flush">
              <div className="admin-toolbar">
                <div className="admin-toolbar__search">
                  <Search size={16} />
                  <input
                    type="search"
                    value={bookQ}
                    onChange={(event) => setBookQ(event.target.value)}
                    placeholder="搜索书名、作者、ISBN 或卖家"
                    aria-label="搜索图书"
                  />
                </div>
                <select
                  value={bookStatus}
                  onChange={(event) => setBookStatus(event.target.value)}
                  aria-label="审核状态"
                >
                  <option value="">全部审核状态</option>
                  <option value="pending">待审核</option>
                  <option value="approved">已通过</option>
                  <option value="rejected">已驳回</option>
                </select>
                <select
                  value={bookCategory}
                  onChange={(event) => setBookCategory(event.target.value)}
                  aria-label="图书分类"
                >
                  <option value="">全部分类</option>
                  {categories.map((category) => (
                    <option key={category.id} value={category.id}>
                      {category.name}
                    </option>
                  ))}
                </select>
              </div>

              {booksLoading ? (
                <LoadingSpinner label="正在加载图书…" />
              ) : booksError ? (
                <ErrorMessage message={booksError} onRetry={() => setBooksReload((key) => key + 1)} />
              ) : adminBooks?.items.length ? (
                <>
                  <div className="table-wrap">
                    <table className="data-table">
                      <thead>
                        <tr>
                          <th>图书</th>
                          <th>卖家</th>
                          <th>价格</th>
                          <th>审核状态</th>
                          <th>交易状态</th>
                          <th>发布时间</th>
                          <th className="text-right">操作</th>
                        </tr>
                      </thead>
                      <tbody>
                        {adminBooks.items.map((book) => (
                          <tr key={book.id}>
                            <td>
                              <div className="table-book">
                                <img src={getCoverUrl(book.coverPath)} alt="" onError={handleCoverError} />
                                <div>
                                  <Link to={`/books/${book.id}`}>{book.title}</Link>
                                  <span className="muted">
                                    {book.author} · {book.category?.name}
                                  </span>
                                  {book.reviewNote && (
                                    <span className="table-note">说明：{book.reviewNote}</span>
                                  )}
                                </div>
                              </div>
                            </td>
                            <td>{book.seller?.username}</td>
                            <td>{formatPrice(book.price)}</td>
                            <td>
                              <StatusBadge type="review" status={book.reviewStatus} />
                            </td>
                            <td>
                              {book.reviewStatus === 'approved' ? (
                                <StatusBadge type="sale" status={book.saleStatus} />
                              ) : (
                                <span className="muted">—</span>
                              )}
                            </td>
                            <td>{formatDate(book.createdAt)}</td>
                            <td>
                              <div className="table-actions">
                                {book.reviewStatus !== 'approved' && (
                                  <button
                                    type="button"
                                    className="button button--secondary button--sm"
                                    onClick={() => openReview(book, 'approve')}
                                  >
                                    <Check size={14} /> 通过
                                  </button>
                                )}
                                {book.reviewStatus === 'pending' && (
                                  <button
                                    type="button"
                                    className="button button--ghost button--sm"
                                    onClick={() => openReview(book, 'reject')}
                                  >
                                    <X size={14} /> 驳回
                                  </button>
                                )}
                                {book.reviewStatus === 'approved' && book.saleStatus === 'available' && (
                                  <button
                                    type="button"
                                    className="button button--ghost button--sm"
                                    onClick={() => openReview(book, 'remove')}
                                  >
                                    <Ban size={14} /> 下架
                                  </button>
                                )}
                              </div>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <Pagination
                    page={adminBooks.pagination.page}
                    totalPages={adminBooks.pagination.totalPages}
                    total={adminBooks.pagination.total}
                    onChange={setBookPage}
                  />
                </>
              ) : (
                <EmptyState icon={BookOpen} title="没有符合条件的图书" description="调整筛选条件后再试。" />
              )}
            </section>
          )}

          {tab === 'orders' && (
            <section className="panel panel--flush">
              <div className="admin-toolbar">
                <div className="admin-toolbar__search">
                  <Search size={16} />
                  <input
                    type="search"
                    value={orderQ}
                    onChange={(event) => setOrderQ(event.target.value)}
                    placeholder="搜索订单号、买家或卖家"
                    aria-label="搜索订单"
                  />
                </div>
                <select
                  value={orderStatus}
                  onChange={(event) => setOrderStatus(event.target.value)}
                  aria-label="订单状态"
                >
                  <option value="">全部状态</option>
                  {ORDER_STATUS_OPTIONS.map((option) => (
                    <option key={option.value} value={option.value}>
                      {option.label}
                    </option>
                  ))}
                </select>
              </div>

              {ordersLoading ? (
                <LoadingSpinner label="正在加载订单…" />
              ) : ordersError ? (
                <ErrorMessage message={ordersError} onRetry={() => setOrdersReload((key) => key + 1)} />
              ) : adminOrders?.items.length ? (
                <>
                  <div className="table-wrap">
                    <table className="data-table">
                      <thead>
                        <tr>
                          <th>订单号</th>
                          <th>图书</th>
                          <th>买家 → 卖家</th>
                          <th>金额</th>
                          <th>状态</th>
                          <th>联系人</th>
                          <th>创建时间</th>
                        </tr>
                      </thead>
                      <tbody>
                        {adminOrders.items.map((order) => (
                          <tr key={order.id}>
                            <td>
                              <span className="mono">{order.orderNo}</span>
                            </td>
                            <td>
                              {order.firstTitle}
                              {order.itemCount > 1 ? ` 等 ${order.itemCount} 本` : ''}
                            </td>
                            <td>
                              {order.buyer.username} → {order.seller.username}
                            </td>
                            <td>{formatPrice(order.totalAmount, { exact: true })}</td>
                            <td>
                              <StatusBadge type="order" status={order.status} />
                            </td>
                            <td>
                              {order.contactName}
                              <span className="muted"> · {order.contactPhone}</span>
                            </td>
                            <td>{formatDate(order.createdAt, { withTime: true })}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                  <Pagination
                    page={adminOrders.pagination.page}
                    totalPages={adminOrders.pagination.totalPages}
                    total={adminOrders.pagination.total}
                    onChange={setOrderPage}
                  />
                </>
              ) : (
                <EmptyState icon={ShoppingBag} title="没有符合条件的订单" description="调整筛选条件后再试。" />
              )}
            </section>
          )}
        </div>
      </div>

      <Modal
        open={Boolean(reviewTarget)}
        title={reviewTarget ? REVIEW_ACTIONS[reviewTarget.action].title : ''}
        onClose={() => !modalBusy && setReviewTarget(null)}
        footer={
          <>
            <button
              type="button"
              className="button button--ghost"
              onClick={() => setReviewTarget(null)}
              disabled={modalBusy}
            >
              取消
            </button>
            <button
              type="button"
              className={`button ${REVIEW_ACTIONS[reviewTarget?.action ?? 'approve'].className}`}
              onClick={submitReview}
              disabled={modalBusy}
            >
              {modalBusy ? <Loader2 size={15} className="loading__icon" /> : null}
              {modalBusy ? '正在提交…' : REVIEW_ACTIONS[reviewTarget?.action ?? 'approve'].button}
            </button>
          </>
        }
      >
        {reviewTarget && (
          <>
            <p>
              图书：《{reviewTarget.book.title}》 · 卖家：{reviewTarget.book.seller?.username}
            </p>
            {reviewTarget.action === 'approve' ? (
              <p className="muted">通过后图书会出现在公开列表中，可正常下单交易。</p>
            ) : (
              <div className="field">
                <label htmlFor="review-reason">
                  审核说明 <span className="required">*</span>
                </label>
                <textarea
                  id="review-reason"
                  rows={3}
                  value={reviewReason}
                  onChange={(event) => setReviewReason(event.target.value)}
                  maxLength={200}
                  placeholder="请说明驳回或下架的原因，将同步给卖家。"
                />
              </div>
            )}
            {modalError && <div className="alert alert--danger">{modalError}</div>}
          </>
        )}
      </Modal>
    </div>
  );
}
