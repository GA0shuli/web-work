import { useEffect, useState } from 'react';
import { RotateCcw, SlidersHorizontal, X } from 'lucide-react';
import { CONDITION_OPTIONS } from '../utils/format';

const EMPTY = {
  category: '',
  minPrice: '',
  maxPrice: '',
  conditions: [],
};

export default function FilterPanel({ categories = [], value = EMPTY, onApply, onReset, open, onClose }) {
  const [draft, setDraft] = useState({ ...EMPTY, ...value });

  useEffect(() => {
    setDraft({
      category: value.category ?? '',
      minPrice: value.minPrice ?? '',
      maxPrice: value.maxPrice ?? '',
      conditions: value.conditions ?? [],
    });
  }, [value.category, value.minPrice, value.maxPrice, value.conditions]);

  const toggleCondition = (condition) => {
    setDraft((current) => ({
      ...current,
      conditions: current.conditions.includes(condition)
        ? current.conditions.filter((item) => item !== condition)
        : [...current.conditions, condition],
    }));
  };

  const apply = () => {
    onApply?.({
      category: draft.category,
      minPrice: draft.minPrice,
      maxPrice: draft.maxPrice,
      conditions: draft.conditions,
    });
  };

  const reset = () => {
    setDraft(EMPTY);
    onReset?.();
  };

  return (
    <aside className={`filter-panel${open ? ' is-open' : ''}`} aria-label="筛选图书">
      <div className="filter-panel__header">
        <h2>
          <SlidersHorizontal size={18} /> 筛选条件
        </h2>
        <button type="button" className="icon-button filter-panel__close" onClick={onClose} aria-label="关闭筛选">
          <X size={18} />
        </button>
      </div>

      <fieldset className="filter-group">
        <legend>图书分类</legend>
        <div className="filter-chips">
          <button
            type="button"
            className={`chip${draft.category === '' ? ' is-active' : ''}`}
            onClick={() => setDraft((current) => ({ ...current, category: '' }))}
          >
            全部
          </button>
          {categories.map((category) => (
            <button
              key={category.id}
              type="button"
              className={`chip${draft.category === category.slug ? ' is-active' : ''}`}
              onClick={() => setDraft((current) => ({ ...current, category: category.slug }))}
            >
              {category.name}
              <span>{category.bookCount}</span>
            </button>
          ))}
        </div>
      </fieldset>

      <fieldset className="filter-group">
        <legend>价格区间</legend>
        <div className="price-range">
          <label>
            <span className="sr-only">最低价格</span>
            <input
              type="number"
              min="0"
              max="9999"
              step="1"
              placeholder="最低价"
              value={draft.minPrice}
              onChange={(event) => setDraft((current) => ({ ...current, minPrice: event.target.value }))}
            />
          </label>
          <span className="price-range__dash">—</span>
          <label>
            <span className="sr-only">最高价格</span>
            <input
              type="number"
              min="0"
              max="9999"
              step="1"
              placeholder="最高价"
              value={draft.maxPrice}
              onChange={(event) => setDraft((current) => ({ ...current, maxPrice: event.target.value }))}
            />
          </label>
        </div>
        <p className="filter-hint">按人民币元筛选，例如 10 — 30</p>
      </fieldset>

      <fieldset className="filter-group">
        <legend>成色</legend>
        <div className="filter-checks">
          {CONDITION_OPTIONS.map((option) => (
            <label key={option.value} className="check-row">
              <input
                type="checkbox"
                checked={draft.conditions.includes(option.value)}
                onChange={() => toggleCondition(option.value)}
              />
              <span>
                <b>{option.label}</b>
                <small>{option.description}</small>
              </span>
            </label>
          ))}
        </div>
      </fieldset>

      <div className="filter-panel__actions">
        <button type="button" className="button button--primary button--block" onClick={apply}>
          应用筛选
        </button>
        <button type="button" className="button button--ghost button--block" onClick={reset}>
          <RotateCcw size={15} /> 重置条件
        </button>
      </div>
    </aside>
  );
}

export { EMPTY as EMPTY_FILTERS };
