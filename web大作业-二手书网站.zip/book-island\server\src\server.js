import { createApp } from './app.js';
import { env } from './config/env.js';
import { bootstrapDatabase } from './database/bootstrap.js';
import { closeDatabase } from './database/db.js';

bootstrapDatabase();
const app = createApp();

const server = app.listen(env.port, () => {
  console.log(`书屿 API 已启动: http://localhost:${env.port}/api/health`);
  console.log(`运行环境: ${env.nodeEnv}，数据库: ${env.dbPath}`);
});

server.on('error', (error) => {
  if (error.code === 'EADDRINUSE') {
    console.error(`\n[启动失败] 端口 ${env.port} 已被占用。`);
    console.error('一般是上一次启动的窗口没有关干净。');
    console.error('请关闭所有「书屿」启动窗口，或双击项目根目录的 stop.bat 清理后再启动。\n');
    process.exit(1);
  }
  throw error;
});

function shutdown(signal) {
  console.log(`收到 ${signal}，正在关闭服务...`);
  server.close(() => {
    closeDatabase();
    process.exit(0);
  });
  setTimeout(() => process.exit(1), 5000).unref();
}

process.on('SIGINT', () => shutdown('SIGINT'));
process.on('SIGTERM', () => shutdown('SIGTERM'));
