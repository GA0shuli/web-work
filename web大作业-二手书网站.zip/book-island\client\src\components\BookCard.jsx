import { Link } from 'react-router-dom';
import { MapPin } from 'lucide-react';
import {
  conditionLabel,
  discountPercent,
  formatPrice,
  getCoverUrl,
  handleCoverError,
  initials,
} from '../utils/format';

export default function BookCard({ book, className = '', highlight = '' }) {
  const unavailable = book.saleStatus && book.saleStatus !== 'available';
  const discount = discountPercent(book.originalPrice, book.price);

  const renderTitle = () => {
    const query = highlight.trim();
    if (!query) return book.title;
    const index = book.title.toLowerCase().indexOf(query.toLowerCase());
    if (index === -1) return book.title;
    return (
      <>
        {book.title.slice(0, index)}
        <mark className="highlight">{book.title.slice(index, index + query.length)}</mark>
        {book.title.slice(index + query.length)}
      </>
    );
  };

  return (
    <article className={`book-card ${className}`.trim()}>
      <div className="book-card__cover">
        <Link to={`/books/${book.id}`} aria-label={`查看《${book.title}》详情`}>
          <img
            src={getCoverUrl(book.coverPath)}
            alt={`《${book.title}》封面`}
            loading="lazy"
            decoding="async"
            onError={handleCoverError}
          />
        </Link>
        {unavailable && (
          <span className="book-card__status">
            {book.saleStatus === 'sold' ? '已售出' : book.saleStatus === 'reserved' ? '交易中' : '已下架'}
          </span>
        )}
      </div>

      <div className="book-card__body">
        <div className="book-card__meta">
          <span className="pill pill--soft">{book.category?.name ?? '图书'}</span>
          <span className="pill pill--outline">{conditionLabel(book.condition)}</span>
        </div>
        <Link to={`/books/${book.id}`} className="book-card__title">
          {renderTitle()}
        </Link>
        <p className="book-card__author">{book.author}</p>

        <div className="book-card__price-row">
          <span className="price">{formatPrice(book.price)}</span>
          {book.originalPrice && Number(book.originalPrice) > Number(book.price) && (
            <>
              <s className="price-original">{formatPrice(book.originalPrice)}</s>
              {discount && <span className="discount">{discount}% off</span>}
            </>
          )}
        </div>

        <div className="book-card__footer">
          <span className="seller-inline">
            <span className="avatar avatar--xs">{initials(book.seller?.username)}</span>
            {book.seller?.username ?? '同学'}
          </span>
          <span className="book-card__campus">
            <MapPin size={13} /> {book.seller?.campus ?? '校内自提'}
          </span>
        </div>
      </div>
    </article>
  );
}
