import { Router } from 'express';
import { listCategories } from '../services/category.service.js';
import { success } from '../utils/response.js';

export const categoryRouter = Router();

categoryRouter.get('/', (req, res) => success(res, { items: listCategories() }, '获取分类成功'));
