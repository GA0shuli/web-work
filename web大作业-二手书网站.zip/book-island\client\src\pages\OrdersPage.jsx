import { useEffect, useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import {
  CheckCircle2,
  Clock,
  Loader2,
  MapPin,
  MessageSquare,
  PackageCheck,
  ShoppingBag,
  Store,
  XCircle,
} from 'lucide-react';
import { useToast } from '../contexts/ToastContext';
import * as ordersApi from '../services/orders';
import { EmptyState, ErrorMessage, LoadingSpinner, StatusBadge } from '../components/common';
import Modal from '../components/Modal';
import Pagination from '../components/Pagination';
import { useDocumentTitle } from '../hooks/useDocumentTitle';
import {
  ORDER_STATUS_OPTIONS,
  conditionLabel,
  formatDate,
  formatPrice,
  getCoverUrl,
  handleCoverError,
} from '../utils/format';

const STEPS = [
  { key: 'pending_seller', label: '待卖家确认', icon: Clock },
  { key: 'in_progress', label: '交易进行中', icon: Store },
  { key: 'completed', label: '已完成', icon: PackageCheck },
];
const STEP_INDEX = { pending_seller: 0, in_progress: 1, completed: 2 };

export default function OrdersPage() {
  useDocumentTitle('我的订单');
  const [searchParams, setSearchParams] = useSearchParams();
  const initialTab = searchParams.get('tab') === 'seller' ? 'seller' : 'buyer';
  const toast = useToast();

  const [tab, setTab] = useState(initialTab);
  const [status, setStatus] = useState('');
  const [page, setPage] = useState(1);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [reloadKey, setReloadKey] = useState(0);
  const [action, setAction] = useState(null);
  const [reason, setReason] = useState('');
  const [busy, setBusy] = useState(false);
  const [actionError, setActionError] = useState('');

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError(null);
    ordersApi
      .list({ role: tab, status: status || undefined, page, pageSize: 10 })
      .then((result) => {
        if (active) setData(result);
      })
      .catch((loadError) => {
        if (active) setError(loadError.message);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [tab, status, page, reloadKey]);

  useEffect(() => {
    const fromUrl = searchParams.get('tab') === 'seller' ? 'seller' : 'buyer';
    if (fromUrl !== tab) setTab(fromUrl);
  }, [searchParams, tab]);

  const orders = data?.items ?? [];

  const summary = useMemo(() => {
    const activeCount = orders.filter((order) =>
      ['pending_seller', 'in_progress'].includes(order.status),
    ).length;
    return { activeCount };
  }, [orders]);

  const changeTab = (next) => {
    setTab(next);
    setStatus('');
    setPage(1);
    if (next === 'seller') setSearchParams({ tab: 'seller' });
    else setSearchParams({});
  };

  const reload = () => setReloadKey((key) => key + 1);

  const openAction = (order, type) => {
    setAction({ order, type });
    setReason('');
    setActionError('');
  };

  const closeAction = () => {
    if (!busy) setAction(null);
  };

  const runStatusUpdate = async (order, nextStatus, cancelReason = '') => {
    setBusy(true);
    setActionError('');
    try {
      await ordersApi.updateStatus(order.id, { status: nextStatus, reason: cancelReason || undefined });
      toast.success(
        nextStatus === 'in_progress'
          ? '已确认接单，记得和买家约定自提时间'
          : nextStatus === 'completed'
            ? '交易已完成，感谢你维护校园交易环境'
            : '订单已取消，图书状态已同步恢复',
      );
      setAction(null);
      reload();
    } catch (updateError) {
      if (action) setActionError(updateError.message);
      else toast.error(updateError.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="container page-section">
      <header className="page-header">
        <div>
          <span className="eyebrow eyebrow--plain">交易全程可追踪</span>
          <h1>我的订单</h1>
          <p>
            共 {data?.pagination.total ?? 0} 笔订单，其中 {summary.activeCount} 笔正在进行。
          </p>
        </div>
        <Link to="/books" className="button button--secondary">
          <ShoppingBag size={16} /> 继续逛书
        </Link>
      </header>

      <div className="tabs" role="tablist" aria-label="订单角色">
        <button
          type="button"
          role="tab"
          aria-selected={tab === 'buyer'}
          className={`tab${tab === 'buyer' ? ' is-active' : ''}`}
          onClick={() => changeTab('buyer')}
        >
          我买到的
        </button>
        <button
          type="button"
          role="tab"
          aria-selected={tab === 'seller'}
          className={`tab${tab === 'seller' ? ' is-active' : ''}`}
          onClick={() => changeTab('seller')}
        >
          我卖出的
        </button>
      </div>

      <div className="orders-toolbar">
        <div className="filter-chips">
          <button
            type="button"
            className={`chip${status === '' ? ' is-active' : ''}`}
            onClick={() => {
              setStatus('');
              setPage(1);
            }}
          >
            全部状态
          </button>
          {ORDER_STATUS_OPTIONS.map((option) => (
            <button
              key={option.value}
              type="button"
              className={`chip${status === option.value ? ' is-active' : ''}`}
              onClick={() => {
                setStatus(option.value);
                setPage(1);
              }}
            >
              {option.label}
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <LoadingSpinner label="正在读取订单…" />
      ) : error ? (
        <ErrorMessage message={error} onRetry={reload} />
      ) : orders.length === 0 ? (
        <EmptyState
          icon={ShoppingBag}
          title={tab === 'buyer' ? '还没有购买记录' : '还没有卖出记录'}
          description={
            tab === 'buyer'
              ? '在图书详情页加入购物车并提交订单后，可在这里查看进度。'
              : '发布闲置并通过审核后，买家下单会出现在这里。'
          }
          action={
            <Link to={tab === 'buyer' ? '/books' : '/publish'} className="button button--primary">
              {tab === 'buyer' ? '去找一本教材' : '发布闲置'}
            </Link>
          }
        />
      ) : (
        <div className="order-list">
          {orders.map((order) => {
            const stepIndex = STEP_INDEX[order.status];
            const canAct =
              order.permissions?.canConfirm ||
              order.permissions?.canComplete ||
              order.permissions?.canCancel;

            return (
              <article className="order-card" key={order.id}>
                <header className="order-card__header">
                  <div>
                    <span className="order-no">订单号 {order.orderNo}</span>
                    <span className="muted">{formatDate(order.createdAt, { withTime: true })}</span>
                  </div>
                  <StatusBadge type="order" status={order.status} />
                </header>

                {order.status !== 'cancelled' && stepIndex !== undefined && (
                  <ol className="order-steps" aria-label="订单进度">
                    {STEPS.map((step, index) => (
                      <li
                        key={step.key}
                        className={`${index <= stepIndex ? 'is-done' : ''}${index === stepIndex ? ' is-current' : ''}`}
                      >
                        <span className="order-steps__dot">
                          <step.icon size={13} />
                        </span>
                        <span>{step.label}</span>
                      </li>
                    ))}
                  </ol>
                )}
                {order.status === 'cancelled' && order.cancelReason && (
                  <p className="order-cancelled-note">
                    <XCircle size={15} /> 取消原因：{order.cancelReason}
                  </p>
                )}

                <div className="order-items">
                  {order.items.map((item) => (
                    <div className="order-item" key={item.id}>
                      <div className="order-item__cover">
                        <img
                          src={getCoverUrl(item.coverPath)}
                          alt={`《${item.title}》封面`}
                          onError={handleCoverError}
                        />
                      </div>
                      <div className="order-item__info">
                        <Link to={`/books/${item.bookId}`}>{item.title}</Link>
                        <span className="muted">{item.author}</span>
                        <span className="pill pill--outline">{conditionLabel(item.condition)}</span>
                      </div>
                      <strong className="price">{formatPrice(item.price)}</strong>
                    </div>
                  ))}
                </div>

                <div className="order-card__meta">
                  <div>
                    <span>
                      <Store size={14} /> {tab === 'buyer' ? '卖家' : '买家'}：
                      {tab === 'buyer'
                        ? order.seller?.username
                        : order.buyer?.username}
                    </span>
                    <span>
                      <MapPin size={14} /> 自提：{order.pickupLocation || '待协商'}
                    </span>
                    <span>
                      <MessageSquare size={14} /> {order.contactName} · {order.contactPhone}
                    </span>
                  </div>
                  <div className="order-total">
                    <span>订单金额</span>
                    <strong>{formatPrice(order.totalAmount, { exact: true })}</strong>
                  </div>
                </div>

                {order.note && <p className="order-note">备注：{order.note}</p>}

                {canAct && (
                  <footer className="order-card__actions">
                    {order.permissions.canConfirm && (
                      <button
                        type="button"
                        className="button button--primary button--sm"
                        onClick={() => runStatusUpdate(order, 'in_progress')}
                        disabled={busy}
                      >
                        <CheckCircle2 size={15} /> 确认接单
                      </button>
                    )}
                    {order.permissions.canComplete && (
                      <button
                        type="button"
                        className="button button--primary button--sm"
                        onClick={() => openAction(order, 'complete')}
                      >
                        <PackageCheck size={15} /> 确认完成交易
                      </button>
                    )}
                    {order.permissions.canCancel && (
                      <button
                        type="button"
                        className="button button--ghost button--sm"
                        onClick={() => openAction(order, 'cancel')}
                      >
                        取消订单
                      </button>
                    )}
                  </footer>
                )}
              </article>
            );
          })}
        </div>
      )}

      {!loading && data?.pagination.totalPages > 1 && (
        <Pagination
          page={data.pagination.page}
          totalPages={data.pagination.totalPages}
          total={data.pagination.total}
          onChange={setPage}
        />
      )}

      <Modal
        open={action?.type === 'complete'}
        title="确认交易已完成？"
        onClose={closeAction}
        footer={
          <>
            <button type="button" className="button button--ghost" onClick={closeAction} disabled={busy}>
              再想想
            </button>
            <button
              type="button"
              className="button button--primary"
              onClick={() => runStatusUpdate(action.order, 'completed')}
              disabled={busy}
            >
              {busy ? '正在确认…' : '确认完成'}
            </button>
          </>
        }
      >
        <p>确认已当面验书并完成交易？确认后订单不可撤销，图书将标记为已售出。</p>
        {actionError && <div className="alert alert--danger">{actionError}</div>}
      </Modal>

      <Modal
        open={action?.type === 'cancel'}
        title="取消订单"
        onClose={closeAction}
        footer={
          <>
            <button type="button" className="button button--ghost" onClick={closeAction} disabled={busy}>
              返回
            </button>
            <button
              type="button"
              className="button button--danger"
              onClick={() => runStatusUpdate(action.order, 'cancelled', reason.trim())}
              disabled={busy || reason.trim().length < 2}
            >
              {busy ? <Loader2 size={15} className="loading__icon" /> : null}
              {busy ? '正在取消…' : '确认取消'}
            </button>
          </>
        }
      >
        <p>取消后图书会恢复为可交易（前提是仍通过审核）。请填写取消原因，方便对方了解情况。</p>
        <div className="field">
          <label htmlFor="cancel-reason">
            取消原因 <span className="required">*</span>
          </label>
          <textarea
            id="cancel-reason"
            rows={3}
            value={reason}
            onChange={(event) => setReason(event.target.value)}
            maxLength={200}
            placeholder="例如 时间冲突，暂时无法自提"
          />
        </div>
        {actionError && <div className="alert alert--danger">{actionError}</div>}
      </Modal>
    </div>
  );
}
