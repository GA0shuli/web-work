import { getDb } from '../src/database/db.js';
import { initSchema } from '../src/database/schema.js';
import { seedDatabase } from '../src/database/seed.js';

const TABLES = [
  'audit_logs',
  'reviews',
  'order_items',
  'orders',
  'favorites',
  'cart_items',
  'books',
  'categories',
  'users',
];

// 直接清空测试库数据，避免 Windows 下删除被占用的 SQLite 文件导致 EPERM。
export function resetTestDatabase() {
  const db = getDb();
  initSchema();
  db.pragma('foreign_keys = OFF');
  const clear = db.transaction(() => {
    for (const table of TABLES) {
      db.prepare(`DELETE FROM ${table}`).run();
    }
    db.prepare('DELETE FROM sqlite_sequence').run();
  });
  clear();
  db.pragma('foreign_keys = ON');
  return seedDatabase();
}
