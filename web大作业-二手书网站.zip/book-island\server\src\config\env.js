import path from 'node:path';
import { fileURLToPath } from 'node:url';
import dotenv from 'dotenv';

const serverRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');

dotenv.config({ path: path.join(serverRoot, '.env'), quiet: true });

const nodeEnv = process.env.NODE_ENV || 'development';
const isProduction = nodeEnv === 'production';
const isTest = nodeEnv === 'test';

const DEFAULT_DEV_SECRET = 'book-island-local-development-secret-change-me';

if (isProduction && !process.env.JWT_SECRET) {
  throw new Error('生产环境必须通过 JWT_SECRET 环境变量配置 JWT 密钥');
}

function toInt(value, fallback) {
  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) ? parsed : fallback;
}

export const env = {
  nodeEnv,
  isProduction,
  isTest,
  port: toInt(process.env.PORT, 4000),
  jwtSecret: process.env.JWT_SECRET || DEFAULT_DEV_SECRET,
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '7d',
  dbPath: path.resolve(serverRoot, process.env.DB_PATH || './data/book-island.db'),
  uploadsDir: path.join(serverRoot, 'uploads'),
  clientDistDir: path.resolve(serverRoot, '../client/dist'),
  clientOrigins: (process.env.CLIENT_ORIGIN || 'http://localhost:5173,http://127.0.0.1:5173')
    .split(',')
    .map((item) => item.trim())
    .filter(Boolean),
  admin: {
    username: process.env.ADMIN_USERNAME || 'admin',
    email: process.env.ADMIN_EMAIL || 'admin@bookisland.local',
    password: process.env.ADMIN_PASSWORD || 'Admin@12345',
  },
  demoPassword: process.env.DEMO_PASSWORD || 'Demo@12345',
  cookieName: 'bi_token',
};

export const serverRootDir = serverRoot;
