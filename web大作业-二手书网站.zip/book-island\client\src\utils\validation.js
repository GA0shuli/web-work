export function passwordStrength(password) {
  if (!password) return { score: 0, label: '请输入密码' };
  let score = 0;
  if (password.length >= 8) score += 1;
  if (/[A-Za-z]/.test(password) && /\d/.test(password)) score += 1;
  if (password.length >= 12) score += 1;
  if (/[^A-Za-z0-9]/.test(password)) score += 1;
  const labels = ['太短', '较弱', '一般', '较强', '很强'];
  return { score, label: labels[score] };
}

export function validateLogin({ identifier, password }) {
  const errors = {};
  if (!identifier?.trim()) errors.identifier = '请输入邮箱或用户名';
  if (!password) errors.password = '请输入密码';
  return errors;
}

export function validateRegister({ username, email, password, confirmPassword }) {
  const errors = {};
  if (!username?.trim()) {
    errors.username = '请输入用户名';
  } else if (!/^[\w\u4e00-\u9fa5.-]{3,20}$/u.test(username.trim())) {
    errors.username = '用户名需为 3-20 位中文、字母、数字或下划线';
  }
  if (!email?.trim()) {
    errors.email = '请输入邮箱';
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email.trim())) {
    errors.email = '邮箱格式不正确';
  }
  if (!password) {
    errors.password = '请输入密码';
  } else if (password.length < 8) {
    errors.password = '密码至少 8 位';
  } else if (!/[A-Za-z]/.test(password) || !/\d/.test(password)) {
    errors.password = '密码需同时包含字母和数字';
  }
  if (password !== confirmPassword) {
    errors.confirmPassword = '两次输入的密码不一致';
  }
  return errors;
}

export function validateBookForm(form) {
  const errors = {};
  if (!form.title?.trim()) errors.title = '请输入书名';
  if (!form.author?.trim()) errors.author = '请输入作者';
  const isbn = String(form.isbn ?? '').replace(/[-\s]/g, '').toUpperCase();
  if (!isbn) {
    errors.isbn = '请输入 ISBN';
  } else if (!/^\d{9}[\dX]$/.test(isbn) && !/^\d{13}$/.test(isbn)) {
    errors.isbn = 'ISBN 需为 10 位或 13 位';
  }
  if (!form.categoryId) errors.categoryId = '请选择分类';
  if (!form.condition) errors.condition = '请选择成色';

  const price = Number(form.price);
  if (!form.price && form.price !== 0) {
    errors.price = '请输入售价';
  } else if (!Number.isFinite(price) || price <= 0) {
    errors.price = '售价需大于 0';
  }
  const originalPrice = form.originalPrice === '' ? null : Number(form.originalPrice);
  if (originalPrice !== null && (!Number.isFinite(originalPrice) || originalPrice < 0)) {
    errors.originalPrice = '参考原价格式不正确';
  } else if (originalPrice !== null && Number.isFinite(price) && originalPrice < price) {
    errors.originalPrice = '参考原价不能低于售价';
  }
  if (form.publishYear) {
    const year = Number(form.publishYear);
    if (!Number.isInteger(year) || year < 1900 || year > new Date().getFullYear() + 1) {
      errors.publishYear = '出版年份不正确';
    }
  }
  return errors;
}

export function hasErrors(errors) {
  return Object.keys(errors).length > 0;
}
