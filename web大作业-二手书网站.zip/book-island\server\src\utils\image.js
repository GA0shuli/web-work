import crypto from 'node:crypto';
import fs from 'node:fs/promises';
import path from 'node:path';
import { badRequest } from './AppError.js';
import { env } from '../config/env.js';

const EXTENSIONS = {
  'image/jpeg': 'jpg',
  'image/png': 'png',
  'image/webp': 'webp',
};

// 图片格式在 multer 的 fileFilter 里已经按 MIME 类型过滤过一次，
// 这里再确认一次，并生成不重复的文件名后写入 uploads 目录
export async function saveCoverImage(file, uploadsDir = env.uploadsDir) {
  const extension = EXTENSIONS[file.mimetype];
  if (!extension) {
    throw badRequest('封面仅支持 JPG、PNG 或 WebP 格式');
  }

  await fs.mkdir(uploadsDir, { recursive: true });
  const fileName = `${Date.now()}-${crypto.randomUUID()}.${extension}`;
  await fs.writeFile(path.join(uploadsDir, fileName), file.buffer, { flag: 'wx' });
  return `/uploads/${fileName}`;
}

export async function removeCoverImage(coverPath, uploadsDir = env.uploadsDir) {
  if (!coverPath || !coverPath.startsWith('/uploads/')) return;

  const fileName = path.basename(coverPath);
  if (!/^[\w.-]+$/.test(fileName)) return;

  try {
    await fs.unlink(path.join(uploadsDir, fileName));
  } catch (error) {
    if (error.code !== 'ENOENT') {
      console.warn('删除旧封面失败:', error.message);
    }
  }
}
