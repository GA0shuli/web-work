import bcrypt from 'bcryptjs';
import { getDb } from '../database/db.js';
import { conflict, forbidden, unauthorized } from '../utils/AppError.js';
import { publicUser } from '../middleware/auth.js';

const SALT_ROUNDS = 11;

export function registerUser({ username, email, password }) {
  const db = getDb();
  const existing = db
    .prepare('SELECT id FROM users WHERE lower(email) = ? OR lower(username) = ?')
    .get(email.toLowerCase(), username.toLowerCase());
  if (existing) throw conflict('该邮箱或用户名已被注册', 'ACCOUNT_EXISTS');

  const passwordHash = bcrypt.hashSync(password, SALT_ROUNDS);
  try {
    const result = db
      .prepare(
        `INSERT INTO users (username, email, password_hash, role, status)
         VALUES (?, ?, ?, 'user', 'active')`,
      )
      .run(username, email.toLowerCase(), passwordHash);
    const row = db.prepare('SELECT * FROM users WHERE id = ?').get(Number(result.lastInsertRowid));
    return publicUser(row);
  } catch (error) {
    if (String(error.code).startsWith('SQLITE_CONSTRAINT')) {
      throw conflict('该邮箱或用户名已被注册', 'ACCOUNT_EXISTS');
    }
    throw error;
  }
}

export function loginUser({ identifier, password }) {
  const db = getDb();
  const row = db
    .prepare('SELECT * FROM users WHERE lower(email) = ? OR lower(username) = ?')
    .get(identifier.toLowerCase(), identifier.toLowerCase());
  if (!row || !bcrypt.compareSync(password, row.password_hash)) {
    throw unauthorized('账号或密码错误');
  }
  if (row.status !== 'active') {
    throw forbidden('该账号已被停用，请联系平台管理员');
  }
  return row;
}

export function findUserById(id) {
  return getDb().prepare('SELECT * FROM users WHERE id = ?').get(id);
}
