import { Link } from 'react-router-dom';
import { MapPin, Sparkles } from 'lucide-react';
import {
  conditionLabel,
  formatPrice,
  getCoverUrl,
  handleCoverError,
} from '../utils/format';

const BREAKDOWN_LABELS = {
  keyword: '关键词匹配',
  price: '价格匹配',
  condition: '成色评分',
  freshness: '新鲜度',
};

export default function RecommendationCard({ item, showBreakdown = false }) {
  return (
    <article className="recommend-card">
      <div className="recommend-card__top">
        <Link to={`/books/${item.id}`} className="recommend-card__cover">
          <img
            src={getCoverUrl(item.coverPath)}
            alt={`《${item.title}》封面`}
            loading="lazy"
            onError={handleCoverError}
          />
        </Link>
        <div className="recommend-card__info">
          <span className="score-badge">
            <Sparkles size={13} /> {item.score?.toFixed(1)} 分
          </span>
          <Link to={`/books/${item.id}`} className="recommend-card__title">
            {item.title}
          </Link>
          <p className="recommend-card__author">{item.author}</p>
          <div className="recommend-card__tags">
            <span className="pill pill--outline">{conditionLabel(item.condition)}</span>
            <span className="pill pill--soft">{item.category?.name}</span>
          </div>
          <div className="recommend-card__price">
            <strong className="price">{formatPrice(item.price)}</strong>
            {item.originalPrice && <s>{formatPrice(item.originalPrice)}</s>}
            {item.priceComparison?.savingsPercent > 0 && (
              <span className="discount">比原价低 {item.priceComparison.savingsPercent}%</span>
            )}
          </div>
          <span className="recommend-card__seller">
            <MapPin size={13} /> {item.seller?.username} · {item.seller?.campus ?? '校内自提'}
          </span>
        </div>
      </div>

      {item.reasons?.length > 0 && (
        <ul className="reason-list" aria-label="推荐理由">
          {item.reasons.slice(0, showBreakdown ? 6 : 3).map((reason) => (
            <li key={reason}>{reason}</li>
          ))}
        </ul>
      )}

      {showBreakdown && item.scoreBreakdown && (
        <div className="score-breakdown">
          {Object.entries(item.scoreBreakdown).map(([key, value]) => (
            <div className="score-breakdown__row" key={key}>
              <span>{BREAKDOWN_LABELS[key] ?? key}</span>
              <div className="score-bar" role="img" aria-label={`${BREAKDOWN_LABELS[key]} ${value} 分`}>
                <span style={{ width: `${Math.min(100, Math.max(0, value))}%` }} />
              </div>
              <b>{Number(value).toFixed(0)}</b>
            </div>
          ))}
        </div>
      )}

      <Link to={`/books/${item.id}`} className="button button--secondary button--sm recommend-card__action">
        查看图书
      </Link>
    </article>
  );
}
