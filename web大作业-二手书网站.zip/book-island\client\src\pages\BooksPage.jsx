import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { ArrowDownUp, SlidersHorizontal, X } from 'lucide-react';
import SearchBar from '../components/SearchBar';
import FilterPanel from '../components/FilterPanel';
import BookCard from '../components/BookCard';
import Pagination from '../components/Pagination';
import { BookGridSkeleton, EmptyState, ErrorMessage } from '../components/common';
import * as booksApi from '../services/books';
import * as categoriesApi from '../services/categories';
import { useDocumentTitle } from '../hooks/useDocumentTitle';
import { conditionLabel } from '../utils/format';

const SORT_OPTIONS = [
  { value: 'newest', label: '最新发布' },
  { value: 'price_asc', label: '价格从低到高' },
  { value: 'price_desc', label: '价格从高到低' },
  { value: 'oldest', label: '最早发布' },
];

const DEFAULT_SORT = 'newest';

export default function BooksPage() {
  useDocumentTitle('全部图书');
  const [searchParams, setSearchParams] = useSearchParams();
  const [categories, setCategories] = useState([]);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filterOpen, setFilterOpen] = useState(false);
  const [reloadKey, setReloadKey] = useState(0);

  const queryKey = searchParams.toString();
  const params = useMemo(() => {
    const conditions = (searchParams.get('condition') ?? '').split(',').filter(Boolean);
    return {
      q: searchParams.get('q') ?? '',
      category: searchParams.get('category') ?? '',
      conditions,
      minPrice: searchParams.get('minPrice') ?? '',
      maxPrice: searchParams.get('maxPrice') ?? '',
      sort: searchParams.get('sort') ?? DEFAULT_SORT,
      page: Number(searchParams.get('page')) || 1,
    };
  }, [searchParams]);

  useEffect(() => {
    categoriesApi
      .list()
      .then(setCategories)
      .catch(() => setCategories([]));
  }, []);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError(null);
    booksApi
      .list({
        q: params.q || undefined,
        category: params.category || undefined,
        condition: params.conditions.length ? params.conditions.join(',') : undefined,
        minPrice: params.minPrice || undefined,
        maxPrice: params.maxPrice || undefined,
        sort: params.sort,
        page: params.page,
        pageSize: 12,
      })
      .then((result) => {
        if (active) setData(result);
      })
      .catch((loadError) => {
        if (active) setError(loadError.message);
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, [queryKey, reloadKey, params]);

  const updateParams = (patch, { resetPage = true } = {}) => {
    const next = new URLSearchParams(searchParams);
    Object.entries(patch).forEach(([key, value]) => {
      if (value === '' || value === null || value === undefined || (Array.isArray(value) && !value.length)) {
        next.delete(key);
      } else {
        next.set(key, Array.isArray(value) ? value.join(',') : String(value));
      }
    });
    if (resetPage) next.delete('page');
    setSearchParams(next);
  };

  const handleSearch = (keyword) => {
    updateParams({ q: keyword });
  };

  const applyFilters = ({ category, minPrice, maxPrice, conditions }) => {
    updateParams({
      category,
      minPrice,
      maxPrice,
      condition: conditions,
    });
    setFilterOpen(false);
  };

  const resetFilters = () => {
    const next = new URLSearchParams();
    if (params.q) next.set('q', params.q);
    if (params.sort !== DEFAULT_SORT) next.set('sort', params.sort);
    setSearchParams(next);
    setFilterOpen(false);
  };

  const categoryName = categories.find((item) => item.slug === params.category)?.name;
  const hasFilters =
    params.q ||
    params.category ||
    params.conditions.length ||
    params.minPrice ||
    params.maxPrice;

  return (
    <div className="container page-section">
      <header className="page-header">
        <div>
          <span className="eyebrow eyebrow--plain">校园书架</span>
          <h1>全部图书</h1>
          <p>按分类、价格和成色筛选，找到适合下一门课的教材。</p>
        </div>
      </header>

      <div className="catalog-toolbar">
        <SearchBar initialValue={params.q} onSearch={handleSearch} />
        <div className="catalog-toolbar__right">
          <button
            type="button"
            className="button button--secondary filter-toggle"
            onClick={() => setFilterOpen((open) => !open)}
          >
            <SlidersHorizontal size={16} /> 筛选
            {hasFilters && <span className="badge-dot">·</span>}
          </button>
          <label className="sort-control">
            <ArrowDownUp size={16} aria-hidden="true" />
            <span className="sr-only">排序方式</span>
            <select
              value={params.sort}
              onChange={(event) => updateParams({ sort: event.target.value })}
            >
              {SORT_OPTIONS.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </label>
        </div>
      </div>

      {hasFilters && (
        <div className="active-filters" aria-label="当前筛选条件">
          {params.q && (
            <button type="button" className="filter-chip" onClick={() => updateParams({ q: '' })}>
              关键词：{params.q} <X size={13} />
            </button>
          )}
          {categoryName && (
            <button type="button" className="filter-chip" onClick={() => updateParams({ category: '' })}>
              {categoryName} <X size={13} />
            </button>
          )}
          {params.conditions.map((condition) => (
            <button
              key={condition}
              type="button"
              className="filter-chip"
              onClick={() =>
                updateParams({ condition: params.conditions.filter((item) => item !== condition) })
              }
            >
              {conditionLabel(condition)} <X size={13} />
            </button>
          ))}
          {(params.minPrice || params.maxPrice) && (
            <button
              type="button"
              className="filter-chip"
              onClick={() => updateParams({ minPrice: '', maxPrice: '' })}
            >
              {params.minPrice ? `¥${params.minPrice}` : '不限'} — {params.maxPrice ? `¥${params.maxPrice}` : '不限'}{' '}
              <X size={13} />
            </button>
          )}
        </div>
      )}

      <div className="catalog-layout">
        <FilterPanel
          categories={categories}
          value={{
            category: params.category,
            minPrice: params.minPrice,
            maxPrice: params.maxPrice,
            conditions: params.conditions,
          }}
          onApply={applyFilters}
          onReset={resetFilters}
          open={filterOpen}
          onClose={() => setFilterOpen(false)}
        />

        <section className="catalog-results" aria-label="图书搜索结果">
          <div className="results-meta">
            <span>
              {loading ? '正在搜索…' : `找到 ${data?.pagination.total ?? 0} 本图书`}
              {categoryName ? ` · ${categoryName}` : ''}
            </span>
            {data && data.pagination.totalPages > 1 && (
              <span>
                第 {data.pagination.page} / {data.pagination.totalPages} 页
              </span>
            )}
          </div>

          {loading ? (
            <BookGridSkeleton count={8} />
          ) : error ? (
            <ErrorMessage message={error} onRetry={() => setReloadKey((key) => key + 1)} />
          ) : data?.items.length ? (
            <>
              <div className="book-grid book-grid--three">
                {data.items.map((book) => (
                  <BookCard key={book.id} book={book} highlight={params.q} />
                ))}
              </div>
              <Pagination
                page={data.pagination.page}
                totalPages={data.pagination.totalPages}
                total={data.pagination.total}
                onChange={(page) => updateParams({ page }, { resetPage: false })}
              />
            </>
          ) : (
            <EmptyState
              title="没有找到匹配的图书"
              description="试试减少筛选条件，或者换一个关键词搜索。"
              action={
                <button type="button" className="button button--primary" onClick={resetFilters}>
                  清除筛选条件
                </button>
              }
            />
          )}
        </section>
      </div>
    </div>
  );
}
