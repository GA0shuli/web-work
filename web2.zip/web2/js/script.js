/* ============================================================
 * 我的个人博客 —— 页面交互脚本 (script.js)
 * 作者：高桂
 * ------------------------------------------------------------
 * 模块划分（每个模块独立、低耦合，统一在 init() 中初始化）：
 *   1. Utils        通用工具函数
 *   2. Theme        明暗主题切换（动态修改样式 + 本地存储）
 *   3. Navigation   移动端菜单 / 滚动高亮 / 返回顶部
 *   4. Hero         打字机效果 + 按时间变化的问候语
 *   5. Skills       技能进度条滚动动画
 *   6. Articles     文章动态渲染 / 新增 / 删除（增删元素）
 *   7. Projects     项目分类筛选 + 关键字搜索
 *   8. Carousel     图片轮播（自动播放 / 手动切换 / 指示点）
 *   9. ContactForm  联系表单实时校验与提交
 *  10. Reveal       元素滚动进入视口时显现动画
 *  11. Footer       页脚年份自动更新
 * ============================================================ */
(function () {
    'use strict';

    /* ========================================================
     * 1. Utils —— 通用工具
     * ====================================================== */
    const Utils = {
        /** 安全地读取 localStorage，避免隐私模式报错 */
        getStore(key, fallback) {
            try {
                const raw = localStorage.getItem(key);
                return raw ? JSON.parse(raw) : fallback;
            } catch (err) {
                return fallback;
            }
        },

        /** 安全地写入 localStorage */
        setStore(key, value) {
            try {
                localStorage.setItem(key, JSON.stringify(value));
            } catch (err) {
                /* 忽略写入异常（如超出配额） */
            }
        },

        /** 生成一个简单的唯一 id */
        uid(prefix) {
            return (prefix || 'id') + '-' + Date.now().toString(36) + '-' +
                Math.random().toString(36).slice(2, 7);
        },

        /** 把 HTML 特殊字符转义，防止用户输入被当作标签解析 */
        escapeHTML(str) {
            return String(str).replace(/[&<>"']/g, function (ch) {
                return {
                    '&': '&amp;',
                    '<': '&lt;',
                    '>': '&gt;',
                    '"': '&quot;',
                    "'": '&#39;'
                }[ch];
            });
        },

        /** 把日期（YYYY-MM-DD 或 Date）格式化为 YYYY.MM.DD */
        formatDate(value) {
            const d = value instanceof Date ? value : new Date(value);
            if (isNaN(d.getTime())) return String(value || '');
            const pad = n => String(n).padStart(2, '0');
            return d.getFullYear() + '.' + pad(d.getMonth() + 1) + '.' + pad(d.getDate());
        },

        /** 节流：限制高频事件（如 scroll）的执行频率 */
        throttle(fn, wait) {
            let last = 0;
            let timer = null;
            return function () {
                const now = Date.now();
                const args = arguments;
                if (now - last >= (wait || 100)) {
                    last = now;
                    fn.apply(this, args);
                } else if (!timer) {
                    timer = setTimeout(() => {
                        last = Date.now();
                        timer = null;
                        fn.apply(this, args);
                    }, (wait || 100) - (now - last));
                }
            };
        }
    };

    /* ========================================================
     * 2. Theme —— 明暗主题切换
     * ====================================================== */
    const Theme = {
        KEY: 'myblog.theme',

        init() {
            const btn = document.getElementById('themeToggle');
            const saved = Utils.getStore(this.KEY, 'light');
            this.apply(saved);

            if (btn) {
                btn.addEventListener('click', () => {
                    const next = document.body.classList.contains('dark-theme') ? 'light' : 'dark';
                    this.apply(next);
                    Utils.setStore(this.KEY, next);
                });
            }
        },

        /** 应用主题：切换 body 上的 class，并同步按钮图标与提示 */
        apply(mode) {
            const btn = document.getElementById('themeToggle');
            const isDark = mode === 'dark';
            document.body.classList.toggle('dark-theme', isDark);
            if (btn) {
                btn.textContent = isDark ? '☀️' : '🌙';
                btn.setAttribute('aria-label', isDark ? '切换到明亮主题' : '切换到暗色主题');
                btn.title = isDark ? '切换到明亮主题' : '切换到暗色主题';
            }
        }
    };

    /* ========================================================
     * 3. Navigation —— 移动端菜单 / 滚动高亮 / 返回顶部
     * ====================================================== */
    const Navigation = {
        init() {
            this.menu();
            this.scrollSpy();
            this.backToTop();
        },

        /** 移动端汉堡菜单展开 / 收起 */
        menu() {
            const toggle = document.getElementById('menuToggle');
            const menu = document.getElementById('navMenu');
            if (!toggle || !menu) return;

            toggle.addEventListener('click', () => {
                menu.classList.toggle('open');
                toggle.classList.toggle('active');
                const expanded = menu.classList.contains('open');
                toggle.setAttribute('aria-expanded', String(expanded));
            });

            // 点击任意导航链接后自动收起菜单
            menu.addEventListener('click', (e) => {
                if (e.target.tagName === 'A') {
                    menu.classList.remove('open');
                    toggle.classList.remove('active');
                }
            });
        },

        /** 滚动时高亮当前区块对应的导航项，并给导航栏加阴影 */
        scrollSpy() {
            const header = document.querySelector('.header');
            const links = Array.prototype.slice.call(document.querySelectorAll('.nav a'));
            const sections = links
                .map(a => document.querySelector(a.getAttribute('href')))
                .filter(Boolean);

            const onScroll = Utils.throttle(() => {
                const pos = window.scrollY + 120;

                if (header) {
                    header.classList.toggle('scrolled', window.scrollY > 10);
                }

                let currentId = sections.length ? sections[0].id : '';
                sections.forEach(sec => {
                    if (sec.offsetTop <= pos) currentId = sec.id;
                });

                links.forEach(a => {
                    a.classList.toggle('active', a.getAttribute('href') === '#' + currentId);
                });
            }, 100);

            window.addEventListener('scroll', onScroll);
            onScroll();
        },

        /** 返回顶部按钮：滚动一定距离后出现，带进度圆环 */
        backToTop() {
            const btn = document.getElementById('backToTop');
            if (!btn) return;
            const ring = btn.querySelector('.progress-ring__circle');

            const update = Utils.throttle(() => {
                const doc = document.documentElement;
                const max = doc.scrollHeight - doc.clientHeight;
                const ratio = max > 0 ? Math.min(doc.scrollTop / max, 1) : 0;

                btn.classList.toggle('show', doc.scrollTop > 300);

                if (ring) {
                    const r = ring.r.baseVal.value;
                    const c = 2 * Math.PI * r;
                    ring.style.strokeDasharray = c + ' ' + c;
                    ring.style.strokeDashoffset = String(c * (1 - ratio));
                }
            }, 60);

            window.addEventListener('scroll', update);
            update();

            btn.addEventListener('click', () => {
                window.scrollTo({ top: 0, behavior: 'smooth' });
            });
        }
    };

    /* ========================================================
     * 4. Hero —— 打字机效果 + 时间问候
     * ====================================================== */
    const Hero = {
        phrases: [
            'Welcome to my blog',
            'Keep Learning, Keep Creating',
            'HTML5 · CSS3 · Python · JavaScript',
            '热爱排球与音乐的计算机学生'
        ],

        init() {
            this.greeting();
            this.typing();
        },

        /** 根据访问时间动态显示问候语 */
        greeting() {
            const el = document.getElementById('greeting');
            if (!el) return;
            const h = new Date().getHours();
            let text;
            if (h < 6) text = '凌晨好，注意休息～';
            else if (h < 12) text = '早上好，新的一天开始啦！';
            else if (h < 14) text = '中午好，记得好好吃饭～';
            else if (h < 18) text = '下午好，继续加油！';
            else if (h < 23) text = '晚上好，欢迎来到我的博客～';
            else text = '夜深了，早点休息哦～';
            el.textContent = text;
        },

        /** 打字机：逐字显示，打完一句停顿后删除，循环播放 */
        typing() {
            const el = document.getElementById('typing');
            if (!el) return;

            let phraseIndex = 0;
            let charIndex = 0;
            let deleting = false;

            const tick = () => {
                const phrase = this.phrases[phraseIndex];

                if (!deleting) {
                    el.textContent = phrase.slice(0, ++charIndex);
                    if (charIndex === phrase.length) {
                        deleting = true;
                        return setTimeout(tick, 1600); // 打完停顿
                    }
                    return setTimeout(tick, 90);
                }

                el.textContent = phrase.slice(0, --charIndex);
                if (charIndex === 0) {
                    deleting = false;
                    phraseIndex = (phraseIndex + 1) % this.phrases.length;
                    return setTimeout(tick, 400);
                }
                return setTimeout(tick, 45);
            };

            tick();
        }
    };

    /* ========================================================
     * 5. Skills —— 技能进度条滚动动画
     * ====================================================== */
    const Skills = {
        init() {
            const cards = document.querySelectorAll('.skill-card');
            if (!cards.length) return;

            // 记录目标百分比，并把初始宽度置 0，等待进入视口后再增长
            const bars = [];
            cards.forEach(card => {
                const bar = card.querySelector('.skill-bar span');
                const label = card.querySelector('small');
                if (!bar) return;
                const target = parseInt(bar.style.width, 10) || 0;
                bar.style.width = '0%';
                bars.push({ bar, label, target, done: false });
            });

            const run = () => {
                bars.forEach(item => {
                    if (item.done) return;
                    const rect = item.bar.getBoundingClientRect();
                    if (rect.top < window.innerHeight - 40) {
                        item.done = true;
                        item.bar.style.width = item.target + '%';
                        this.countUp(item.label, item.target);
                    }
                });
            };

            const onScroll = Utils.throttle(run, 120);
            window.addEventListener('scroll', onScroll);
            window.addEventListener('resize', onScroll);
            run();
        },

        /** 数字从 0 增长到目标值，动态修改文本内容 */
        countUp(el, target) {
            if (!el) return;
            let cur = 0;
            const step = Math.max(1, Math.round(target / 30));
            const timer = setInterval(() => {
                cur += step;
                if (cur >= target) {
                    cur = target;
                    clearInterval(timer);
                }
                el.textContent = cur + '%';
            }, 25);
        }
    };

    /* ========================================================
     * 6. Articles —— 文章动态渲染 / 新增 / 删除
     * ====================================================== */
    const Articles = {
        KEY: 'myblog.articles',

        defaults: [
            {
                id: 'seed-1',
                title: 'Python 学习笔记',
                date: '2026.09.20',
                content: '记录 Python 学习过程中的一些基础知识，包括函数、类、文件操作以及异常处理等。'
            },
            {
                id: 'seed-2',
                title: 'HTML5 与 CSS3 学习记录',
                date: '2026.09.15',
                content: '学习 HTML5 语义化标签以及 CSS3 Flexbox 和 Grid 布局技术。'
            }
        ],

        /** 运行时的文章数据（从本地存储读取，无则使用默认数据） */
        list: [],

        init() {
            this.grid = document.getElementById('articleGrid');
            this.form = document.getElementById('articleForm');
            this.error = document.getElementById('articleError');
            this.countEl = document.getElementById('articleCount');
            if (!this.grid) return;

            this.list = Utils.getStore(this.KEY, this.defaults);
            this.render();
            this.bind();
        },

        persist() {
            Utils.setStore(this.KEY, this.list);
        },

        /** 用数据重新渲染整个文章列表（清空 + 重建 DOM 元素） */
        render() {
            this.grid.innerHTML = '';

            if (!this.list.length) {
                const empty = document.createElement('p');
                empty.className = 'empty-tip';
                empty.textContent = '暂时还没有文章，点击「写新文章」发布第一篇吧～';
                this.grid.appendChild(empty);
            }

            this.list.forEach((item, index) => {
                const card = document.createElement('article');
                card.className = 'article-card';
                card.dataset.id = item.id;
                card.innerHTML =
                    '<div class="article-number">' + String(index + 1).padStart(2, '0') + '</div>' +
                    '<p class="article-date">' + Utils.escapeHTML(item.date) + '</p>' +
                    '<h3>' + Utils.escapeHTML(item.title) + '</h3>' +
                    '<p>' + Utils.escapeHTML(item.content) + '</p>' +
                    '<div class="article-footer">' +
                    '  <a href="#">阅读更多 →</a>' +
                    '  <button type="button" class="article-delete" data-id="' + item.id + '" title="删除这篇文章">删除</button>' +
                    '</div>';
                this.grid.appendChild(card);
            });

            if (this.countEl) {
                this.countEl.textContent = '共 ' + this.list.length + ' 篇文章';
            }
        },

        bind() {
            // 打开 / 关闭「写新文章」面板
            const toggleBtn = document.getElementById('toggleEditorBtn');
            const cancelBtn = document.getElementById('cancelArticleBtn');
            if (toggleBtn && this.form) {
                toggleBtn.addEventListener('click', () => {
                    const hidden = this.form.hasAttribute('hidden');
                    if (hidden) {
                        this.form.removeAttribute('hidden');
                        toggleBtn.textContent = '− 收起';
                    } else {
                        this.form.setAttribute('hidden', '');
                        toggleBtn.textContent = '+ 写新文章';
                    }
                });
            }
            if (cancelBtn && this.form) {
                cancelBtn.addEventListener('click', () => {
                    this.form.setAttribute('hidden', '');
                    this.form.reset();
                    this.setError('');
                    const t = document.getElementById('toggleEditorBtn');
                    if (t) t.textContent = '+ 写新文章';
                });
            }

            // 提交新文章（含表单验证）
            if (this.form) {
                this.form.addEventListener('submit', (e) => {
                    e.preventDefault();
                    this.add();
                });
            }

            // 删除文章：使用事件委托，动态生成的按钮也能响应
            this.grid.addEventListener('click', (e) => {
                const btn = e.target.closest('.article-delete');
                if (!btn) return;
                this.remove(btn.dataset.id);
            });
        },

        setError(msg) {
            if (!this.error) return;
            this.error.textContent = msg || '';
            this.error.classList.toggle('show', Boolean(msg));
        },

        /** 读取表单 -> 校验 -> 生成新文章元素 */
        add() {
            const titleEl = document.getElementById('articleTitle');
            const dateEl = document.getElementById('articleDate');
            const contentEl = document.getElementById('articleContent');

            const title = titleEl.value.trim();
            const content = contentEl.value.trim();
            const date = dateEl.value ? Utils.formatDate(dateEl.value) : Utils.formatDate(new Date());

            if (title.length < 2) {
                this.setError('标题至少需要 2 个字符。');
                titleEl.focus();
                return;
            }
            if (content.length < 10) {
                this.setError('正文内容至少需要 10 个字符。');
                contentEl.focus();
                return;
            }

            this.setError('');
            this.list.unshift({ id: Utils.uid('article'), title, date, content });
            this.persist();
            this.render();

            this.form.reset();
            this.form.setAttribute('hidden', '');
            const t = document.getElementById('toggleEditorBtn');
            if (t) t.textContent = '+ 写新文章';
        },

        /** 删除指定文章并重新渲染 */
        remove(id) {
            this.list = this.list.filter(item => item.id !== id);
            this.persist();
            this.render();
        }
    };

    /* ========================================================
     * 7. Projects —— 分类筛选 + 关键字搜索
     * ====================================================== */
    const Projects = {
        filter: 'all',
        keyword: '',

        init() {
            this.grid = document.querySelector('.projects-grid');
            this.bar = document.getElementById('projectFilters');
            this.search = document.getElementById('projectSearch');
            if (!this.grid) return;

            this.cards = Array.prototype.slice.call(this.grid.querySelectorAll('.project-card'));
            this.bind();
            this.update();
        },

        bind() {
            // 分类按钮
            if (this.bar) {
                this.bar.addEventListener('click', (e) => {
                    const btn = e.target.closest('.filter-btn');
                    if (!btn) return;
                    this.filter = btn.dataset.filter;
                    this.bar.querySelectorAll('.filter-btn').forEach(b => {
                        b.classList.toggle('active', b === btn);
                    });
                    this.update();
                });
            }

            // 搜索框
            if (this.search) {
                this.search.addEventListener('input', Utils.throttle(() => {
                    this.keyword = this.search.value.trim().toLowerCase();
                    this.update();
                }, 120));
            }
        },

        /** 根据当前分类与关键字，动态显示 / 隐藏项目卡片 */
        update() {
            let visible = 0;

            this.cards.forEach(card => {
                const category = card.dataset.category || '';
                const text = card.textContent.toLowerCase();

                const matchFilter = this.filter === 'all' || category === this.filter;
                const matchKeyword = !this.keyword || text.indexOf(this.keyword) !== -1;
                const show = matchFilter && matchKeyword;

                card.classList.toggle('is-hidden', !show);
                if (show) visible++;
            });

            let tip = this.grid.querySelector('.empty-tip');
            if (!visible) {
                if (!tip) {
                    tip = document.createElement('p');
                    tip.className = 'empty-tip';
                    this.grid.appendChild(tip);
                }
                tip.textContent = '没有找到符合条件的项目，试试其它筛选条件吧～';
            } else if (tip) {
                tip.remove();
            }
        }
    };

    /* ========================================================
     * 8. Carousel —— 图片轮播
     * ====================================================== */
    const Carousel = {
        index: 0,
        timer: null,
        delay: 4000,

        init() {
            this.track = document.getElementById('carouselTrack');
            this.dotsBox = document.getElementById('carouselDots');
            const root = document.getElementById('carousel');
            if (!this.track || !root) return;

            this.slides = Array.prototype.slice.call(this.track.children);
            if (!this.slides.length) return;

            this.buildDots();
            this.bind(root);
            this.go(0);
            this.play();
        },

        /** 根据幻灯片数量动态生成指示点 */
        buildDots() {
            if (!this.dotsBox) return;
            this.dotsBox.innerHTML = '';
            this.slides.forEach((_, i) => {
                const dot = document.createElement('button');
                dot.type = 'button';
                dot.className = 'carousel-dot';
                dot.setAttribute('aria-label', '第 ' + (i + 1) + ' 张');
                dot.addEventListener('click', () => {
                    this.go(i);
                    this.play();
                });
                this.dotsBox.appendChild(dot);
            });
            this.dots = Array.prototype.slice.call(this.dotsBox.children);
        },

        bind(root) {
            const prev = document.getElementById('prevBtn');
            const next = document.getElementById('nextBtn');

            if (prev) prev.addEventListener('click', () => { this.go(this.index - 1); this.play(); });
            if (next) next.addEventListener('click', () => { this.go(this.index + 1); this.play(); });

            // 鼠标悬停暂停，移开继续
            root.addEventListener('mouseenter', () => this.pause());
            root.addEventListener('mouseleave', () => this.play());

            // 键盘左右方向键控制
            document.addEventListener('keydown', (e) => {
                if (e.key === 'ArrowLeft') { this.go(this.index - 1); this.play(); }
                if (e.key === 'ArrowRight') { this.go(this.index + 1); this.play(); }
            });
        },

        /** 切换到第 i 张（自动循环），动态修改 transform 样式 */
        go(i) {
            const total = this.slides.length;
            this.index = (i % total + total) % total;
            this.track.style.transform = 'translateX(-' + (this.index * 100) + '%)';

            this.slides.forEach((s, k) => s.classList.toggle('active', k === this.index));
            if (this.dots) {
                this.dots.forEach((d, k) => d.classList.toggle('active', k === this.index));
            }
        },

        play() {
            this.pause();
            this.timer = setInterval(() => this.go(this.index + 1), this.delay);
        },

        pause() {
            if (this.timer) {
                clearInterval(this.timer);
                this.timer = null;
            }
        }
    };

    /* ========================================================
     * 9. ContactForm —— 联系表单验证
     * ====================================================== */
    const ContactForm = {
        rules: {
            name: {
                test: v => v.trim().length >= 2,
                msg: '请输入至少 2 个字符的姓名。'
            },
            email: {
                test: v => /^[\w.+-]+@[\w-]+(\.[\w-]+)+$/.test(v.trim()),
                msg: '请输入有效的邮箱地址，例如 name@example.com。'
            },
            message: {
                test: v => v.trim().length >= 10,
                msg: '留言内容至少需要 10 个字符。'
            }
        },

        init() {
            this.form = document.getElementById('contactForm');
            if (!this.form) return;

            this.success = document.getElementById('contactSuccess');
            this.countEl = document.getElementById('charCount');
            this.messageEl = document.getElementById('message');

            this.bind();
        },

        bind() {
            const fields = Object.keys(this.rules);

            fields.forEach(name => {
                const input = this.form.elements[name];
                if (!input) return;

                // 实时校验：输入时与失焦时都触发
                input.addEventListener('input', () => {
                    if (this.touched(name)) this.validateField(name);
                    if (name === 'message') this.updateCount();
                });
                input.addEventListener('blur', () => {
                    this.form.elements[name].dataset.touched = 'true';
                    this.validateField(name);
                });
            });

            this.updateCount();

            this.form.addEventListener('submit', (e) => {
                e.preventDefault();
                let ok = true;
                fields.forEach(name => {
                    this.form.elements[name].dataset.touched = 'true';
                    if (!this.validateField(name)) ok = false;
                });

                if (!ok) {
                    this.showSuccess('');
                    const firstBad = this.form.querySelector('.form-group.error input, .form-group.error textarea');
                    if (firstBad) firstBad.focus();
                    return;
                }

                // 模拟发送：真实项目中这里可改为 fetch 提交
                const name = this.form.elements.name.value.trim();
                this.showSuccess('✅ 谢谢 ' + name + '，你的消息已发送，我会尽快回复！');
                this.form.reset();
                this.updateCount();
                this.clearAllState();
            });
        },

        touched(name) {
            const el = this.form.elements[name];
            return el && el.dataset.touched === 'true';
        },

        /** 校验单个字段，动态添加 / 移除错误样式与提示 */
        validateField(name) {
            const rule = this.rules[name];
            const input = this.form.elements[name];
            if (!rule || !input) return true;

            const group = input.closest('.form-group');
            const msgEl = group ? group.querySelector('.error-msg') : null;
            const valid = rule.test(input.value);

            if (group) group.classList.toggle('error', !valid);
            if (msgEl) msgEl.textContent = valid ? '' : rule.msg;

            return valid;
        },

        clearAllState() {
            this.form.querySelectorAll('.form-group').forEach(g => g.classList.remove('error'));
            this.form.querySelectorAll('.error-msg').forEach(m => (m.textContent = ''));
            const selects = this.form.querySelectorAll('[data-touched]');
            selects.forEach(el => (el.dataset.touched = ''));
        },

        updateCount() {
            if (this.countEl && this.messageEl) {
                this.countEl.textContent = String(this.messageEl.value.length);
            }
        },

        showSuccess(msg) {
            if (!this.success) return;
            this.success.textContent = msg || '';
            this.success.classList.toggle('show', Boolean(msg));
        }
    };

    /* ========================================================
     * 10. Reveal —— 元素滚动显现动画
     * ====================================================== */
    const Reveal = {
        init() {
            const items = document.querySelectorAll('.reveal');
            if (!items.length) return;

            if (!('IntersectionObserver' in window)) {
                items.forEach(el => el.classList.add('visible'));
                return;
            }

            const observer = new IntersectionObserver((entries) => {
                entries.forEach(entry => {
                    if (entry.isIntersecting) {
                        entry.target.classList.add('visible');
                        observer.unobserve(entry.target);
                    }
                });
            }, { threshold: 0.12 });

            items.forEach(el => observer.observe(el));
        }
    };

    /* ========================================================
     * 11. Footer —— 页脚年份
     * ====================================================== */
    const Footer = {
        init() {
            const el = document.getElementById('year');
            if (el) el.textContent = String(new Date().getFullYear());
        }
    };

    /* ========================================================
     * 启动
     * ====================================================== */
    function init() {
        Theme.init();
        Navigation.init();
        Hero.init();
        Skills.init();
        Articles.init();
        Projects.init();
        Carousel.init();
        ContactForm.init();
        Reveal.init();
        Footer.init();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
