(() => {
  "use strict";

  const canvas = document.getElementById("gameCanvas");
  const ctx = canvas.getContext("2d");

  const timeValue = document.getElementById("timeValue");
  const bestValue = document.getElementById("bestValue");
  const finalScore = document.getElementById("finalScore");
  const finalBest = document.getElementById("finalBest");
  const startBtn = document.getElementById("startBtn");
  const restartBtn = document.getElementById("restartBtn");
  const overScreen = document.getElementById("overScreen");

  const WIDTH = canvas.width;
  const HEIGHT = canvas.height;

  const PLAYER_SPEED = 300;
  const OBSTACLE_SPEED = 240;
  const SPAWN_INTERVAL = 1.15;

  const player = {
    x: 80,
    y: HEIGHT / 2 - 20,
    width: 40,
    height: 40,
  };

  const keys = {
    up: false,
    down: false,
    left: false,
    right: false,
  };

  const keyMap = {
    ArrowUp: "up",
    KeyW: "up",
    ArrowDown: "down",
    KeyS: "down",
    ArrowLeft: "left",
    KeyA: "left",
    ArrowRight: "right",
    KeyD: "right",
  };

  const directionButtons = Array.from(document.querySelectorAll("[data-dir]"));

  let phase = "ready";
  let elapsed = 0;
  let spawnTimer = 0;
  let obstacles = [];
  let lastTimestamp = 0;
  let best = readBest();
  let audioContext = null;

  bestValue.textContent = best.toFixed(1);

  function readBest() {
    try {
      return Number(localStorage.getItem("squareRunBestTime")) || 0;
    } catch {
      return 0;
    }
  }

  function saveBest(value) {
    try {
      localStorage.setItem("squareRunBestTime", String(value));
    } catch {
      // 本地存储不可用时仍可继续游戏
    }
  }

  function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
  }

  function setKey(direction, pressed) {
    keys[direction] = pressed;
    updateButtonState();
  }

  function clearKeys() {
    keys.up = false;
    keys.down = false;
    keys.left = false;
    keys.right = false;
    updateButtonState();
  }

  function updateButtonState() {
    for (const button of directionButtons) {
      const direction = button.dataset.dir;
      button.classList.toggle("active", keys[direction]);
    }
  }

  function getAudioContext() {
    if (!audioContext) {
      const AudioContextClass = window.AudioContext || window.webkitAudioContext;
      if (!AudioContextClass) return null;
      audioContext = new AudioContextClass();
    }

    if (audioContext.state === "suspended") {
      audioContext.resume();
    }

    return audioContext;
  }

  function beep(frequency, duration, type = "sine") {
    const audio = getAudioContext();
    if (!audio) return;

    const oscillator = audio.createOscillator();
    const gain = audio.createGain();
    const now = audio.currentTime;

    oscillator.type = type;
    oscillator.frequency.value = frequency;
    gain.gain.setValueAtTime(0.06, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + duration);

    oscillator.connect(gain);
    gain.connect(audio.destination);
    oscillator.start(now);
    oscillator.stop(now + duration);
  }

  function spawnObstacle() {
    const height = 70 + Math.random() * 110;
    const width = 28;

    obstacles.push({
      x: WIDTH + 10,
      y: 20 + Math.random() * (HEIGHT - height - 40),
      width,
      height,
    });
  }

  function startGame() {
    if (phase === "running") return;

    phase = "running";
    elapsed = 0;
    spawnTimer = 0;
    obstacles = [];

    player.x = 80;
    player.y = HEIGHT / 2 - player.height / 2;

    clearKeys();
    overScreen.hidden = true;
    startBtn.disabled = true;
    startBtn.textContent = "游戏进行中";
    timeValue.textContent = "0.0";

    spawnObstacle();
    beep(520, 0.08, "triangle");
  }

  function endGame() {
    phase = "over";
    clearKeys();

    const score = Number(elapsed.toFixed(1));
    if (score > best) {
      best = score;
      saveBest(best);
    }

    bestValue.textContent = best.toFixed(1);
    finalScore.textContent = score.toFixed(1);
    finalBest.textContent = best.toFixed(1);
    overScreen.hidden = false;

    startBtn.disabled = false;
    startBtn.textContent = "重新开始";
    beep(120, 0.25, "sawtooth");
  }

  function updatePlayer(dt) {
    let dx = (keys.right ? 1 : 0) - (keys.left ? 1 : 0);
    let dy = (keys.down ? 1 : 0) - (keys.up ? 1 : 0);

    if (dx !== 0 && dy !== 0) {
      dx *= Math.SQRT1_2;
      dy *= Math.SQRT1_2;
    }

    player.x = clamp(player.x + dx * PLAYER_SPEED * dt, 0, WIDTH - player.width);
    player.y = clamp(player.y + dy * PLAYER_SPEED * dt, 0, HEIGHT - player.height);
  }

  function hasCollision(obstacle) {
    return (
      player.x < obstacle.x + obstacle.width &&
      player.x + player.width > obstacle.x &&
      player.y < obstacle.y + obstacle.height &&
      player.y + player.height > obstacle.y
    );
  }

  function update(dt) {
    elapsed += dt;
    timeValue.textContent = elapsed.toFixed(1);

    updatePlayer(dt);

    spawnTimer += dt;
    if (spawnTimer >= SPAWN_INTERVAL) {
      spawnTimer = 0;
      spawnObstacle();
    }

    for (const obstacle of obstacles) {
      obstacle.x -= OBSTACLE_SPEED * dt;
    }

    obstacles = obstacles.filter((obstacle) => obstacle.x + obstacle.width > 0);

    for (const obstacle of obstacles) {
      if (hasCollision(obstacle)) {
        endGame();
        return;
      }
    }
  }

  function draw() {
    ctx.fillStyle = "#fafafa";
    ctx.fillRect(0, 0, WIDTH, HEIGHT);

    ctx.strokeStyle = "#ececec";
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let x = 50; x < WIDTH; x += 50) {
      ctx.moveTo(x, 0);
      ctx.lineTo(x, HEIGHT);
    }
    for (let y = 50; y < HEIGHT; y += 50) {
      ctx.moveTo(0, y);
      ctx.lineTo(WIDTH, y);
    }
    ctx.stroke();

    ctx.fillStyle = "#3d5a80";
    for (const obstacle of obstacles) {
      ctx.fillRect(obstacle.x, obstacle.y, obstacle.width, obstacle.height);
    }

    ctx.fillStyle = "#e63946";
    ctx.fillRect(player.x, player.y, player.width, player.height);
  }

  function loop(timestamp) {
    if (!lastTimestamp) lastTimestamp = timestamp;
    const dt = Math.min((timestamp - lastTimestamp) / 1000, 0.05);
    lastTimestamp = timestamp;

    if (phase === "running") {
      update(dt);
    }

    draw();
    requestAnimationFrame(loop);
  }

  window.addEventListener("keydown", (event) => {
    const direction = keyMap[event.code];

    if (direction) {
      event.preventDefault();

      if (phase === "ready") {
        startGame();
      }

      if (phase === "running") {
        setKey(direction, true);
      }
      return;
    }

    if (event.code === "Space") {
      event.preventDefault();

      if (phase === "ready") {
        startGame();
      } else if (phase === "over") {
        startGame();
      }
    }
  });

  window.addEventListener("keyup", (event) => {
    const direction = keyMap[event.code];
    if (direction) {
      setKey(direction, false);
    }
  });

  window.addEventListener("blur", clearKeys);

  for (const button of directionButtons) {
    const direction = button.dataset.dir;

    button.addEventListener("pointerdown", (event) => {
      event.preventDefault();

      if (phase === "ready") {
        startGame();
      }

      if (phase !== "running") return;

      button.setPointerCapture(event.pointerId);
      setKey(direction, true);
    });

    const release = () => setKey(direction, false);
    button.addEventListener("pointerup", release);
    button.addEventListener("pointercancel", release);
    button.addEventListener("lostpointercapture", release);
  }

  startBtn.addEventListener("click", startGame);
  restartBtn.addEventListener("click", startGame);

  draw();
  requestAnimationFrame(loop);
})();
